(function() {
	//#region \0rolldown/runtime.js
	var __create = Object.create;
	var __defProp = Object.defineProperty;
	var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
	var __getOwnPropNames = Object.getOwnPropertyNames;
	var __getProtoOf = Object.getPrototypeOf;
	var __hasOwnProp = Object.prototype.hasOwnProperty;
	var __commonJSMin = (cb, mod) => () => (mod || (cb((mod = { exports: {} }).exports, mod), cb = null), mod.exports);
	var __copyProps = (to, from, except, desc) => {
		if (from && typeof from === "object" || typeof from === "function") for (var keys = __getOwnPropNames(from), i = 0, n = keys.length, key; i < n; i++) {
			key = keys[i];
			if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
				get: ((k) => from[k]).bind(null, key),
				enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
			});
		}
		return to;
	};
	var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", {
		value: mod,
		enumerable: true
	}) : target, mod));
	//#endregion
	//#region src/content/data/emoji.json
	var import_browser_polyfill = /* @__PURE__ */ __toESM((/* @__PURE__ */ __commonJSMin(((exports, module) => {
		(function(global, factory) {
			if (typeof define === "function" && define.amd) define("webextension-polyfill", ["module"], factory);
			else if (typeof exports !== "undefined") factory(module);
			else {
				var mod = { exports: {} };
				factory(mod);
				global.browser = mod.exports;
			}
		})(typeof globalThis !== "undefined" ? globalThis : typeof self !== "undefined" ? self : exports, function(module$1) {
			"use strict";
			if (!(globalThis.chrome && globalThis.chrome.runtime && globalThis.chrome.runtime.id)) throw new Error("This script should only be loaded in a browser extension.");
			if (!(globalThis.browser && globalThis.browser.runtime && globalThis.browser.runtime.id)) {
				const CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE = "The message port closed before a response was received.";
				const wrapAPIs = (extensionAPIs) => {
					const apiMetadata = {
						"alarms": {
							"clear": {
								"minArgs": 0,
								"maxArgs": 1
							},
							"clearAll": {
								"minArgs": 0,
								"maxArgs": 0
							},
							"get": {
								"minArgs": 0,
								"maxArgs": 1
							},
							"getAll": {
								"minArgs": 0,
								"maxArgs": 0
							}
						},
						"bookmarks": {
							"create": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"get": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"getChildren": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"getRecent": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"getSubTree": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"getTree": {
								"minArgs": 0,
								"maxArgs": 0
							},
							"move": {
								"minArgs": 2,
								"maxArgs": 2
							},
							"remove": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"removeTree": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"search": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"update": {
								"minArgs": 2,
								"maxArgs": 2
							}
						},
						"browserAction": {
							"disable": {
								"minArgs": 0,
								"maxArgs": 1,
								"fallbackToNoCallback": true
							},
							"enable": {
								"minArgs": 0,
								"maxArgs": 1,
								"fallbackToNoCallback": true
							},
							"getBadgeBackgroundColor": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"getBadgeText": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"getPopup": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"getTitle": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"openPopup": {
								"minArgs": 0,
								"maxArgs": 0
							},
							"setBadgeBackgroundColor": {
								"minArgs": 1,
								"maxArgs": 1,
								"fallbackToNoCallback": true
							},
							"setBadgeText": {
								"minArgs": 1,
								"maxArgs": 1,
								"fallbackToNoCallback": true
							},
							"setIcon": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"setPopup": {
								"minArgs": 1,
								"maxArgs": 1,
								"fallbackToNoCallback": true
							},
							"setTitle": {
								"minArgs": 1,
								"maxArgs": 1,
								"fallbackToNoCallback": true
							}
						},
						"browsingData": {
							"remove": {
								"minArgs": 2,
								"maxArgs": 2
							},
							"removeCache": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"removeCookies": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"removeDownloads": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"removeFormData": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"removeHistory": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"removeLocalStorage": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"removePasswords": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"removePluginData": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"settings": {
								"minArgs": 0,
								"maxArgs": 0
							}
						},
						"commands": { "getAll": {
							"minArgs": 0,
							"maxArgs": 0
						} },
						"contextMenus": {
							"remove": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"removeAll": {
								"minArgs": 0,
								"maxArgs": 0
							},
							"update": {
								"minArgs": 2,
								"maxArgs": 2
							}
						},
						"cookies": {
							"get": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"getAll": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"getAllCookieStores": {
								"minArgs": 0,
								"maxArgs": 0
							},
							"remove": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"set": {
								"minArgs": 1,
								"maxArgs": 1
							}
						},
						"devtools": {
							"inspectedWindow": { "eval": {
								"minArgs": 1,
								"maxArgs": 2,
								"singleCallbackArg": false
							} },
							"panels": {
								"create": {
									"minArgs": 3,
									"maxArgs": 3,
									"singleCallbackArg": true
								},
								"elements": { "createSidebarPane": {
									"minArgs": 1,
									"maxArgs": 1
								} }
							}
						},
						"downloads": {
							"cancel": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"download": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"erase": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"getFileIcon": {
								"minArgs": 1,
								"maxArgs": 2
							},
							"open": {
								"minArgs": 1,
								"maxArgs": 1,
								"fallbackToNoCallback": true
							},
							"pause": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"removeFile": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"resume": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"search": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"show": {
								"minArgs": 1,
								"maxArgs": 1,
								"fallbackToNoCallback": true
							}
						},
						"extension": {
							"isAllowedFileSchemeAccess": {
								"minArgs": 0,
								"maxArgs": 0
							},
							"isAllowedIncognitoAccess": {
								"minArgs": 0,
								"maxArgs": 0
							}
						},
						"history": {
							"addUrl": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"deleteAll": {
								"minArgs": 0,
								"maxArgs": 0
							},
							"deleteRange": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"deleteUrl": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"getVisits": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"search": {
								"minArgs": 1,
								"maxArgs": 1
							}
						},
						"i18n": {
							"detectLanguage": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"getAcceptLanguages": {
								"minArgs": 0,
								"maxArgs": 0
							}
						},
						"identity": { "launchWebAuthFlow": {
							"minArgs": 1,
							"maxArgs": 1
						} },
						"idle": { "queryState": {
							"minArgs": 1,
							"maxArgs": 1
						} },
						"management": {
							"get": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"getAll": {
								"minArgs": 0,
								"maxArgs": 0
							},
							"getSelf": {
								"minArgs": 0,
								"maxArgs": 0
							},
							"setEnabled": {
								"minArgs": 2,
								"maxArgs": 2
							},
							"uninstallSelf": {
								"minArgs": 0,
								"maxArgs": 1
							}
						},
						"notifications": {
							"clear": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"create": {
								"minArgs": 1,
								"maxArgs": 2
							},
							"getAll": {
								"minArgs": 0,
								"maxArgs": 0
							},
							"getPermissionLevel": {
								"minArgs": 0,
								"maxArgs": 0
							},
							"update": {
								"minArgs": 2,
								"maxArgs": 2
							}
						},
						"pageAction": {
							"getPopup": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"getTitle": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"hide": {
								"minArgs": 1,
								"maxArgs": 1,
								"fallbackToNoCallback": true
							},
							"setIcon": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"setPopup": {
								"minArgs": 1,
								"maxArgs": 1,
								"fallbackToNoCallback": true
							},
							"setTitle": {
								"minArgs": 1,
								"maxArgs": 1,
								"fallbackToNoCallback": true
							},
							"show": {
								"minArgs": 1,
								"maxArgs": 1,
								"fallbackToNoCallback": true
							}
						},
						"permissions": {
							"contains": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"getAll": {
								"minArgs": 0,
								"maxArgs": 0
							},
							"remove": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"request": {
								"minArgs": 1,
								"maxArgs": 1
							}
						},
						"runtime": {
							"getBackgroundPage": {
								"minArgs": 0,
								"maxArgs": 0
							},
							"getPlatformInfo": {
								"minArgs": 0,
								"maxArgs": 0
							},
							"openOptionsPage": {
								"minArgs": 0,
								"maxArgs": 0
							},
							"requestUpdateCheck": {
								"minArgs": 0,
								"maxArgs": 0
							},
							"sendMessage": {
								"minArgs": 1,
								"maxArgs": 3
							},
							"sendNativeMessage": {
								"minArgs": 2,
								"maxArgs": 2
							},
							"setUninstallURL": {
								"minArgs": 1,
								"maxArgs": 1
							}
						},
						"sessions": {
							"getDevices": {
								"minArgs": 0,
								"maxArgs": 1
							},
							"getRecentlyClosed": {
								"minArgs": 0,
								"maxArgs": 1
							},
							"restore": {
								"minArgs": 0,
								"maxArgs": 1
							}
						},
						"storage": {
							"local": {
								"clear": {
									"minArgs": 0,
									"maxArgs": 0
								},
								"get": {
									"minArgs": 0,
									"maxArgs": 1
								},
								"getBytesInUse": {
									"minArgs": 0,
									"maxArgs": 1
								},
								"remove": {
									"minArgs": 1,
									"maxArgs": 1
								},
								"set": {
									"minArgs": 1,
									"maxArgs": 1
								}
							},
							"managed": {
								"get": {
									"minArgs": 0,
									"maxArgs": 1
								},
								"getBytesInUse": {
									"minArgs": 0,
									"maxArgs": 1
								}
							},
							"sync": {
								"clear": {
									"minArgs": 0,
									"maxArgs": 0
								},
								"get": {
									"minArgs": 0,
									"maxArgs": 1
								},
								"getBytesInUse": {
									"minArgs": 0,
									"maxArgs": 1
								},
								"remove": {
									"minArgs": 1,
									"maxArgs": 1
								},
								"set": {
									"minArgs": 1,
									"maxArgs": 1
								}
							}
						},
						"tabs": {
							"captureVisibleTab": {
								"minArgs": 0,
								"maxArgs": 2
							},
							"create": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"detectLanguage": {
								"minArgs": 0,
								"maxArgs": 1
							},
							"discard": {
								"minArgs": 0,
								"maxArgs": 1
							},
							"duplicate": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"executeScript": {
								"minArgs": 1,
								"maxArgs": 2
							},
							"get": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"getCurrent": {
								"minArgs": 0,
								"maxArgs": 0
							},
							"getZoom": {
								"minArgs": 0,
								"maxArgs": 1
							},
							"getZoomSettings": {
								"minArgs": 0,
								"maxArgs": 1
							},
							"goBack": {
								"minArgs": 0,
								"maxArgs": 1
							},
							"goForward": {
								"minArgs": 0,
								"maxArgs": 1
							},
							"highlight": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"insertCSS": {
								"minArgs": 1,
								"maxArgs": 2
							},
							"move": {
								"minArgs": 2,
								"maxArgs": 2
							},
							"query": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"reload": {
								"minArgs": 0,
								"maxArgs": 2
							},
							"remove": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"removeCSS": {
								"minArgs": 1,
								"maxArgs": 2
							},
							"sendMessage": {
								"minArgs": 2,
								"maxArgs": 3
							},
							"setZoom": {
								"minArgs": 1,
								"maxArgs": 2
							},
							"setZoomSettings": {
								"minArgs": 1,
								"maxArgs": 2
							},
							"update": {
								"minArgs": 1,
								"maxArgs": 2
							}
						},
						"topSites": { "get": {
							"minArgs": 0,
							"maxArgs": 0
						} },
						"webNavigation": {
							"getAllFrames": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"getFrame": {
								"minArgs": 1,
								"maxArgs": 1
							}
						},
						"webRequest": { "handlerBehaviorChanged": {
							"minArgs": 0,
							"maxArgs": 0
						} },
						"windows": {
							"create": {
								"minArgs": 0,
								"maxArgs": 1
							},
							"get": {
								"minArgs": 1,
								"maxArgs": 2
							},
							"getAll": {
								"minArgs": 0,
								"maxArgs": 1
							},
							"getCurrent": {
								"minArgs": 0,
								"maxArgs": 1
							},
							"getLastFocused": {
								"minArgs": 0,
								"maxArgs": 1
							},
							"remove": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"update": {
								"minArgs": 2,
								"maxArgs": 2
							}
						}
					};
					if (Object.keys(apiMetadata).length === 0) throw new Error("api-metadata.json has not been included in browser-polyfill");
					/**
					* A WeakMap subclass which creates and stores a value for any key which does
					* not exist when accessed, but behaves exactly as an ordinary WeakMap
					* otherwise.
					*
					* @param {function} createItem
					*        A function which will be called in order to create the value for any
					*        key which does not exist, the first time it is accessed. The
					*        function receives, as its only argument, the key being created.
					*/
					class DefaultWeakMap extends WeakMap {
						constructor(createItem, items = void 0) {
							super(items);
							this.createItem = createItem;
						}
						get(key) {
							if (!this.has(key)) this.set(key, this.createItem(key));
							return super.get(key);
						}
					}
					/**
					* Returns true if the given object is an object with a `then` method, and can
					* therefore be assumed to behave as a Promise.
					*
					* @param {*} value The value to test.
					* @returns {boolean} True if the value is thenable.
					*/
					const isThenable = (value) => {
						return value && typeof value === "object" && typeof value.then === "function";
					};
					/**
					* Creates and returns a function which, when called, will resolve or reject
					* the given promise based on how it is called:
					*
					* - If, when called, `chrome.runtime.lastError` contains a non-null object,
					*   the promise is rejected with that value.
					* - If the function is called with exactly one argument, the promise is
					*   resolved to that value.
					* - Otherwise, the promise is resolved to an array containing all of the
					*   function's arguments.
					*
					* @param {object} promise
					*        An object containing the resolution and rejection functions of a
					*        promise.
					* @param {function} promise.resolve
					*        The promise's resolution function.
					* @param {function} promise.reject
					*        The promise's rejection function.
					* @param {object} metadata
					*        Metadata about the wrapped method which has created the callback.
					* @param {boolean} metadata.singleCallbackArg
					*        Whether or not the promise is resolved with only the first
					*        argument of the callback, alternatively an array of all the
					*        callback arguments is resolved. By default, if the callback
					*        function is invoked with only a single argument, that will be
					*        resolved to the promise, while all arguments will be resolved as
					*        an array if multiple are given.
					*
					* @returns {function}
					*        The generated callback function.
					*/
					const makeCallback = (promise, metadata) => {
						return (...callbackArgs) => {
							if (extensionAPIs.runtime.lastError) promise.reject(new Error(extensionAPIs.runtime.lastError.message));
							else if (metadata.singleCallbackArg || callbackArgs.length <= 1 && metadata.singleCallbackArg !== false) promise.resolve(callbackArgs[0]);
							else promise.resolve(callbackArgs);
						};
					};
					const pluralizeArguments = (numArgs) => numArgs == 1 ? "argument" : "arguments";
					/**
					* Creates a wrapper function for a method with the given name and metadata.
					*
					* @param {string} name
					*        The name of the method which is being wrapped.
					* @param {object} metadata
					*        Metadata about the method being wrapped.
					* @param {integer} metadata.minArgs
					*        The minimum number of arguments which must be passed to the
					*        function. If called with fewer than this number of arguments, the
					*        wrapper will raise an exception.
					* @param {integer} metadata.maxArgs
					*        The maximum number of arguments which may be passed to the
					*        function. If called with more than this number of arguments, the
					*        wrapper will raise an exception.
					* @param {boolean} metadata.singleCallbackArg
					*        Whether or not the promise is resolved with only the first
					*        argument of the callback, alternatively an array of all the
					*        callback arguments is resolved. By default, if the callback
					*        function is invoked with only a single argument, that will be
					*        resolved to the promise, while all arguments will be resolved as
					*        an array if multiple are given.
					*
					* @returns {function(object, ...*)}
					*       The generated wrapper function.
					*/
					const wrapAsyncFunction = (name, metadata) => {
						return function asyncFunctionWrapper(target, ...args) {
							if (args.length < metadata.minArgs) throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
							if (args.length > metadata.maxArgs) throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
							return new Promise((resolve, reject) => {
								if (metadata.fallbackToNoCallback) try {
									target[name](...args, makeCallback({
										resolve,
										reject
									}, metadata));
								} catch (cbError) {
									console.warn(`${name} API method doesn't seem to support the callback parameter, falling back to call it without a callback: `, cbError);
									target[name](...args);
									metadata.fallbackToNoCallback = false;
									metadata.noCallback = true;
									resolve();
								}
								else if (metadata.noCallback) {
									target[name](...args);
									resolve();
								} else target[name](...args, makeCallback({
									resolve,
									reject
								}, metadata));
							});
						};
					};
					/**
					* Wraps an existing method of the target object, so that calls to it are
					* intercepted by the given wrapper function. The wrapper function receives,
					* as its first argument, the original `target` object, followed by each of
					* the arguments passed to the original method.
					*
					* @param {object} target
					*        The original target object that the wrapped method belongs to.
					* @param {function} method
					*        The method being wrapped. This is used as the target of the Proxy
					*        object which is created to wrap the method.
					* @param {function} wrapper
					*        The wrapper function which is called in place of a direct invocation
					*        of the wrapped method.
					*
					* @returns {Proxy<function>}
					*        A Proxy object for the given method, which invokes the given wrapper
					*        method in its place.
					*/
					const wrapMethod = (target, method, wrapper) => {
						return new Proxy(method, { apply(targetMethod, thisObj, args) {
							return wrapper.call(thisObj, target, ...args);
						} });
					};
					let hasOwnProperty = Function.call.bind(Object.prototype.hasOwnProperty);
					/**
					* Wraps an object in a Proxy which intercepts and wraps certain methods
					* based on the given `wrappers` and `metadata` objects.
					*
					* @param {object} target
					*        The target object to wrap.
					*
					* @param {object} [wrappers = {}]
					*        An object tree containing wrapper functions for special cases. Any
					*        function present in this object tree is called in place of the
					*        method in the same location in the `target` object tree. These
					*        wrapper methods are invoked as described in {@see wrapMethod}.
					*
					* @param {object} [metadata = {}]
					*        An object tree containing metadata used to automatically generate
					*        Promise-based wrapper functions for asynchronous. Any function in
					*        the `target` object tree which has a corresponding metadata object
					*        in the same location in the `metadata` tree is replaced with an
					*        automatically-generated wrapper function, as described in
					*        {@see wrapAsyncFunction}
					*
					* @returns {Proxy<object>}
					*/
					const wrapObject = (target, wrappers = {}, metadata = {}) => {
						let cache = Object.create(null);
						return new Proxy(Object.create(target), {
							has(proxyTarget, prop) {
								return prop in target || prop in cache;
							},
							get(proxyTarget, prop, receiver) {
								if (prop in cache) return cache[prop];
								if (!(prop in target)) return;
								let value = target[prop];
								if (typeof value === "function") if (typeof wrappers[prop] === "function") value = wrapMethod(target, target[prop], wrappers[prop]);
								else if (hasOwnProperty(metadata, prop)) {
									let wrapper = wrapAsyncFunction(prop, metadata[prop]);
									value = wrapMethod(target, target[prop], wrapper);
								} else value = value.bind(target);
								else if (typeof value === "object" && value !== null && (hasOwnProperty(wrappers, prop) || hasOwnProperty(metadata, prop))) value = wrapObject(value, wrappers[prop], metadata[prop]);
								else if (hasOwnProperty(metadata, "*")) value = wrapObject(value, wrappers[prop], metadata["*"]);
								else {
									Object.defineProperty(cache, prop, {
										configurable: true,
										enumerable: true,
										get() {
											return target[prop];
										},
										set(value) {
											target[prop] = value;
										}
									});
									return value;
								}
								cache[prop] = value;
								return value;
							},
							set(proxyTarget, prop, value, receiver) {
								if (prop in cache) cache[prop] = value;
								else target[prop] = value;
								return true;
							},
							defineProperty(proxyTarget, prop, desc) {
								return Reflect.defineProperty(cache, prop, desc);
							},
							deleteProperty(proxyTarget, prop) {
								return Reflect.deleteProperty(cache, prop);
							}
						});
					};
					/**
					* Creates a set of wrapper functions for an event object, which handles
					* wrapping of listener functions that those messages are passed.
					*
					* A single wrapper is created for each listener function, and stored in a
					* map. Subsequent calls to `addListener`, `hasListener`, or `removeListener`
					* retrieve the original wrapper, so that  attempts to remove a
					* previously-added listener work as expected.
					*
					* @param {DefaultWeakMap<function, function>} wrapperMap
					*        A DefaultWeakMap object which will create the appropriate wrapper
					*        for a given listener function when one does not exist, and retrieve
					*        an existing one when it does.
					*
					* @returns {object}
					*/
					const wrapEvent = (wrapperMap) => ({
						addListener(target, listener, ...args) {
							target.addListener(wrapperMap.get(listener), ...args);
						},
						hasListener(target, listener) {
							return target.hasListener(wrapperMap.get(listener));
						},
						removeListener(target, listener) {
							target.removeListener(wrapperMap.get(listener));
						}
					});
					const onRequestFinishedWrappers = new DefaultWeakMap((listener) => {
						if (typeof listener !== "function") return listener;
						/**
						* Wraps an onRequestFinished listener function so that it will return a
						* `getContent()` property which returns a `Promise` rather than using a
						* callback API.
						*
						* @param {object} req
						*        The HAR entry object representing the network request.
						*/
						return function onRequestFinished(req) {
							listener(wrapObject(req, {}, { getContent: {
								minArgs: 0,
								maxArgs: 0
							} }));
						};
					});
					const onMessageWrappers = new DefaultWeakMap((listener) => {
						if (typeof listener !== "function") return listener;
						/**
						* Wraps a message listener function so that it may send responses based on
						* its return value, rather than by returning a sentinel value and calling a
						* callback. If the listener function returns a Promise, the response is
						* sent when the promise either resolves or rejects.
						*
						* @param {*} message
						*        The message sent by the other end of the channel.
						* @param {object} sender
						*        Details about the sender of the message.
						* @param {function(*)} sendResponse
						*        A callback which, when called with an arbitrary argument, sends
						*        that value as a response.
						* @returns {boolean}
						*        True if the wrapped listener returned a Promise, which will later
						*        yield a response. False otherwise.
						*/
						return function onMessage(message, sender, sendResponse) {
							let didCallSendResponse = false;
							let wrappedSendResponse;
							let sendResponsePromise = new Promise((resolve) => {
								wrappedSendResponse = function(response) {
									didCallSendResponse = true;
									resolve(response);
								};
							});
							let result;
							try {
								result = listener(message, sender, wrappedSendResponse);
							} catch (err) {
								result = Promise.reject(err);
							}
							const isResultThenable = result !== true && isThenable(result);
							if (result !== true && !isResultThenable && !didCallSendResponse) return false;
							const sendPromisedResult = (promise) => {
								promise.then((msg) => {
									sendResponse(msg);
								}, (error) => {
									let message;
									if (error && (error instanceof Error || typeof error.message === "string")) message = error.message;
									else message = "An unexpected error occurred";
									sendResponse({
										__mozWebExtensionPolyfillReject__: true,
										message
									});
								}).catch((err) => {
									console.error("Failed to send onMessage rejected reply", err);
								});
							};
							if (isResultThenable) sendPromisedResult(result);
							else sendPromisedResult(sendResponsePromise);
							return true;
						};
					});
					const wrappedSendMessageCallback = ({ reject, resolve }, reply) => {
						if (extensionAPIs.runtime.lastError) if (extensionAPIs.runtime.lastError.message === CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE) resolve();
						else reject(new Error(extensionAPIs.runtime.lastError.message));
						else if (reply && reply.__mozWebExtensionPolyfillReject__) reject(new Error(reply.message));
						else resolve(reply);
					};
					const wrappedSendMessage = (name, metadata, apiNamespaceObj, ...args) => {
						if (args.length < metadata.minArgs) throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
						if (args.length > metadata.maxArgs) throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
						return new Promise((resolve, reject) => {
							const wrappedCb = wrappedSendMessageCallback.bind(null, {
								resolve,
								reject
							});
							args.push(wrappedCb);
							apiNamespaceObj.sendMessage(...args);
						});
					};
					const staticWrappers = {
						devtools: { network: { onRequestFinished: wrapEvent(onRequestFinishedWrappers) } },
						runtime: {
							onMessage: wrapEvent(onMessageWrappers),
							onMessageExternal: wrapEvent(onMessageWrappers),
							sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
								minArgs: 1,
								maxArgs: 3
							})
						},
						tabs: { sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
							minArgs: 2,
							maxArgs: 3
						}) }
					};
					const settingMetadata = {
						clear: {
							minArgs: 1,
							maxArgs: 1
						},
						get: {
							minArgs: 1,
							maxArgs: 1
						},
						set: {
							minArgs: 1,
							maxArgs: 1
						}
					};
					apiMetadata.privacy = {
						network: { "*": settingMetadata },
						services: { "*": settingMetadata },
						websites: { "*": settingMetadata }
					};
					return wrapObject(extensionAPIs, staticWrappers, apiMetadata);
				};
				module$1.exports = wrapAPIs(chrome);
			} else module$1.exports = globalThis.browser;
		});
	})))());
	var emoji_default = {
		"😀": {
			"name": "grinning face",
			"slug": "grinning_face",
			"group": "Smileys & Emotion",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"grinning_face",
				"face",
				"smile",
				"happy",
				"joy",
				":D",
				"grin",
				"smiley"
			]
		},
		"😃": {
			"name": "grinning face with big eyes",
			"slug": "grinning_face_with_big_eyes",
			"group": "Smileys & Emotion",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"grinning_face_with_big_eyes",
				"face",
				"happy",
				"joy",
				"haha",
				":D",
				":)",
				"smile",
				"funny",
				"mouth",
				"open",
				"smiley",
				"smiling"
			]
		},
		"😄": {
			"name": "grinning face with smiling eyes",
			"slug": "grinning_face_with_smiling_eyes",
			"group": "Smileys & Emotion",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"grinning_face_with_smiling_eyes",
				"face",
				"happy",
				"joy",
				"funny",
				"haha",
				"laugh",
				"like",
				":D",
				":)",
				"smile",
				"eye",
				"grin",
				"mouth",
				"open",
				"pleased",
				"smiley"
			]
		},
		"😁": {
			"name": "beaming face with smiling eyes",
			"slug": "beaming_face_with_smiling_eyes",
			"group": "Smileys & Emotion",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"beaming_face_with_smiling_eyes",
				"face",
				"happy",
				"smile",
				"joy",
				"kawaii",
				"eye",
				"grin",
				"grinning"
			]
		},
		"😆": {
			"name": "grinning squinting face",
			"slug": "grinning_squinting_face",
			"group": "Smileys & Emotion",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"grinning_squinting_face",
				"happy",
				"joy",
				"lol",
				"satisfied",
				"haha",
				"face",
				"glad",
				"XD",
				"laugh",
				"big",
				"closed",
				"eyes",
				"grin",
				"laughing",
				"mouth",
				"open",
				"smile",
				"smiling",
				"tightly"
			]
		},
		"😅": {
			"name": "grinning face with sweat",
			"slug": "grinning_face_with_sweat",
			"group": "Smileys & Emotion",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"grinning_face_with_sweat",
				"face",
				"hot",
				"happy",
				"laugh",
				"sweat",
				"smile",
				"relief",
				"cold",
				"exercise",
				"mouth",
				"open",
				"smiling"
			]
		},
		"🤣": {
			"name": "rolling on the floor laughing",
			"slug": "rolling_on_the_floor_laughing",
			"group": "Smileys & Emotion",
			"emoji_version": "3.0",
			"unicode_version": "3.0",
			"skin_tone_support": false,
			"aliases": [
				"rolling_on_the_floor_laughing",
				"face",
				"rolling",
				"floor",
				"laughing",
				"lol",
				"haha",
				"rofl",
				"laugh",
				"rotfl"
			]
		},
		"😂": {
			"name": "face with tears of joy",
			"slug": "face_with_tears_of_joy",
			"group": "Smileys & Emotion",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"face_with_tears_of_joy",
				"face",
				"cry",
				"tears",
				"weep",
				"happy",
				"happytears",
				"haha",
				"crying",
				"laugh",
				"laughing",
				"lol",
				"tear"
			]
		},
		"🙂": {
			"name": "slightly smiling face",
			"slug": "slightly_smiling_face",
			"group": "Smileys & Emotion",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"slightly_smiling_face",
				"face",
				"smile",
				"fine",
				"happy",
				"this"
			]
		},
		"🙃": {
			"name": "upside-down face",
			"slug": "upside_down_face",
			"group": "Smileys & Emotion",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"upside_down_face",
				"face",
				"flipped",
				"silly",
				"smile",
				"sarcasm"
			]
		},
		"🫠": {
			"name": "melting face",
			"slug": "melting_face",
			"group": "Smileys & Emotion",
			"emoji_version": "14.0",
			"unicode_version": "14.0",
			"skin_tone_support": false,
			"aliases": [
				"melting face",
				"hot",
				"heat",
				"disappear",
				"dissolve",
				"dread",
				"liquid",
				"melt",
				"sarcasm"
			]
		},
		"😉": {
			"name": "winking face",
			"slug": "winking_face",
			"group": "Smileys & Emotion",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"winking_face",
				"face",
				"happy",
				"mischievous",
				"secret",
				";)",
				"smile",
				"eye",
				"flirt",
				"wink",
				"winky"
			]
		},
		"😊": {
			"name": "smiling face with smiling eyes",
			"slug": "smiling_face_with_smiling_eyes",
			"group": "Smileys & Emotion",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"smiling_face_with_smiling_eyes",
				"face",
				"smile",
				"happy",
				"flushed",
				"crush",
				"embarrassed",
				"shy",
				"joy",
				"^^",
				"blush",
				"eye",
				"proud",
				"smiley"
			]
		},
		"😇": {
			"name": "smiling face with halo",
			"slug": "smiling_face_with_halo",
			"group": "Smileys & Emotion",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"smiling_face_with_halo",
				"face",
				"angel",
				"heaven",
				"halo",
				"innocent",
				"fairy",
				"fantasy",
				"smile",
				"tale"
			]
		},
		"🥰": {
			"name": "smiling face with hearts",
			"slug": "smiling_face_with_hearts",
			"group": "Smileys & Emotion",
			"emoji_version": "11.0",
			"unicode_version": "11.0",
			"skin_tone_support": false,
			"aliases": [
				"smiling_face_with_hearts",
				"face",
				"love",
				"like",
				"affection",
				"valentines",
				"infatuation",
				"crush",
				"hearts",
				"adore",
				"eyes",
				"three"
			]
		},
		"😍": {
			"name": "smiling face with heart-eyes",
			"slug": "smiling_face_with_heart_eyes",
			"group": "Smileys & Emotion",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"smiling_face_with_heart_eyes",
				"face",
				"love",
				"like",
				"affection",
				"valentines",
				"infatuation",
				"crush",
				"heart",
				"eye",
				"shaped",
				"smile"
			]
		},
		"🤩": {
			"name": "star-struck",
			"slug": "star_struck",
			"group": "Smileys & Emotion",
			"emoji_version": "5.0",
			"unicode_version": "5.0",
			"skin_tone_support": false,
			"aliases": [
				"star_struck",
				"face",
				"smile",
				"starry",
				"eyes",
				"grinning",
				"excited",
				"eyed",
				"wow"
			]
		},
		"😘": {
			"name": "face blowing a kiss",
			"slug": "face_blowing_a_kiss",
			"group": "Smileys & Emotion",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"face_blowing_a_kiss",
				"face",
				"love",
				"like",
				"affection",
				"valentines",
				"infatuation",
				"kiss",
				"blow",
				"flirt",
				"heart",
				"kissing",
				"throwing"
			]
		},
		"😗": {
			"name": "kissing face",
			"slug": "kissing_face",
			"group": "Smileys & Emotion",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"kissing_face",
				"love",
				"like",
				"face",
				"3",
				"valentines",
				"infatuation",
				"kiss",
				"duck",
				"kissy",
				"whistling"
			]
		},
		"☺️": {
			"name": "smiling face",
			"slug": "smiling_face",
			"group": "Smileys & Emotion",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"smiling_face",
				"face",
				"blush",
				"massage",
				"happiness",
				"happy",
				"outlined",
				"pleased",
				"relaxed",
				"smile",
				"smiley",
				"white"
			]
		},
		"😚": {
			"name": "kissing face with closed eyes",
			"slug": "kissing_face_with_closed_eyes",
			"group": "Smileys & Emotion",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"kissing_face_with_closed_eyes",
				"face",
				"love",
				"like",
				"affection",
				"valentines",
				"infatuation",
				"kiss",
				"eye",
				"kissy"
			]
		},
		"😙": {
			"name": "kissing face with smiling eyes",
			"slug": "kissing_face_with_smiling_eyes",
			"group": "Smileys & Emotion",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"kissing_face_with_smiling_eyes",
				"face",
				"affection",
				"valentines",
				"infatuation",
				"kiss",
				"eye",
				"kissy",
				"smile",
				"whistle",
				"whistling"
			]
		},
		"🥲": {
			"name": "smiling face with tear",
			"slug": "smiling_face_with_tear",
			"group": "Smileys & Emotion",
			"emoji_version": "13.0",
			"unicode_version": "13.0",
			"skin_tone_support": false,
			"aliases": [
				"smiling face with tear",
				"sad",
				"cry",
				"pretend",
				"grateful",
				"happy",
				"proud",
				"relieved",
				"smile",
				"touched"
			]
		},
		"😋": {
			"name": "face savoring food",
			"slug": "face_savoring_food",
			"group": "Smileys & Emotion",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"face_savoring_food",
				"happy",
				"joy",
				"tongue",
				"smile",
				"face",
				"silly",
				"yummy",
				"nom",
				"delicious",
				"savouring",
				"goofy",
				"hungry",
				"lick",
				"licking",
				"lips",
				"smiling",
				"um",
				"yum"
			]
		},
		"😛": {
			"name": "face with tongue",
			"slug": "face_with_tongue",
			"group": "Smileys & Emotion",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"face_with_tongue",
				"face",
				"prank",
				"childish",
				"playful",
				"mischievous",
				"smile",
				"tongue",
				"cheeky",
				"out",
				"stuck"
			]
		},
		"😜": {
			"name": "winking face with tongue",
			"slug": "winking_face_with_tongue",
			"group": "Smileys & Emotion",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"winking_face_with_tongue",
				"face",
				"prank",
				"childish",
				"playful",
				"mischievous",
				"smile",
				"wink",
				"tongue",
				"crazy",
				"eye",
				"joke",
				"out",
				"silly",
				"stuck"
			]
		},
		"🤪": {
			"name": "zany face",
			"slug": "zany_face",
			"group": "Smileys & Emotion",
			"emoji_version": "5.0",
			"unicode_version": "5.0",
			"skin_tone_support": false,
			"aliases": [
				"zany_face",
				"face",
				"goofy",
				"crazy",
				"excited",
				"eye",
				"eyes",
				"grinning",
				"large",
				"one",
				"small",
				"wacky",
				"wild"
			]
		},
		"😝": {
			"name": "squinting face with tongue",
			"slug": "squinting_face_with_tongue",
			"group": "Smileys & Emotion",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"squinting_face_with_tongue",
				"face",
				"prank",
				"playful",
				"mischievous",
				"smile",
				"tongue",
				"closed",
				"eye",
				"eyes",
				"horrible",
				"out",
				"stuck",
				"taste",
				"tightly"
			]
		},
		"🤑": {
			"name": "money-mouth face",
			"slug": "money_mouth_face",
			"group": "Smileys & Emotion",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"money_mouth_face",
				"face",
				"rich",
				"dollar",
				"money",
				"eyes",
				"sign"
			]
		},
		"🤗": {
			"name": "smiling face with open hands",
			"slug": "smiling_face_with_open_hands",
			"group": "Smileys & Emotion",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"hugging_face",
				"face",
				"smile",
				"hug",
				"hands",
				"hugs",
				"open",
				"smiling"
			]
		},
		"🤭": {
			"name": "face with hand over mouth",
			"slug": "face_with_hand_over_mouth",
			"group": "Smileys & Emotion",
			"emoji_version": "5.0",
			"unicode_version": "5.0",
			"skin_tone_support": false,
			"aliases": [
				"face_with_hand_over_mouth",
				"face",
				"whoops",
				"shock",
				"surprise",
				"blushing",
				"covering",
				"eyes",
				"quiet",
				"smiling"
			]
		},
		"🫢": {
			"name": "face with open eyes and hand over mouth",
			"slug": "face_with_open_eyes_and_hand_over_mouth",
			"group": "Smileys & Emotion",
			"emoji_version": "14.0",
			"unicode_version": "14.0",
			"skin_tone_support": false,
			"aliases": [
				"face with open eyes and hand over mouth",
				"silence",
				"secret",
				"shock",
				"surprise",
				"amazement",
				"awe",
				"disbelief",
				"embarrass",
				"gasp",
				"scared"
			]
		},
		"🫣": {
			"name": "face with peeking eye",
			"slug": "face_with_peeking_eye",
			"group": "Smileys & Emotion",
			"emoji_version": "14.0",
			"unicode_version": "14.0",
			"skin_tone_support": false,
			"aliases": [
				"face with peeking eye",
				"scared",
				"frightening",
				"embarrassing",
				"shy",
				"captivated",
				"peep",
				"stare"
			]
		},
		"🤫": {
			"name": "shushing face",
			"slug": "shushing_face",
			"group": "Smileys & Emotion",
			"emoji_version": "5.0",
			"unicode_version": "5.0",
			"skin_tone_support": false,
			"aliases": [
				"shushing_face",
				"face",
				"quiet",
				"shhh",
				"closed",
				"covering",
				"finger",
				"hush",
				"lips",
				"shh",
				"shush",
				"silence"
			]
		},
		"🤔": {
			"name": "thinking face",
			"slug": "thinking_face",
			"group": "Smileys & Emotion",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"thinking_face",
				"face",
				"hmmm",
				"think",
				"consider",
				"chin",
				"shade",
				"thinker",
				"throwing",
				"thumb"
			]
		},
		"🫡": {
			"name": "saluting face",
			"slug": "saluting_face",
			"group": "Smileys & Emotion",
			"emoji_version": "14.0",
			"unicode_version": "14.0",
			"skin_tone_support": false,
			"aliases": [
				"saluting face",
				"respect",
				"salute",
				"ok",
				"sunny",
				"troops",
				"yes"
			]
		},
		"🤐": {
			"name": "zipper-mouth face",
			"slug": "zipper_mouth_face",
			"group": "Smileys & Emotion",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"zipper_mouth_face",
				"face",
				"sealed",
				"zipper",
				"secret",
				"hush",
				"lips",
				"silence",
				"zip"
			]
		},
		"🤨": {
			"name": "face with raised eyebrow",
			"slug": "face_with_raised_eyebrow",
			"group": "Smileys & Emotion",
			"emoji_version": "5.0",
			"unicode_version": "5.0",
			"skin_tone_support": false,
			"aliases": [
				"face_with_raised_eyebrow",
				"face",
				"distrust",
				"scepticism",
				"disapproval",
				"disbelief",
				"surprise",
				"suspicious",
				"colbert",
				"mild",
				"one",
				"rock",
				"skeptic"
			]
		},
		"😐": {
			"name": "neutral face",
			"slug": "neutral_face",
			"group": "Smileys & Emotion",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"neutral_face",
				"indifference",
				"meh",
				":|",
				"neutral",
				"deadpan",
				"faced",
				"mouth",
				"straight"
			]
		},
		"😑": {
			"name": "expressionless face",
			"slug": "expressionless_face",
			"group": "Smileys & Emotion",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"expressionless_face",
				"face",
				"indifferent",
				"-_-",
				"meh",
				"deadpan",
				"inexpressive",
				"mouth",
				"straight",
				"unexpressive"
			]
		},
		"😶": {
			"name": "face without mouth",
			"slug": "face_without_mouth",
			"group": "Smileys & Emotion",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"face_without_mouth",
				"face",
				"blank",
				"mouthless",
				"mute",
				"no",
				"quiet",
				"silence",
				"silent"
			]
		},
		"🫥": {
			"name": "dotted line face",
			"slug": "dotted_line_face",
			"group": "Smileys & Emotion",
			"emoji_version": "14.0",
			"unicode_version": "14.0",
			"skin_tone_support": false,
			"aliases": [
				"dotted line face",
				"invisible",
				"lonely",
				"isolation",
				"depression",
				"depressed",
				"disappear",
				"hide",
				"introvert"
			]
		},
		"😶‍🌫️": {
			"name": "face in clouds",
			"slug": "face_in_clouds",
			"group": "Smileys & Emotion",
			"emoji_version": "13.1",
			"unicode_version": "13.1",
			"skin_tone_support": false,
			"aliases": [
				"face in clouds",
				"shower",
				"steam",
				"dream",
				"absentminded",
				"brain",
				"fog",
				"forgetful",
				"haze",
				"head",
				"impractical",
				"unrealistic"
			]
		},
		"😏": {
			"name": "smirking face",
			"slug": "smirking_face",
			"group": "Smileys & Emotion",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"smirking_face",
				"face",
				"smile",
				"mean",
				"prank",
				"smug",
				"sarcasm",
				"flirting",
				"sexual",
				"smirk",
				"suggestive"
			]
		},
		"😒": {
			"name": "unamused face",
			"slug": "unamused_face",
			"group": "Smileys & Emotion",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"unamused_face",
				"indifference",
				"bored",
				"straight face",
				"serious",
				"sarcasm",
				"unimpressed",
				"skeptical",
				"dubious",
				"ugh",
				"side_eye",
				"dissatisfied",
				"meh",
				"unhappy"
			]
		},
		"🙄": {
			"name": "face with rolling eyes",
			"slug": "face_with_rolling_eyes",
			"group": "Smileys & Emotion",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"face_with_rolling_eyes",
				"face",
				"eyeroll",
				"frustrated",
				"eye",
				"roll"
			]
		},
		"😬": {
			"name": "grimacing face",
			"slug": "grimacing_face",
			"group": "Smileys & Emotion",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"grimacing_face",
				"face",
				"grimace",
				"teeth",
				"awkward",
				"eek",
				"nervous"
			]
		},
		"😮‍💨": {
			"name": "face exhaling",
			"slug": "face_exhaling",
			"group": "Smileys & Emotion",
			"emoji_version": "13.1",
			"unicode_version": "13.1",
			"skin_tone_support": false,
			"aliases": [
				"face exhaling",
				"relieve",
				"relief",
				"tired",
				"sigh",
				"exhale",
				"gasp",
				"groan",
				"whisper",
				"whistle"
			]
		},
		"🤥": {
			"name": "lying face",
			"slug": "lying_face",
			"group": "Smileys & Emotion",
			"emoji_version": "3.0",
			"unicode_version": "3.0",
			"skin_tone_support": false,
			"aliases": [
				"lying_face",
				"face",
				"lie",
				"pinocchio",
				"liar",
				"long",
				"nose"
			]
		},
		"🫨": {
			"name": "shaking face",
			"slug": "shaking_face",
			"group": "Smileys & Emotion",
			"emoji_version": "15.0",
			"unicode_version": "15.0",
			"skin_tone_support": false,
			"aliases": [
				"shaking face",
				"dizzy",
				"shock",
				"blurry",
				"earthquake"
			]
		},
		"🙂‍↔️": {
			"name": "head shaking horizontally",
			"slug": "head_shaking_horizontally",
			"group": "Smileys & Emotion",
			"emoji_version": "15.1",
			"unicode_version": "15.1",
			"skin_tone_support": false,
			"aliases": [
				"head shaking horizontally",
				"disapprove",
				"indiffernt",
				"left"
			]
		},
		"🙂‍↕️": {
			"name": "head shaking vertically",
			"slug": "head_shaking_vertically",
			"group": "Smileys & Emotion",
			"emoji_version": "15.1",
			"unicode_version": "15.1",
			"skin_tone_support": false,
			"aliases": [
				"head shaking vertically",
				"down",
				"nod"
			]
		},
		"😌": {
			"name": "relieved face",
			"slug": "relieved_face",
			"group": "Smileys & Emotion",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"relieved_face",
				"face",
				"relaxed",
				"phew",
				"massage",
				"happiness",
				"content",
				"pleased",
				"whew"
			]
		},
		"😔": {
			"name": "pensive face",
			"slug": "pensive_face",
			"group": "Smileys & Emotion",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"pensive_face",
				"face",
				"sad",
				"depressed",
				"upset",
				"dejected",
				"sadface",
				"sorrowful"
			]
		},
		"😪": {
			"name": "sleepy face",
			"slug": "sleepy_face",
			"group": "Smileys & Emotion",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"sleepy_face",
				"face",
				"tired",
				"rest",
				"nap",
				"bubble",
				"side",
				"sleep",
				"snot",
				"tear"
			]
		},
		"🤤": {
			"name": "drooling face",
			"slug": "drooling_face",
			"group": "Smileys & Emotion",
			"emoji_version": "3.0",
			"unicode_version": "3.0",
			"skin_tone_support": false,
			"aliases": [
				"drooling_face",
				"face",
				"drool"
			]
		},
		"😴": {
			"name": "sleeping face",
			"slug": "sleeping_face",
			"group": "Smileys & Emotion",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"sleeping_face",
				"face",
				"tired",
				"sleepy",
				"night",
				"zzz",
				"sleep",
				"snoring"
			]
		},
		"🫩": {
			"name": "face with bags under eyes",
			"slug": "face_with_bags_under_eyes",
			"group": "Smileys & Emotion",
			"emoji_version": "16.0",
			"unicode_version": "16.0",
			"skin_tone_support": false,
			"aliases": [
				"face with bags under eyes",
				"tired",
				"sleepy",
				"exhausted"
			]
		},
		"😷": {
			"name": "face with medical mask",
			"slug": "face_with_medical_mask",
			"group": "Smileys & Emotion",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"face_with_medical_mask",
				"face",
				"sick",
				"ill",
				"disease",
				"covid",
				"cold",
				"coronavirus",
				"doctor",
				"medicine",
				"surgical"
			]
		},
		"🤒": {
			"name": "face with thermometer",
			"slug": "face_with_thermometer",
			"group": "Smileys & Emotion",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"face_with_thermometer",
				"sick",
				"temperature",
				"thermometer",
				"cold",
				"fever",
				"covid",
				"ill"
			]
		},
		"🤕": {
			"name": "face with head-bandage",
			"slug": "face_with_head_bandage",
			"group": "Smileys & Emotion",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"face_with_head_bandage",
				"injured",
				"clumsy",
				"bandage",
				"hurt",
				"bandaged",
				"injury"
			]
		},
		"🤢": {
			"name": "nauseated face",
			"slug": "nauseated_face",
			"group": "Smileys & Emotion",
			"emoji_version": "3.0",
			"unicode_version": "3.0",
			"skin_tone_support": false,
			"aliases": [
				"nauseated_face",
				"face",
				"vomit",
				"gross",
				"green",
				"sick",
				"throw up",
				"ill",
				"barf",
				"disgust",
				"disgusted",
				"green\xA0face"
			]
		},
		"🤮": {
			"name": "face vomiting",
			"slug": "face_vomiting",
			"group": "Smileys & Emotion",
			"emoji_version": "5.0",
			"unicode_version": "5.0",
			"skin_tone_support": false,
			"aliases": [
				"face_vomiting",
				"face",
				"sick",
				"barf",
				"ill",
				"mouth",
				"open",
				"puke",
				"spew",
				"throwing",
				"up",
				"vomit"
			]
		},
		"🤧": {
			"name": "sneezing face",
			"slug": "sneezing_face",
			"group": "Smileys & Emotion",
			"emoji_version": "3.0",
			"unicode_version": "3.0",
			"skin_tone_support": false,
			"aliases": [
				"sneezing_face",
				"face",
				"gesundheit",
				"sneeze",
				"sick",
				"allergy",
				"achoo"
			]
		},
		"🥵": {
			"name": "hot face",
			"slug": "hot_face",
			"group": "Smileys & Emotion",
			"emoji_version": "11.0",
			"unicode_version": "11.0",
			"skin_tone_support": false,
			"aliases": [
				"hot_face",
				"face",
				"feverish",
				"heat",
				"red",
				"sweating",
				"overheated",
				"stroke"
			]
		},
		"🥶": {
			"name": "cold face",
			"slug": "cold_face",
			"group": "Smileys & Emotion",
			"emoji_version": "11.0",
			"unicode_version": "11.0",
			"skin_tone_support": false,
			"aliases": [
				"cold_face",
				"face",
				"blue",
				"freezing",
				"frozen",
				"frostbite",
				"icicles",
				"ice"
			]
		},
		"🥴": {
			"name": "woozy face",
			"slug": "woozy_face",
			"group": "Smileys & Emotion",
			"emoji_version": "11.0",
			"unicode_version": "11.0",
			"skin_tone_support": false,
			"aliases": [
				"woozy_face",
				"face",
				"dizzy",
				"intoxicated",
				"tipsy",
				"wavy",
				"drunk",
				"eyes",
				"groggy",
				"mouth",
				"uneven"
			]
		},
		"😵": {
			"name": "face with crossed-out eyes",
			"slug": "face_with_crossed_out_eyes",
			"group": "Smileys & Emotion",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"dizzy_face",
				"spent",
				"unconscious",
				"xox",
				"dizzy",
				"cross",
				"crossed",
				"dead",
				"eyes",
				"knocked",
				"out",
				"spiral\xA0eyes"
			]
		},
		"😵‍💫": {
			"name": "face with spiral eyes",
			"slug": "face_with_spiral_eyes",
			"group": "Smileys & Emotion",
			"emoji_version": "13.1",
			"unicode_version": "13.1",
			"skin_tone_support": false,
			"aliases": [
				"face with spiral eyes",
				"sick",
				"ill",
				"confused",
				"nauseous",
				"nausea",
				"dizzy",
				"hypnotized",
				"trouble",
				"whoa"
			]
		},
		"🤯": {
			"name": "exploding head",
			"slug": "exploding_head",
			"group": "Smileys & Emotion",
			"emoji_version": "5.0",
			"unicode_version": "5.0",
			"skin_tone_support": false,
			"aliases": [
				"exploding_head",
				"face",
				"shocked",
				"mind",
				"blown",
				"blowing",
				"explosion",
				"mad"
			]
		},
		"🤠": {
			"name": "cowboy hat face",
			"slug": "cowboy_hat_face",
			"group": "Smileys & Emotion",
			"emoji_version": "3.0",
			"unicode_version": "3.0",
			"skin_tone_support": false,
			"aliases": [
				"cowboy_hat_face",
				"face",
				"cowgirl",
				"hat"
			]
		},
		"🥳": {
			"name": "partying face",
			"slug": "partying_face",
			"group": "Smileys & Emotion",
			"emoji_version": "11.0",
			"unicode_version": "11.0",
			"skin_tone_support": false,
			"aliases": [
				"partying_face",
				"face",
				"celebration",
				"woohoo",
				"birthday",
				"hat",
				"horn",
				"party"
			]
		},
		"🥸": {
			"name": "disguised face",
			"slug": "disguised_face",
			"group": "Smileys & Emotion",
			"emoji_version": "13.0",
			"unicode_version": "13.0",
			"skin_tone_support": false,
			"aliases": [
				"disguised face",
				"pretent",
				"brows",
				"glasses",
				"moustache",
				"disguise",
				"incognito",
				"nose"
			]
		},
		"😎": {
			"name": "smiling face with sunglasses",
			"slug": "smiling_face_with_sunglasses",
			"group": "Smileys & Emotion",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"smiling_face_with_sunglasses",
				"face",
				"cool",
				"smile",
				"summer",
				"beach",
				"sunglass",
				"best",
				"bright",
				"eye",
				"eyewear",
				"friends",
				"glasses",
				"mutual",
				"snapchat",
				"sun",
				"weather"
			]
		},
		"🤓": {
			"name": "nerd face",
			"slug": "nerd_face",
			"group": "Smileys & Emotion",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"nerd_face",
				"face",
				"nerdy",
				"geek",
				"dork",
				"glasses",
				"smiling"
			]
		},
		"🧐": {
			"name": "face with monocle",
			"slug": "face_with_monocle",
			"group": "Smileys & Emotion",
			"emoji_version": "5.0",
			"unicode_version": "5.0",
			"skin_tone_support": false,
			"aliases": [
				"face_with_monocle",
				"face",
				"stuffy",
				"wealthy",
				"rich",
				"exploration",
				"inspection"
			]
		},
		"😕": {
			"name": "confused face",
			"slug": "confused_face",
			"group": "Smileys & Emotion",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"confused_face",
				"face",
				"indifference",
				"huh",
				"weird",
				"hmmm",
				":/",
				"meh",
				"nonplussed",
				"puzzled",
				"s"
			]
		},
		"🫤": {
			"name": "face with diagonal mouth",
			"slug": "face_with_diagonal_mouth",
			"group": "Smileys & Emotion",
			"emoji_version": "14.0",
			"unicode_version": "14.0",
			"skin_tone_support": false,
			"aliases": [
				"face with diagonal mouth",
				"skeptic",
				"confuse",
				"frustrated",
				"indifferent",
				"confused",
				"disappointed",
				"meh",
				"skeptical",
				"unsure"
			]
		},
		"😟": {
			"name": "worried face",
			"slug": "worried_face",
			"group": "Smileys & Emotion",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"worried_face",
				"face",
				"concern",
				"nervous",
				":(",
				"sad",
				"sadface"
			]
		},
		"🙁": {
			"name": "slightly frowning face",
			"slug": "slightly_frowning_face",
			"group": "Smileys & Emotion",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"slightly_frowning_face",
				"face",
				"frowning",
				"disappointed",
				"sad",
				"upset",
				"frown",
				"unhappy"
			]
		},
		"☹️": {
			"name": "frowning face",
			"slug": "frowning_face",
			"group": "Smileys & Emotion",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"frowning_face",
				"face",
				"sad",
				"upset",
				"frown",
				"megafrown",
				"unhappy",
				"white"
			]
		},
		"😮": {
			"name": "face with open mouth",
			"slug": "face_with_open_mouth",
			"group": "Smileys & Emotion",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"face_with_open_mouth",
				"face",
				"surprise",
				"impressed",
				"wow",
				"whoa",
				":O",
				"surprised",
				"sympathy"
			]
		},
		"😯": {
			"name": "hushed face",
			"slug": "hushed_face",
			"group": "Smileys & Emotion",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"hushed_face",
				"face",
				"woo",
				"shh",
				"silence",
				"speechless",
				"stunned",
				"surprise",
				"surprised"
			]
		},
		"😲": {
			"name": "astonished face",
			"slug": "astonished_face",
			"group": "Smileys & Emotion",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"astonished_face",
				"face",
				"xox",
				"surprised",
				"poisoned",
				"amazed",
				"drunk\xA0face",
				"gasp",
				"gasping",
				"shocked",
				"totally"
			]
		},
		"😳": {
			"name": "flushed face",
			"slug": "flushed_face",
			"group": "Smileys & Emotion",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"flushed_face",
				"face",
				"blush",
				"shy",
				"flattered",
				"blushing",
				"dazed",
				"embarrassed",
				"eyes",
				"open",
				"shame",
				"wide"
			]
		},
		"🫪": {
			"name": "distorted face",
			"slug": "distorted_face",
			"group": "Smileys & Emotion",
			"emoji_version": "17.0",
			"unicode_version": "17.0",
			"skin_tone_support": false,
			"aliases": [
				"distorted face",
				"surprised",
				"fluttered",
				"wide-eyed"
			]
		},
		"🥺": {
			"name": "pleading face",
			"slug": "pleading_face",
			"group": "Smileys & Emotion",
			"emoji_version": "11.0",
			"unicode_version": "11.0",
			"skin_tone_support": false,
			"aliases": [
				"pleading_face",
				"face",
				"begging",
				"mercy",
				"cry",
				"tears",
				"sad",
				"grievance",
				"eyes",
				"glossy",
				"puppy",
				"simp"
			]
		},
		"🥹": {
			"name": "face holding back tears",
			"slug": "face_holding_back_tears",
			"group": "Smileys & Emotion",
			"emoji_version": "14.0",
			"unicode_version": "14.0",
			"skin_tone_support": false,
			"aliases": [
				"face holding back tears",
				"touched",
				"gratitude",
				"cry",
				"angry",
				"proud",
				"resist",
				"sad"
			]
		},
		"😦": {
			"name": "frowning face with open mouth",
			"slug": "frowning_face_with_open_mouth",
			"group": "Smileys & Emotion",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"frowning_face_with_open_mouth",
				"face",
				"aw",
				"what",
				"frown",
				"yawning"
			]
		},
		"😧": {
			"name": "anguished face",
			"slug": "anguished_face",
			"group": "Smileys & Emotion",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"anguished_face",
				"face",
				"stunned",
				"nervous",
				"pained"
			]
		},
		"😨": {
			"name": "fearful face",
			"slug": "fearful_face",
			"group": "Smileys & Emotion",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"fearful_face",
				"face",
				"scared",
				"terrified",
				"nervous",
				"fear",
				"oops",
				"shocked",
				"surprised"
			]
		},
		"😰": {
			"name": "anxious face with sweat",
			"slug": "anxious_face_with_sweat",
			"group": "Smileys & Emotion",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"anxious_face_with_sweat",
				"face",
				"nervous",
				"sweat",
				"blue",
				"cold",
				"concerned\xA0face",
				"mouth",
				"open",
				"rushed"
			]
		},
		"😥": {
			"name": "sad but relieved face",
			"slug": "sad_but_relieved_face",
			"group": "Smileys & Emotion",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"sad_but_relieved_face",
				"face",
				"phew",
				"sweat",
				"nervous",
				"disappointed",
				"eyebrow",
				"whew"
			]
		},
		"😢": {
			"name": "crying face",
			"slug": "crying_face",
			"group": "Smileys & Emotion",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"crying_face",
				"face",
				"tears",
				"sad",
				"depressed",
				"upset",
				":'(",
				"cry",
				"tear"
			]
		},
		"😭": {
			"name": "loudly crying face",
			"slug": "loudly_crying_face",
			"group": "Smileys & Emotion",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"loudly_crying_face",
				"sobbing",
				"face",
				"cry",
				"tears",
				"sad",
				"upset",
				"depressed",
				"bawling",
				"sob",
				"tear"
			]
		},
		"😱": {
			"name": "face screaming in fear",
			"slug": "face_screaming_in_fear",
			"group": "Smileys & Emotion",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"face_screaming_in_fear",
				"face",
				"munch",
				"scared",
				"omg",
				"alone",
				"fearful",
				"home",
				"horror",
				"scream",
				"shocked"
			]
		},
		"😖": {
			"name": "confounded face",
			"slug": "confounded_face",
			"group": "Smileys & Emotion",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"confounded_face",
				"face",
				"confused",
				"sick",
				"unwell",
				"oops",
				":S",
				"mouth",
				"quivering",
				"scrunched"
			]
		},
		"😣": {
			"name": "persevering face",
			"slug": "persevering_face",
			"group": "Smileys & Emotion",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"persevering_face",
				"face",
				"sick",
				"no",
				"upset",
				"oops",
				"eyes",
				"helpless",
				"persevere",
				"scrunched",
				"struggling"
			]
		},
		"😞": {
			"name": "disappointed face",
			"slug": "disappointed_face",
			"group": "Smileys & Emotion",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"disappointed_face",
				"face",
				"sad",
				"upset",
				"depressed",
				":(",
				"sadface"
			]
		},
		"😓": {
			"name": "downcast face with sweat",
			"slug": "downcast_face_with_sweat",
			"group": "Smileys & Emotion",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"downcast_face_with_sweat",
				"face",
				"hot",
				"sad",
				"tired",
				"exercise",
				"cold",
				"hard",
				"work"
			]
		},
		"😩": {
			"name": "weary face",
			"slug": "weary_face",
			"group": "Smileys & Emotion",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"weary_face",
				"face",
				"tired",
				"sleepy",
				"sad",
				"frustrated",
				"upset",
				"distraught",
				"wailing"
			]
		},
		"😫": {
			"name": "tired face",
			"slug": "tired_face",
			"group": "Smileys & Emotion",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"tired_face",
				"sick",
				"whine",
				"upset",
				"frustrated",
				"distraught",
				"exhausted",
				"fed",
				"up"
			]
		},
		"🥱": {
			"name": "yawning face",
			"slug": "yawning_face",
			"group": "Smileys & Emotion",
			"emoji_version": "12.0",
			"unicode_version": "12.0",
			"skin_tone_support": false,
			"aliases": [
				"yawning_face",
				"tired",
				"sleepy",
				"bored",
				"yawn"
			]
		},
		"😤": {
			"name": "face with steam from nose",
			"slug": "face_with_steam_from_nose",
			"group": "Smileys & Emotion",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"face_with_steam_from_nose",
				"face",
				"gas",
				"phew",
				"proud",
				"pride",
				"triumph",
				"airing",
				"frustrated",
				"grievances",
				"look",
				"mad",
				"smug",
				"steaming",
				"won"
			]
		},
		"😡": {
			"name": "enraged face",
			"slug": "enraged_face",
			"group": "Smileys & Emotion",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"pouting_face",
				"angry",
				"mad",
				"hate",
				"despise",
				"enraged",
				"grumpy",
				"pout",
				"rage",
				"red"
			]
		},
		"😠": {
			"name": "angry face",
			"slug": "angry_face",
			"group": "Smileys & Emotion",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"angry_face",
				"mad",
				"face",
				"annoyed",
				"frustrated",
				"anger",
				"grumpy"
			]
		},
		"🤬": {
			"name": "face with symbols on mouth",
			"slug": "face_with_symbols_on_mouth",
			"group": "Smileys & Emotion",
			"emoji_version": "5.0",
			"unicode_version": "5.0",
			"skin_tone_support": false,
			"aliases": [
				"face_with_symbols_on_mouth",
				"face",
				"swearing",
				"cursing",
				"cussing",
				"profanity",
				"expletive",
				"covering",
				"foul",
				"grawlix",
				"over",
				"serious"
			]
		},
		"😈": {
			"name": "smiling face with horns",
			"slug": "smiling_face_with_horns",
			"group": "Smileys & Emotion",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"smiling_face_with_horns",
				"devil",
				"horns",
				"evil",
				"fairy",
				"fantasy",
				"happy",
				"imp",
				"purple",
				"red\xA0devil",
				"smile",
				"tale"
			]
		},
		"👿": {
			"name": "angry face with horns",
			"slug": "angry_face_with_horns",
			"group": "Smileys & Emotion",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"angry_face_with_horns",
				"devil",
				"angry",
				"horns",
				"demon",
				"evil",
				"fairy",
				"fantasy",
				"goblin",
				"imp",
				"purple",
				"sad",
				"tale"
			]
		},
		"💀": {
			"name": "skull",
			"slug": "skull",
			"group": "Smileys & Emotion",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"skull",
				"dead",
				"skeleton",
				"creepy",
				"death",
				"dead",
				"body",
				"danger",
				"face",
				"fairy",
				"grey",
				"halloween",
				"monster",
				"poison",
				"tale"
			]
		},
		"☠️": {
			"name": "skull and crossbones",
			"slug": "skull_and_crossbones",
			"group": "Smileys & Emotion",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"skull_and_crossbones",
				"poison",
				"danger",
				"deadly",
				"scary",
				"death",
				"pirate",
				"evil",
				"body",
				"face",
				"halloween",
				"monster"
			]
		},
		"💩": {
			"name": "pile of poo",
			"slug": "pile_of_poo",
			"group": "Smileys & Emotion",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"pile_of_poo",
				"hankey",
				"shitface",
				"fail",
				"turd",
				"shit",
				"comic",
				"crap",
				"dirt",
				"dog",
				"dung",
				"face",
				"monster",
				"poop",
				"smiling",
				"bad",
				"needs_improvement"
			]
		},
		"🤡": {
			"name": "clown face",
			"slug": "clown_face",
			"group": "Smileys & Emotion",
			"emoji_version": "3.0",
			"unicode_version": "3.0",
			"skin_tone_support": false,
			"aliases": [
				"clown_face",
				"face",
				"mock"
			]
		},
		"👹": {
			"name": "ogre",
			"slug": "ogre",
			"group": "Smileys & Emotion",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"ogre",
				"monster",
				"red",
				"mask",
				"halloween",
				"scary",
				"creepy",
				"devil",
				"demon",
				"japanese_ogre",
				"creature",
				"face",
				"fairy",
				"fantasy",
				"oni",
				"tale",
				"shrek"
			]
		},
		"👺": {
			"name": "goblin",
			"slug": "goblin",
			"group": "Smileys & Emotion",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"goblin",
				"red",
				"evil",
				"mask",
				"monster",
				"scary",
				"creepy",
				"japanese_goblin",
				"creature",
				"face",
				"fairy",
				"fantasy",
				"long",
				"nose",
				"tale",
				"tengu"
			]
		},
		"👻": {
			"name": "ghost",
			"slug": "ghost",
			"group": "Smileys & Emotion",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"ghost",
				"halloween",
				"spooky",
				"scary",
				"creature",
				"disappear",
				"face",
				"fairy",
				"fantasy",
				"ghoul",
				"monster",
				"tale"
			]
		},
		"👽": {
			"name": "alien",
			"slug": "alien",
			"group": "Smileys & Emotion",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"alien",
				"UFO",
				"paul",
				"weird",
				"outer_space",
				"creature",
				"et",
				"extraterrestrial",
				"face",
				"fairy",
				"fantasy",
				"monster",
				"tale",
				"external"
			]
		},
		"👾": {
			"name": "alien monster",
			"slug": "alien_monster",
			"group": "Smileys & Emotion",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"alien_monster",
				"game",
				"arcade",
				"play",
				"creature",
				"extraterrestrial",
				"face",
				"fairy",
				"fantasy",
				"invader",
				"retro",
				"space",
				"tale",
				"ufo",
				"video"
			]
		},
		"🤖": {
			"name": "robot",
			"slug": "robot",
			"group": "Smileys & Emotion",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"robot",
				"computer",
				"machine",
				"bot",
				"face",
				"monster"
			]
		},
		"😺": {
			"name": "grinning cat",
			"slug": "grinning_cat",
			"group": "Smileys & Emotion",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"grinning_cat",
				"animal",
				"cats",
				"happy",
				"smile",
				"face",
				"mouth",
				"open",
				"smiley",
				"smiling"
			]
		},
		"😸": {
			"name": "grinning cat with smiling eyes",
			"slug": "grinning_cat_with_smiling_eyes",
			"group": "Smileys & Emotion",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"grinning_cat_with_smiling_eyes",
				"animal",
				"cats",
				"smile",
				"eye",
				"face",
				"grin",
				"happy"
			]
		},
		"😹": {
			"name": "cat with tears of joy",
			"slug": "cat_with_tears_of_joy",
			"group": "Smileys & Emotion",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"cat_with_tears_of_joy",
				"animal",
				"cats",
				"haha",
				"happy",
				"tears",
				"face",
				"laughing",
				"tear"
			]
		},
		"😻": {
			"name": "smiling cat with heart-eyes",
			"slug": "smiling_cat_with_heart_eyes",
			"group": "Smileys & Emotion",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"smiling_cat_with_heart_eyes",
				"animal",
				"love",
				"like",
				"affection",
				"cats",
				"valentines",
				"heart",
				"eye",
				"face",
				"loving\xA0cat",
				"shaped",
				"smile"
			]
		},
		"😼": {
			"name": "cat with wry smile",
			"slug": "cat_with_wry_smile",
			"group": "Smileys & Emotion",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"cat_with_wry_smile",
				"animal",
				"cats",
				"smirk",
				"face",
				"ironic",
				"smirking"
			]
		},
		"😽": {
			"name": "kissing cat",
			"slug": "kissing_cat",
			"group": "Smileys & Emotion",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"kissing_cat",
				"animal",
				"cats",
				"kiss",
				"closed",
				"eye",
				"eyes",
				"face"
			]
		},
		"🙀": {
			"name": "weary cat",
			"slug": "weary_cat",
			"group": "Smileys & Emotion",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"weary_cat",
				"animal",
				"cats",
				"munch",
				"scared",
				"scream",
				"face",
				"fear",
				"horror",
				"oh",
				"screaming",
				"surprised"
			]
		},
		"😿": {
			"name": "crying cat",
			"slug": "crying_cat",
			"group": "Smileys & Emotion",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"crying_cat",
				"animal",
				"tears",
				"weep",
				"sad",
				"cats",
				"upset",
				"cry",
				"face",
				"sad\xA0cat",
				"tear"
			]
		},
		"😾": {
			"name": "pouting cat",
			"slug": "pouting_cat",
			"group": "Smileys & Emotion",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"pouting_cat",
				"animal",
				"cats",
				"face",
				"grumpy"
			]
		},
		"🙈": {
			"name": "see-no-evil monkey",
			"slug": "see_no_evil_monkey",
			"group": "Smileys & Emotion",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"see_no_evil_monkey",
				"monkey",
				"animal",
				"nature",
				"haha",
				"blind",
				"covering",
				"eyes",
				"face",
				"forbidden",
				"gesture",
				"ignore",
				"mizaru",
				"not",
				"prohibited"
			]
		},
		"🙉": {
			"name": "hear-no-evil monkey",
			"slug": "hear_no_evil_monkey",
			"group": "Smileys & Emotion",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"hear_no_evil_monkey",
				"animal",
				"monkey",
				"nature",
				"covering",
				"deaf",
				"ears",
				"face",
				"forbidden",
				"gesture",
				"kikazaru",
				"not",
				"prohibited"
			]
		},
		"🙊": {
			"name": "speak-no-evil monkey",
			"slug": "speak_no_evil_monkey",
			"group": "Smileys & Emotion",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"speak_no_evil_monkey",
				"monkey",
				"animal",
				"nature",
				"omg",
				"covering",
				"face",
				"forbidden",
				"gesture",
				"hush",
				"iwazaru",
				"mouth",
				"mute",
				"not",
				"no\xA0speaking",
				"prohibited",
				"ignore"
			]
		},
		"💌": {
			"name": "love letter",
			"slug": "love_letter",
			"group": "Smileys & Emotion",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"love_letter",
				"email",
				"like",
				"affection",
				"envelope",
				"valentines",
				"heart",
				"mail",
				"note",
				"romance"
			]
		},
		"💘": {
			"name": "heart with arrow",
			"slug": "heart_with_arrow",
			"group": "Smileys & Emotion",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"heart_with_arrow",
				"love",
				"like",
				"heart",
				"affection",
				"valentines",
				"cupid",
				"lovestruck",
				"romance"
			]
		},
		"💝": {
			"name": "heart with ribbon",
			"slug": "heart_with_ribbon",
			"group": "Smileys & Emotion",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"heart_with_ribbon",
				"love",
				"valentines",
				"box",
				"chocolate",
				"chocolates",
				"gift",
				"valentine"
			]
		},
		"💖": {
			"name": "sparkling heart",
			"slug": "sparkling_heart",
			"group": "Smileys & Emotion",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"sparkling_heart",
				"love",
				"like",
				"affection",
				"valentines",
				"excited",
				"sparkle",
				"sparkly",
				"stars\xA0heart"
			]
		},
		"💗": {
			"name": "growing heart",
			"slug": "growing_heart",
			"group": "Smileys & Emotion",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"growing_heart",
				"like",
				"love",
				"affection",
				"valentines",
				"pink",
				"excited",
				"heartpulse",
				"multiple",
				"nervous",
				"pulse",
				"triple"
			]
		},
		"💓": {
			"name": "beating heart",
			"slug": "beating_heart",
			"group": "Smileys & Emotion",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"beating_heart",
				"love",
				"like",
				"affection",
				"valentines",
				"pink",
				"heart",
				"alarm",
				"heartbeat",
				"pulsating",
				"wifi"
			]
		},
		"💞": {
			"name": "revolving hearts",
			"slug": "revolving_hearts",
			"group": "Smileys & Emotion",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"revolving_hearts",
				"love",
				"like",
				"affection",
				"valentines",
				"heart",
				"two"
			]
		},
		"💕": {
			"name": "two hearts",
			"slug": "two_hearts",
			"group": "Smileys & Emotion",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"two_hearts",
				"love",
				"like",
				"affection",
				"valentines",
				"heart",
				"pink",
				"small"
			]
		},
		"💟": {
			"name": "heart decoration",
			"slug": "heart_decoration",
			"group": "Smileys & Emotion",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"heart_decoration",
				"purple-square",
				"love",
				"like"
			]
		},
		"❣️": {
			"name": "heart exclamation",
			"slug": "heart_exclamation",
			"group": "Smileys & Emotion",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"heart_exclamation",
				"decoration",
				"love",
				"above",
				"an",
				"as",
				"dot",
				"heavy",
				"mark",
				"ornament",
				"punctuation",
				"red"
			]
		},
		"💔": {
			"name": "broken heart",
			"slug": "broken_heart",
			"group": "Smileys & Emotion",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"broken_heart",
				"sad",
				"sorry",
				"break",
				"heart",
				"heartbreak",
				"breaking",
				"brokenhearted"
			]
		},
		"❤️‍🔥": {
			"name": "heart on fire",
			"slug": "heart_on_fire",
			"group": "Smileys & Emotion",
			"emoji_version": "13.1",
			"unicode_version": "13.1",
			"skin_tone_support": false,
			"aliases": [
				"heart on fire",
				"passionate",
				"enthusiastic",
				"burn",
				"love",
				"lust",
				"sacred"
			]
		},
		"❤️‍🩹": {
			"name": "mending heart",
			"slug": "mending_heart",
			"group": "Smileys & Emotion",
			"emoji_version": "13.1",
			"unicode_version": "13.1",
			"skin_tone_support": false,
			"aliases": [
				"mending heart",
				"broken heart",
				"bandage",
				"wounded",
				"bandaged",
				"healing",
				"healthier",
				"improving",
				"recovering",
				"recuperating",
				"unbroken",
				"well"
			]
		},
		"❤️": {
			"name": "red heart",
			"slug": "red_heart",
			"group": "Smileys & Emotion",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"red_heart",
				"love",
				"like",
				"valentines",
				"black",
				"heavy"
			]
		},
		"🩷": {
			"name": "pink heart",
			"slug": "pink_heart",
			"group": "Smileys & Emotion",
			"emoji_version": "15.0",
			"unicode_version": "15.0",
			"skin_tone_support": false,
			"aliases": ["pink heart", "valentines"]
		},
		"🧡": {
			"name": "orange heart",
			"slug": "orange_heart",
			"group": "Smileys & Emotion",
			"emoji_version": "5.0",
			"unicode_version": "5.0",
			"skin_tone_support": false,
			"aliases": [
				"orange_heart",
				"love",
				"like",
				"affection",
				"valentines"
			]
		},
		"💛": {
			"name": "yellow heart",
			"slug": "yellow_heart",
			"group": "Smileys & Emotion",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"yellow_heart",
				"love",
				"like",
				"affection",
				"valentines",
				"bf",
				"gold",
				"snapchat"
			]
		},
		"💚": {
			"name": "green heart",
			"slug": "green_heart",
			"group": "Smileys & Emotion",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"green_heart",
				"love",
				"like",
				"affection",
				"valentines",
				"nct"
			]
		},
		"💙": {
			"name": "blue heart",
			"slug": "blue_heart",
			"group": "Smileys & Emotion",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"blue_heart",
				"love",
				"like",
				"affection",
				"valentines",
				"brand",
				"neutral"
			]
		},
		"🩵": {
			"name": "light blue heart",
			"slug": "light_blue_heart",
			"group": "Smileys & Emotion",
			"emoji_version": "15.0",
			"unicode_version": "15.0",
			"skin_tone_support": false,
			"aliases": [
				"light blue heart",
				"ice",
				"baby blue"
			]
		},
		"💜": {
			"name": "purple heart",
			"slug": "purple_heart",
			"group": "Smileys & Emotion",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"purple_heart",
				"love",
				"like",
				"affection",
				"valentines",
				"bts",
				"emoji"
			]
		},
		"🤎": {
			"name": "brown heart",
			"slug": "brown_heart",
			"group": "Smileys & Emotion",
			"emoji_version": "12.0",
			"unicode_version": "12.0",
			"skin_tone_support": false,
			"aliases": ["brown_heart", "coffee"]
		},
		"🖤": {
			"name": "black heart",
			"slug": "black_heart",
			"group": "Smileys & Emotion",
			"emoji_version": "3.0",
			"unicode_version": "3.0",
			"skin_tone_support": false,
			"aliases": [
				"black_heart",
				"evil",
				"dark",
				"wicked"
			]
		},
		"🩶": {
			"name": "grey heart",
			"slug": "grey_heart",
			"group": "Smileys & Emotion",
			"emoji_version": "15.0",
			"unicode_version": "15.0",
			"skin_tone_support": false,
			"aliases": [
				"grey heart",
				"silver",
				"monochrome"
			]
		},
		"🤍": {
			"name": "white heart",
			"slug": "white_heart",
			"group": "Smileys & Emotion",
			"emoji_version": "12.0",
			"unicode_version": "12.0",
			"skin_tone_support": false,
			"aliases": ["white_heart", "pure"]
		},
		"💋": {
			"name": "kiss mark",
			"slug": "kiss_mark",
			"group": "Smileys & Emotion",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"kiss_mark",
				"face",
				"lips",
				"love",
				"like",
				"affection",
				"valentines",
				"heart",
				"kissing",
				"lipstick",
				"romance"
			]
		},
		"💯": {
			"name": "hundred points",
			"slug": "hundred_points",
			"group": "Smileys & Emotion",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"hundred_points",
				"score",
				"perfect",
				"numbers",
				"century",
				"exam",
				"quiz",
				"test",
				"pass",
				"hundred",
				"100",
				"full",
				"keep",
				"symbol"
			]
		},
		"💢": {
			"name": "anger symbol",
			"slug": "anger_symbol",
			"group": "Smileys & Emotion",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"anger_symbol",
				"angry",
				"mad",
				"comic",
				"pop",
				"sign",
				"vein"
			]
		},
		"🫯": {
			"name": "fight cloud",
			"slug": "fight_cloud",
			"group": "Smileys & Emotion",
			"emoji_version": "17.0",
			"unicode_version": "17.0",
			"skin_tone_support": false,
			"aliases": [
				"fight cloud",
				"brawl",
				"conflict"
			]
		},
		"💥": {
			"name": "collision",
			"slug": "collision",
			"group": "Smileys & Emotion",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"collision",
				"bomb",
				"explode",
				"explosion",
				"blown",
				"bang",
				"boom",
				"comic",
				"impact",
				"red",
				"spark",
				"symbol",
				"break"
			]
		},
		"💫": {
			"name": "dizzy",
			"slug": "dizzy",
			"group": "Smileys & Emotion",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"dizzy",
				"star",
				"sparkle",
				"shoot",
				"magic",
				"circle",
				"comic",
				"symbol",
				"animations",
				"transitions"
			]
		},
		"💦": {
			"name": "sweat droplets",
			"slug": "sweat_droplets",
			"group": "Smileys & Emotion",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"sweat_droplets",
				"water",
				"drip",
				"oops",
				"comic",
				"drops",
				"plewds",
				"splashing",
				"symbol",
				"workout"
			]
		},
		"💨": {
			"name": "dashing away",
			"slug": "dashing_away",
			"group": "Smileys & Emotion",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"dashing_away",
				"wind",
				"air",
				"fast",
				"shoo",
				"fart",
				"smoke",
				"puff",
				"blow",
				"comic",
				"dash",
				"gust",
				"running",
				"steam",
				"symbol",
				"vaping"
			]
		},
		"🕳️": {
			"name": "hole",
			"slug": "hole",
			"group": "Smileys & Emotion",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": ["hole", "embarrassing"]
		},
		"💬": {
			"name": "speech balloon",
			"slug": "speech_balloon",
			"group": "Smileys & Emotion",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"speech_balloon",
				"bubble",
				"words",
				"message",
				"talk",
				"chatting",
				"chat",
				"comic",
				"comment",
				"dialog",
				"text",
				"literals"
			]
		},
		"👁️‍🗨️": {
			"name": "eye in speech bubble",
			"slug": "eye_in_speech_bubble",
			"group": "Smileys & Emotion",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"eye_in_speech_bubble",
				"info",
				"am",
				"i",
				"witness"
			]
		},
		"🗨️": {
			"name": "left speech bubble",
			"slug": "left_speech_bubble",
			"group": "Smileys & Emotion",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"left_speech_bubble",
				"words",
				"message",
				"talk",
				"chatting",
				"dialog"
			]
		},
		"🗯️": {
			"name": "right anger bubble",
			"slug": "right_anger_bubble",
			"group": "Smileys & Emotion",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"right_anger_bubble",
				"caption",
				"speech",
				"thinking",
				"mad",
				"angry",
				"balloon",
				"zag",
				"zig"
			]
		},
		"💭": {
			"name": "thought balloon",
			"slug": "thought_balloon",
			"group": "Smileys & Emotion",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"thought_balloon",
				"bubble",
				"cloud",
				"speech",
				"thinking",
				"dream",
				"comic"
			]
		},
		"💤": {
			"name": "ZZZ",
			"slug": "zzz",
			"group": "Smileys & Emotion",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"zzz",
				"sleepy",
				"tired",
				"dream",
				"bedtime",
				"boring",
				"comic",
				"sign",
				"sleep",
				"sleeping",
				"symbol"
			]
		},
		"👋": {
			"name": "waving hand",
			"slug": "waving_hand",
			"group": "People & Body",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "1.0",
			"aliases": [
				"waving_hand",
				"wave",
				"hands",
				"gesture",
				"goodbye",
				"solong",
				"farewell",
				"hello",
				"hi",
				"palm",
				"body",
				"sign"
			]
		},
		"🤚": {
			"name": "raised back of hand",
			"slug": "raised_back_of_hand",
			"group": "People & Body",
			"emoji_version": "3.0",
			"unicode_version": "3.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "3.0",
			"aliases": [
				"raised_back_of_hand",
				"fingers",
				"raised",
				"backhand",
				"body"
			]
		},
		"🖐️": {
			"name": "hand with fingers splayed",
			"slug": "hand_with_fingers_splayed",
			"group": "People & Body",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "1.0",
			"aliases": [
				"hand_with_fingers_splayed",
				"hand",
				"fingers",
				"palm",
				"body",
				"finger",
				"five",
				"raised"
			]
		},
		"✋": {
			"name": "raised hand",
			"slug": "raised_hand",
			"group": "People & Body",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "1.0",
			"aliases": [
				"raised_hand",
				"fingers",
				"stop",
				"highfive",
				"palm",
				"ban",
				"body",
				"five",
				"high"
			]
		},
		"🖖": {
			"name": "vulcan salute",
			"slug": "vulcan_salute",
			"group": "People & Body",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "1.0",
			"aliases": [
				"vulcan_salute",
				"hand",
				"fingers",
				"spock",
				"star trek",
				"between",
				"body",
				"finger",
				"middle",
				"part",
				"prosper",
				"raised",
				"ring",
				"split"
			]
		},
		"🫱": {
			"name": "rightwards hand",
			"slug": "rightwards_hand",
			"group": "People & Body",
			"emoji_version": "14.0",
			"unicode_version": "14.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "14.0",
			"aliases": [
				"rightwards hand",
				"palm",
				"offer",
				"right",
				"rightward"
			]
		},
		"🫲": {
			"name": "leftwards hand",
			"slug": "leftwards_hand",
			"group": "People & Body",
			"emoji_version": "14.0",
			"unicode_version": "14.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "14.0",
			"aliases": [
				"leftwards hand",
				"palm",
				"offer",
				"left",
				"leftward"
			]
		},
		"🫳": {
			"name": "palm down hand",
			"slug": "palm_down_hand",
			"group": "People & Body",
			"emoji_version": "14.0",
			"unicode_version": "14.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "14.0",
			"aliases": [
				"palm down hand",
				"palm",
				"drop",
				"dismiss",
				"shoo"
			]
		},
		"🫴": {
			"name": "palm up hand",
			"slug": "palm_up_hand",
			"group": "People & Body",
			"emoji_version": "14.0",
			"unicode_version": "14.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "14.0",
			"aliases": [
				"palm up hand",
				"lift",
				"offer",
				"demand",
				"beckon",
				"catch",
				"come"
			]
		},
		"🫷": {
			"name": "leftwards pushing hand",
			"slug": "leftwards_pushing_hand",
			"group": "People & Body",
			"emoji_version": "15.0",
			"unicode_version": "15.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "15.0",
			"aliases": [
				"leftwards pushing hand",
				"highfive",
				"pressing",
				"stop"
			]
		},
		"🫸": {
			"name": "rightwards pushing hand",
			"slug": "rightwards_pushing_hand",
			"group": "People & Body",
			"emoji_version": "15.0",
			"unicode_version": "15.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "15.0",
			"aliases": [
				"rightwards pushing hand",
				"highfive",
				"pressing",
				"stop"
			]
		},
		"👌": {
			"name": "OK hand",
			"slug": "ok_hand",
			"group": "People & Body",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "1.0",
			"aliases": [
				"ok_hand",
				"fingers",
				"limbs",
				"perfect",
				"ok",
				"okay",
				"body",
				"sign"
			]
		},
		"🤌": {
			"name": "pinched fingers",
			"slug": "pinched_fingers",
			"group": "People & Body",
			"emoji_version": "13.0",
			"unicode_version": "13.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "13.0",
			"aliases": [
				"pinched fingers",
				"size",
				"tiny",
				"small",
				"che",
				"finger",
				"gesture",
				"hand",
				"interrogation",
				"ma",
				"purse",
				"sarcastic",
				"vuoi"
			]
		},
		"🤏": {
			"name": "pinching hand",
			"slug": "pinching_hand",
			"group": "People & Body",
			"emoji_version": "12.0",
			"unicode_version": "12.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "12.0",
			"aliases": [
				"pinching_hand",
				"tiny",
				"small",
				"size",
				"amount",
				"body",
				"little"
			]
		},
		"✌️": {
			"name": "victory hand",
			"slug": "victory_hand",
			"group": "People & Body",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "1.0",
			"aliases": [
				"victory_hand",
				"fingers",
				"ohyeah",
				"hand",
				"peace",
				"victory",
				"two",
				"air",
				"body",
				"quotes",
				"sign",
				"v"
			]
		},
		"🤞": {
			"name": "crossed fingers",
			"slug": "crossed_fingers",
			"group": "People & Body",
			"emoji_version": "3.0",
			"unicode_version": "3.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "3.0",
			"aliases": [
				"crossed_fingers",
				"good",
				"lucky",
				"body",
				"cross",
				"finger",
				"hand",
				"hopeful",
				"index",
				"luck",
				"middle"
			]
		},
		"🫰": {
			"name": "hand with index finger and thumb crossed",
			"slug": "hand_with_index_finger_and_thumb_crossed",
			"group": "People & Body",
			"emoji_version": "14.0",
			"unicode_version": "14.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "14.0",
			"aliases": [
				"hand with index finger and thumb crossed",
				"heart",
				"love",
				"money",
				"expensive",
				"snap"
			]
		},
		"🤟": {
			"name": "love-you gesture",
			"slug": "love_you_gesture",
			"group": "People & Body",
			"emoji_version": "5.0",
			"unicode_version": "5.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "5.0",
			"aliases": [
				"love_you_gesture",
				"hand",
				"fingers",
				"gesture",
				"body",
				"i",
				"ily",
				"sign"
			]
		},
		"🤘": {
			"name": "sign of the horns",
			"slug": "sign_of_the_horns",
			"group": "People & Body",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "1.0",
			"aliases": [
				"sign_of_the_horns",
				"hand",
				"fingers",
				"evil_eye",
				"sign_of_horns",
				"rock_on",
				"body",
				"devil",
				"finger",
				"heavy",
				"metal"
			]
		},
		"🤙": {
			"name": "call me hand",
			"slug": "call_me_hand",
			"group": "People & Body",
			"emoji_version": "3.0",
			"unicode_version": "3.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "3.0",
			"aliases": [
				"call_me_hand",
				"hands",
				"gesture",
				"shaka",
				"body",
				"phone",
				"sign"
			]
		},
		"👈": {
			"name": "backhand index pointing left",
			"slug": "backhand_index_pointing_left",
			"group": "People & Body",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "1.0",
			"aliases": [
				"backhand_index_pointing_left",
				"direction",
				"fingers",
				"hand",
				"left",
				"body",
				"finger",
				"point",
				"white"
			]
		},
		"👉": {
			"name": "backhand index pointing right",
			"slug": "backhand_index_pointing_right",
			"group": "People & Body",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "1.0",
			"aliases": [
				"backhand_index_pointing_right",
				"fingers",
				"hand",
				"direction",
				"right",
				"body",
				"finger",
				"point",
				"white"
			]
		},
		"👆": {
			"name": "backhand index pointing up",
			"slug": "backhand_index_pointing_up",
			"group": "People & Body",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "1.0",
			"aliases": [
				"backhand_index_pointing_up",
				"fingers",
				"hand",
				"direction",
				"up",
				"body",
				"finger",
				"middle",
				"point",
				"white"
			]
		},
		"🖕": {
			"name": "middle finger",
			"slug": "middle_finger",
			"group": "People & Body",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "1.0",
			"aliases": [
				"middle_finger",
				"hand",
				"fingers",
				"rude",
				"middle",
				"flipping",
				"bird",
				"body",
				"dito",
				"extended",
				"fu",
				"medio",
				"middle\xA0finger",
				"reversed"
			]
		},
		"👇": {
			"name": "backhand index pointing down",
			"slug": "backhand_index_pointing_down",
			"group": "People & Body",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "1.0",
			"aliases": [
				"backhand_index_pointing_down",
				"fingers",
				"hand",
				"direction",
				"down",
				"body",
				"finger",
				"point",
				"white"
			]
		},
		"☝️": {
			"name": "index pointing up",
			"slug": "index_pointing_up",
			"group": "People & Body",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "1.0",
			"aliases": [
				"index_pointing_up",
				"hand",
				"fingers",
				"direction",
				"up",
				"body",
				"finger",
				"point",
				"secret",
				"white"
			]
		},
		"🫵": {
			"name": "index pointing at the viewer",
			"slug": "index_pointing_at_the_viewer",
			"group": "People & Body",
			"emoji_version": "14.0",
			"unicode_version": "14.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "14.0",
			"aliases": [
				"index pointing at the viewer",
				"you",
				"recruit",
				"point"
			]
		},
		"👍": {
			"name": "thumbs up",
			"slug": "thumbs_up",
			"group": "People & Body",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "1.0",
			"aliases": [
				"thumbs_up",
				"thumbsup",
				"yes",
				"awesome",
				"good",
				"agree",
				"accept",
				"cool",
				"hand",
				"like",
				"+1",
				"approve",
				"body",
				"ok",
				"sign",
				"thumb"
			]
		},
		"👎": {
			"name": "thumbs down",
			"slug": "thumbs_down",
			"group": "People & Body",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "1.0",
			"aliases": [
				"thumbs_down",
				"thumbsdown",
				"no",
				"dislike",
				"hand",
				"-1",
				"bad",
				"body",
				"bury",
				"disapprove",
				"sign",
				"thumb"
			]
		},
		"✊": {
			"name": "raised fist",
			"slug": "raised_fist",
			"group": "People & Body",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "1.0",
			"aliases": [
				"raised_fist",
				"fingers",
				"hand",
				"grasp",
				"body",
				"clenched",
				"power",
				"pump",
				"punch"
			]
		},
		"👊": {
			"name": "oncoming fist",
			"slug": "oncoming_fist",
			"group": "People & Body",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "1.0",
			"aliases": [
				"oncoming_fist",
				"angry",
				"violence",
				"fist",
				"hit",
				"attack",
				"hand",
				"body",
				"bro",
				"brofist",
				"bump",
				"clenched",
				"closed",
				"facepunch",
				"fisted",
				"punch",
				"sign"
			]
		},
		"🤛": {
			"name": "left-facing fist",
			"slug": "left_facing_fist",
			"group": "People & Body",
			"emoji_version": "3.0",
			"unicode_version": "3.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "3.0",
			"aliases": [
				"left_facing_fist",
				"hand",
				"fistbump",
				"body",
				"bump",
				"leftwards"
			]
		},
		"🤜": {
			"name": "right-facing fist",
			"slug": "right_facing_fist",
			"group": "People & Body",
			"emoji_version": "3.0",
			"unicode_version": "3.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "3.0",
			"aliases": [
				"right_facing_fist",
				"hand",
				"fistbump",
				"body",
				"bump",
				"rightwards",
				"right\xA0fist"
			]
		},
		"👏": {
			"name": "clapping hands",
			"slug": "clapping_hands",
			"group": "People & Body",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "1.0",
			"aliases": [
				"clapping_hands",
				"hands",
				"praise",
				"applause",
				"congrats",
				"yay",
				"body",
				"clap",
				"golf",
				"hand",
				"round",
				"sign"
			]
		},
		"🙌": {
			"name": "raising hands",
			"slug": "raising_hands",
			"group": "People & Body",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "1.0",
			"aliases": [
				"raising_hands",
				"gesture",
				"hooray",
				"yea",
				"celebration",
				"hands",
				"air",
				"arms",
				"banzai",
				"body",
				"both",
				"festivus",
				"hallelujah",
				"hand",
				"miracle",
				"person",
				"praise",
				"raised",
				"two"
			]
		},
		"🫶": {
			"name": "heart hands",
			"slug": "heart_hands",
			"group": "People & Body",
			"emoji_version": "14.0",
			"unicode_version": "14.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "14.0",
			"aliases": [
				"heart hands",
				"love",
				"appreciation",
				"support"
			]
		},
		"👐": {
			"name": "open hands",
			"slug": "open_hands",
			"group": "People & Body",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "1.0",
			"aliases": [
				"open_hands",
				"fingers",
				"butterfly",
				"hands",
				"open",
				"body",
				"hand",
				"hug",
				"jazz",
				"sign"
			]
		},
		"🤲": {
			"name": "palms up together",
			"slug": "palms_up_together",
			"group": "People & Body",
			"emoji_version": "5.0",
			"unicode_version": "5.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "5.0",
			"aliases": [
				"palms_up_together",
				"hands",
				"gesture",
				"cupped",
				"prayer",
				"body",
				"dua",
				"facing"
			]
		},
		"🤝": {
			"name": "handshake",
			"slug": "handshake",
			"group": "People & Body",
			"emoji_version": "3.0",
			"unicode_version": "3.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "14.0",
			"aliases": [
				"handshake",
				"agreement",
				"shake",
				"deal",
				"hand",
				"hands",
				"meeting",
				"shaking"
			]
		},
		"🙏": {
			"name": "folded hands",
			"slug": "folded_hands",
			"group": "People & Body",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "1.0",
			"aliases": [
				"folded_hands",
				"please",
				"hope",
				"wish",
				"namaste",
				"highfive",
				"pray",
				"thank you",
				"thanks",
				"appreciate",
				"ask",
				"body",
				"bow",
				"five",
				"gesture",
				"hand",
				"high",
				"person",
				"prayer",
				"pressed",
				"together"
			]
		},
		"✍️": {
			"name": "writing hand",
			"slug": "writing_hand",
			"group": "People & Body",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "1.0",
			"aliases": [
				"writing_hand",
				"lower_left_ballpoint_pen",
				"stationery",
				"write",
				"compose",
				"body"
			]
		},
		"💅": {
			"name": "nail polish",
			"slug": "nail_polish",
			"group": "People & Body",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "1.0",
			"aliases": [
				"nail_polish",
				"nail_care",
				"beauty",
				"manicure",
				"finger",
				"fashion",
				"nail",
				"slay",
				"body",
				"cosmetics",
				"fingers",
				"nonchalant"
			]
		},
		"🤳": {
			"name": "selfie",
			"slug": "selfie",
			"group": "People & Body",
			"emoji_version": "3.0",
			"unicode_version": "3.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "3.0",
			"aliases": [
				"selfie",
				"camera",
				"phone",
				"arm",
				"hand"
			]
		},
		"💪": {
			"name": "flexed biceps",
			"slug": "flexed_biceps",
			"group": "People & Body",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "1.0",
			"aliases": [
				"flexed_biceps",
				"arm",
				"flex",
				"hand",
				"summer",
				"strong",
				"biceps",
				"bicep",
				"body",
				"comic",
				"feats",
				"flexing",
				"muscle",
				"muscles",
				"strength",
				"workout"
			]
		},
		"🦾": {
			"name": "mechanical arm",
			"slug": "mechanical_arm",
			"group": "People & Body",
			"emoji_version": "12.0",
			"unicode_version": "12.0",
			"skin_tone_support": false,
			"aliases": [
				"mechanical_arm",
				"accessibility",
				"body",
				"prosthetic"
			]
		},
		"🦿": {
			"name": "mechanical leg",
			"slug": "mechanical_leg",
			"group": "People & Body",
			"emoji_version": "12.0",
			"unicode_version": "12.0",
			"skin_tone_support": false,
			"aliases": [
				"mechanical_leg",
				"accessibility",
				"body",
				"prosthetic"
			]
		},
		"🦵": {
			"name": "leg",
			"slug": "leg",
			"group": "People & Body",
			"emoji_version": "11.0",
			"unicode_version": "11.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "11.0",
			"aliases": [
				"leg",
				"kick",
				"limb",
				"body"
			]
		},
		"🦶": {
			"name": "foot",
			"slug": "foot",
			"group": "People & Body",
			"emoji_version": "11.0",
			"unicode_version": "11.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "11.0",
			"aliases": [
				"foot",
				"kick",
				"stomp",
				"body"
			]
		},
		"👂": {
			"name": "ear",
			"slug": "ear",
			"group": "People & Body",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "1.0",
			"aliases": [
				"ear",
				"face",
				"hear",
				"sound",
				"listen",
				"body",
				"ears",
				"hearing",
				"listening",
				"nose"
			]
		},
		"🦻": {
			"name": "ear with hearing aid",
			"slug": "ear_with_hearing_aid",
			"group": "People & Body",
			"emoji_version": "12.0",
			"unicode_version": "12.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "12.0",
			"aliases": [
				"ear_with_hearing_aid",
				"accessibility",
				"body",
				"hard"
			]
		},
		"👃": {
			"name": "nose",
			"slug": "nose",
			"group": "People & Body",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "1.0",
			"aliases": [
				"nose",
				"smell",
				"sniff",
				"body",
				"smelling",
				"sniffing",
				"stinky"
			]
		},
		"🧠": {
			"name": "brain",
			"slug": "brain",
			"group": "People & Body",
			"emoji_version": "5.0",
			"unicode_version": "5.0",
			"skin_tone_support": false,
			"aliases": [
				"brain",
				"smart",
				"intelligent",
				"body",
				"organ"
			]
		},
		"🫀": {
			"name": "anatomical heart",
			"slug": "anatomical_heart",
			"group": "People & Body",
			"emoji_version": "13.0",
			"unicode_version": "13.0",
			"skin_tone_support": false,
			"aliases": [
				"anatomical heart",
				"health",
				"heartbeat",
				"cardiology",
				"organ",
				"pulse"
			]
		},
		"🫁": {
			"name": "lungs",
			"slug": "lungs",
			"group": "People & Body",
			"emoji_version": "13.0",
			"unicode_version": "13.0",
			"skin_tone_support": false,
			"aliases": [
				"lungs",
				"breathe",
				"breath",
				"exhalation",
				"inhalation",
				"organ",
				"respiration"
			]
		},
		"🦷": {
			"name": "tooth",
			"slug": "tooth",
			"group": "People & Body",
			"emoji_version": "11.0",
			"unicode_version": "11.0",
			"skin_tone_support": false,
			"aliases": [
				"tooth",
				"teeth",
				"dentist",
				"body"
			]
		},
		"🦴": {
			"name": "bone",
			"slug": "bone",
			"group": "People & Body",
			"emoji_version": "11.0",
			"unicode_version": "11.0",
			"skin_tone_support": false,
			"aliases": [
				"bone",
				"skeleton",
				"body"
			]
		},
		"👀": {
			"name": "eyes",
			"slug": "eyes",
			"group": "People & Body",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"eyes",
				"look",
				"watch",
				"stalk",
				"peek",
				"see",
				"body",
				"eye",
				"eyeballs",
				"face",
				"shifty",
				"wide"
			]
		},
		"👁️": {
			"name": "eye",
			"slug": "eye",
			"group": "People & Body",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"eye",
				"face",
				"look",
				"see",
				"watch",
				"stare",
				"body",
				"single"
			]
		},
		"👅": {
			"name": "tongue",
			"slug": "tongue",
			"group": "People & Body",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"tongue",
				"mouth",
				"playful",
				"body",
				"out",
				"taste"
			]
		},
		"👄": {
			"name": "mouth",
			"slug": "mouth",
			"group": "People & Body",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"mouth",
				"kiss",
				"body",
				"kissing",
				"lips"
			]
		},
		"🫦": {
			"name": "biting lip",
			"slug": "biting_lip",
			"group": "People & Body",
			"emoji_version": "14.0",
			"unicode_version": "14.0",
			"skin_tone_support": false,
			"aliases": [
				"biting lip",
				"flirt",
				"sexy",
				"pain",
				"worry",
				"anxious",
				"fear",
				"flirting",
				"nervous",
				"uncomfortable",
				"worried"
			]
		},
		"👶": {
			"name": "baby",
			"slug": "baby",
			"group": "People & Body",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "1.0",
			"aliases": [
				"baby",
				"child",
				"boy",
				"girl",
				"toddler",
				"newborn",
				"young"
			]
		},
		"🧒": {
			"name": "child",
			"slug": "child",
			"group": "People & Body",
			"emoji_version": "5.0",
			"unicode_version": "5.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "5.0",
			"aliases": [
				"child",
				"gender-neutral",
				"young",
				"boy",
				"gender",
				"girl",
				"inclusive",
				"neutral",
				"person",
				"unspecified"
			]
		},
		"👦": {
			"name": "boy",
			"slug": "boy",
			"group": "People & Body",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "1.0",
			"aliases": [
				"boy",
				"man",
				"male",
				"guy",
				"teenager",
				"child",
				"young"
			]
		},
		"👧": {
			"name": "girl",
			"slug": "girl",
			"group": "People & Body",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "1.0",
			"aliases": [
				"girl",
				"female",
				"woman",
				"teenager",
				"child",
				"maiden",
				"virgin",
				"virgo",
				"young",
				"zodiac"
			]
		},
		"🧑": {
			"name": "person",
			"slug": "person",
			"group": "People & Body",
			"emoji_version": "5.0",
			"unicode_version": "5.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "5.0",
			"aliases": [
				"person",
				"gender-neutral",
				"adult",
				"female",
				"gender",
				"inclusive",
				"male",
				"man",
				"men",
				"neutral",
				"unspecified",
				"woman",
				"women"
			]
		},
		"👱": {
			"name": "person blond hair",
			"slug": "person_blond_hair",
			"group": "People & Body",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "1.0",
			"aliases": [
				"person_blond_hair",
				"hairstyle",
				"blonde",
				"haired",
				"man"
			]
		},
		"👨": {
			"name": "man",
			"slug": "man",
			"group": "People & Body",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "1.0",
			"aliases": [
				"man",
				"mustache",
				"father",
				"dad",
				"guy",
				"classy",
				"sir",
				"moustache",
				"adult",
				"male",
				"men"
			]
		},
		"🧔": {
			"name": "person beard",
			"slug": "person_beard",
			"group": "People & Body",
			"emoji_version": "5.0",
			"unicode_version": "5.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "5.0",
			"aliases": [
				"man_beard",
				"person",
				"bewhiskered",
				"bearded"
			]
		},
		"🧔‍♂️": {
			"name": "man beard",
			"slug": "man_beard",
			"group": "People & Body",
			"emoji_version": "13.1",
			"unicode_version": "13.1",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "13.1",
			"aliases": [
				"man beard",
				"facial hair",
				"bearded",
				"bewhiskered",
				"male",
				"men"
			]
		},
		"🧔‍♀️": {
			"name": "woman beard",
			"slug": "woman_beard",
			"group": "People & Body",
			"emoji_version": "13.1",
			"unicode_version": "13.1",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "13.1",
			"aliases": [
				"woman beard",
				"facial hair",
				"bearded",
				"bewhiskered",
				"female",
				"women"
			]
		},
		"👨‍🦰": {
			"name": "man red hair",
			"slug": "man_red_hair",
			"group": "People & Body",
			"emoji_version": "11.0",
			"unicode_version": "11.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "11.0",
			"aliases": [
				"man_red_hair",
				"hairstyle",
				"adult",
				"ginger",
				"haired",
				"male",
				"men",
				"redhead"
			]
		},
		"👨‍🦱": {
			"name": "man curly hair",
			"slug": "man_curly_hair",
			"group": "People & Body",
			"emoji_version": "11.0",
			"unicode_version": "11.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "11.0",
			"aliases": [
				"man_curly_hair",
				"hairstyle",
				"adult",
				"haired",
				"male",
				"men"
			]
		},
		"👨‍🦳": {
			"name": "man white hair",
			"slug": "man_white_hair",
			"group": "People & Body",
			"emoji_version": "11.0",
			"unicode_version": "11.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "11.0",
			"aliases": [
				"man_white_hair",
				"old",
				"elder",
				"adult",
				"haired",
				"male",
				"men"
			]
		},
		"👨‍🦲": {
			"name": "man bald",
			"slug": "man_bald",
			"group": "People & Body",
			"emoji_version": "11.0",
			"unicode_version": "11.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "11.0",
			"aliases": [
				"man_bald",
				"hairless",
				"adult",
				"hair",
				"male",
				"men",
				"no"
			]
		},
		"👩": {
			"name": "woman",
			"slug": "woman",
			"group": "People & Body",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "1.0",
			"aliases": [
				"woman",
				"female",
				"girls",
				"lady",
				"adult",
				"women",
				"yellow"
			]
		},
		"👩‍🦰": {
			"name": "woman red hair",
			"slug": "woman_red_hair",
			"group": "People & Body",
			"emoji_version": "11.0",
			"unicode_version": "11.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "11.0",
			"aliases": [
				"woman_red_hair",
				"hairstyle",
				"adult",
				"female",
				"ginger",
				"haired",
				"redhead",
				"women"
			]
		},
		"🧑‍🦰": {
			"name": "person red hair",
			"slug": "person_red_hair",
			"group": "People & Body",
			"emoji_version": "12.1",
			"unicode_version": "12.1",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "12.1",
			"aliases": [
				"person_red_hair",
				"hairstyle",
				"adult",
				"gender",
				"haired",
				"unspecified"
			]
		},
		"👩‍🦱": {
			"name": "woman curly hair",
			"slug": "woman_curly_hair",
			"group": "People & Body",
			"emoji_version": "11.0",
			"unicode_version": "11.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "11.0",
			"aliases": [
				"woman_curly_hair",
				"hairstyle",
				"adult",
				"female",
				"haired",
				"women"
			]
		},
		"🧑‍🦱": {
			"name": "person curly hair",
			"slug": "person_curly_hair",
			"group": "People & Body",
			"emoji_version": "12.1",
			"unicode_version": "12.1",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "12.1",
			"aliases": [
				"person_curly_hair",
				"hairstyle",
				"adult",
				"gender",
				"haired",
				"unspecified"
			]
		},
		"👩‍🦳": {
			"name": "woman white hair",
			"slug": "woman_white_hair",
			"group": "People & Body",
			"emoji_version": "11.0",
			"unicode_version": "11.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "11.0",
			"aliases": [
				"woman_white_hair",
				"old",
				"elder",
				"adult",
				"female",
				"haired",
				"women"
			]
		},
		"🧑‍🦳": {
			"name": "person white hair",
			"slug": "person_white_hair",
			"group": "People & Body",
			"emoji_version": "12.1",
			"unicode_version": "12.1",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "12.1",
			"aliases": [
				"person_white_hair",
				"elder",
				"old",
				"adult",
				"gender",
				"haired",
				"unspecified"
			]
		},
		"👩‍🦲": {
			"name": "woman bald",
			"slug": "woman_bald",
			"group": "People & Body",
			"emoji_version": "11.0",
			"unicode_version": "11.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "11.0",
			"aliases": [
				"woman_bald",
				"hairless",
				"adult",
				"female",
				"hair",
				"no",
				"women"
			]
		},
		"🧑‍🦲": {
			"name": "person bald",
			"slug": "person_bald",
			"group": "People & Body",
			"emoji_version": "12.1",
			"unicode_version": "12.1",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "12.1",
			"aliases": [
				"person_bald",
				"hairless",
				"adult",
				"gender",
				"hair",
				"no",
				"unspecified"
			]
		},
		"👱‍♀️": {
			"name": "woman blond hair",
			"slug": "woman_blond_hair",
			"group": "People & Body",
			"emoji_version": "4.0",
			"unicode_version": "4.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "4.0",
			"aliases": [
				"woman_blond_hair",
				"woman",
				"female",
				"girl",
				"blonde",
				"person",
				"haired",
				"women"
			]
		},
		"👱‍♂️": {
			"name": "man blond hair",
			"slug": "man_blond_hair",
			"group": "People & Body",
			"emoji_version": "4.0",
			"unicode_version": "4.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "4.0",
			"aliases": [
				"man_blond_hair",
				"man",
				"male",
				"boy",
				"blonde",
				"guy",
				"person",
				"haired",
				"men"
			]
		},
		"🧓": {
			"name": "older person",
			"slug": "older_person",
			"group": "People & Body",
			"emoji_version": "5.0",
			"unicode_version": "5.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "5.0",
			"aliases": [
				"older_person",
				"human",
				"elder",
				"senior",
				"gender-neutral",
				"adult",
				"female",
				"gender",
				"male",
				"man",
				"men",
				"neutral",
				"old",
				"unspecified",
				"woman",
				"women"
			]
		},
		"👴": {
			"name": "old man",
			"slug": "old_man",
			"group": "People & Body",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "1.0",
			"aliases": [
				"old_man",
				"human",
				"male",
				"men",
				"old",
				"elder",
				"senior",
				"adult",
				"elderly",
				"grandpa",
				"older"
			]
		},
		"👵": {
			"name": "old woman",
			"slug": "old_woman",
			"group": "People & Body",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "1.0",
			"aliases": [
				"old_woman",
				"human",
				"female",
				"women",
				"lady",
				"old",
				"elder",
				"senior",
				"adult",
				"elderly",
				"grandma",
				"nanna",
				"older"
			]
		},
		"🙍": {
			"name": "person frowning",
			"slug": "person_frowning",
			"group": "People & Body",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "1.0",
			"aliases": [
				"person_frowning",
				"worried",
				"frown",
				"gesture",
				"sad",
				"woman"
			]
		},
		"🙍‍♂️": {
			"name": "man frowning",
			"slug": "man_frowning",
			"group": "People & Body",
			"emoji_version": "4.0",
			"unicode_version": "4.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "4.0",
			"aliases": [
				"man_frowning",
				"male",
				"boy",
				"man",
				"sad",
				"depressed",
				"discouraged",
				"unhappy",
				"frown",
				"gesture",
				"men"
			]
		},
		"🙍‍♀️": {
			"name": "woman frowning",
			"slug": "woman_frowning",
			"group": "People & Body",
			"emoji_version": "4.0",
			"unicode_version": "4.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "4.0",
			"aliases": [
				"woman_frowning",
				"female",
				"girl",
				"woman",
				"sad",
				"depressed",
				"discouraged",
				"unhappy",
				"frown",
				"gesture",
				"women"
			]
		},
		"🙎": {
			"name": "person pouting",
			"slug": "person_pouting",
			"group": "People & Body",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "1.0",
			"aliases": [
				"person_pouting",
				"upset",
				"blank",
				"face",
				"fed",
				"gesture",
				"look",
				"up"
			]
		},
		"🙎‍♂️": {
			"name": "man pouting",
			"slug": "man_pouting",
			"group": "People & Body",
			"emoji_version": "4.0",
			"unicode_version": "4.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "4.0",
			"aliases": [
				"man_pouting",
				"male",
				"boy",
				"man",
				"gesture",
				"men"
			]
		},
		"🙎‍♀️": {
			"name": "woman pouting",
			"slug": "woman_pouting",
			"group": "People & Body",
			"emoji_version": "4.0",
			"unicode_version": "4.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "4.0",
			"aliases": [
				"woman_pouting",
				"female",
				"girl",
				"woman",
				"gesture",
				"women"
			]
		},
		"🙅": {
			"name": "person gesturing NO",
			"slug": "person_gesturing_no",
			"group": "People & Body",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "1.0",
			"aliases": [
				"person_gesturing_no",
				"decline",
				"arms",
				"deal",
				"denied",
				"face",
				"forbidden",
				"gesture",
				"good",
				"halt",
				"hand",
				"not",
				"ok",
				"prohibited",
				"stop",
				"x"
			]
		},
		"🙅‍♂️": {
			"name": "man gesturing NO",
			"slug": "man_gesturing_no",
			"group": "People & Body",
			"emoji_version": "4.0",
			"unicode_version": "4.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "4.0",
			"aliases": [
				"man_gesturing_no",
				"male",
				"boy",
				"man",
				"nope",
				"denied",
				"forbidden",
				"gesture",
				"good",
				"halt",
				"hand",
				"men",
				"ng",
				"not",
				"ok",
				"prohibited",
				"stop"
			]
		},
		"🙅‍♀️": {
			"name": "woman gesturing NO",
			"slug": "woman_gesturing_no",
			"group": "People & Body",
			"emoji_version": "4.0",
			"unicode_version": "4.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "4.0",
			"aliases": [
				"woman_gesturing_no",
				"female",
				"girl",
				"woman",
				"nope",
				"denied",
				"forbidden",
				"gesture",
				"good",
				"halt",
				"hand",
				"ng",
				"not",
				"ok",
				"prohibited",
				"stop",
				"women"
			]
		},
		"🙆": {
			"name": "person gesturing OK",
			"slug": "person_gesturing_ok",
			"group": "People & Body",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "1.0",
			"aliases": [
				"person_gesturing_ok",
				"agree",
				"ballerina",
				"face",
				"gesture",
				"hand",
				"hands",
				"head"
			]
		},
		"🙆‍♂️": {
			"name": "man gesturing OK",
			"slug": "man_gesturing_ok",
			"group": "People & Body",
			"emoji_version": "4.0",
			"unicode_version": "4.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "4.0",
			"aliases": [
				"man_gesturing_ok",
				"men",
				"boy",
				"male",
				"blue",
				"human",
				"man",
				"gesture",
				"hand"
			]
		},
		"🙆‍♀️": {
			"name": "woman gesturing OK",
			"slug": "woman_gesturing_ok",
			"group": "People & Body",
			"emoji_version": "4.0",
			"unicode_version": "4.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "4.0",
			"aliases": [
				"woman_gesturing_ok",
				"women",
				"girl",
				"female",
				"pink",
				"human",
				"woman",
				"gesture",
				"hand"
			]
		},
		"💁": {
			"name": "person tipping hand",
			"slug": "person_tipping_hand",
			"group": "People & Body",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "1.0",
			"aliases": [
				"person_tipping_hand",
				"information",
				"attendant",
				"bellhop",
				"concierge",
				"desk",
				"female",
				"flick",
				"girl",
				"hair",
				"help",
				"sassy",
				"woman",
				"women"
			]
		},
		"💁‍♂️": {
			"name": "man tipping hand",
			"slug": "man_tipping_hand",
			"group": "People & Body",
			"emoji_version": "4.0",
			"unicode_version": "4.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "4.0",
			"aliases": [
				"man_tipping_hand",
				"male",
				"boy",
				"man",
				"human",
				"information",
				"desk",
				"help",
				"men",
				"sassy"
			]
		},
		"💁‍♀️": {
			"name": "woman tipping hand",
			"slug": "woman_tipping_hand",
			"group": "People & Body",
			"emoji_version": "4.0",
			"unicode_version": "4.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "4.0",
			"aliases": [
				"woman_tipping_hand",
				"female",
				"girl",
				"woman",
				"human",
				"information",
				"desk",
				"help",
				"sassy",
				"women"
			]
		},
		"🙋": {
			"name": "person raising hand",
			"slug": "person_raising_hand",
			"group": "People & Body",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "1.0",
			"aliases": [
				"person_raising_hand",
				"question",
				"answering",
				"gesture",
				"happy",
				"one",
				"raised",
				"up"
			]
		},
		"🙋‍♂️": {
			"name": "man raising hand",
			"slug": "man_raising_hand",
			"group": "People & Body",
			"emoji_version": "4.0",
			"unicode_version": "4.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "4.0",
			"aliases": [
				"man_raising_hand",
				"male",
				"boy",
				"man",
				"gesture",
				"happy",
				"men",
				"one",
				"raised"
			]
		},
		"🙋‍♀️": {
			"name": "woman raising hand",
			"slug": "woman_raising_hand",
			"group": "People & Body",
			"emoji_version": "4.0",
			"unicode_version": "4.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "4.0",
			"aliases": [
				"woman_raising_hand",
				"female",
				"girl",
				"woman",
				"gesture",
				"happy",
				"one",
				"raised",
				"women"
			]
		},
		"🧏": {
			"name": "deaf person",
			"slug": "deaf_person",
			"group": "People & Body",
			"emoji_version": "12.0",
			"unicode_version": "12.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "12.0",
			"aliases": [
				"deaf_person",
				"accessibility",
				"ear",
				"hear"
			]
		},
		"🧏‍♂️": {
			"name": "deaf man",
			"slug": "deaf_man",
			"group": "People & Body",
			"emoji_version": "12.0",
			"unicode_version": "12.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "12.0",
			"aliases": [
				"deaf_man",
				"accessibility",
				"male",
				"men"
			]
		},
		"🧏‍♀️": {
			"name": "deaf woman",
			"slug": "deaf_woman",
			"group": "People & Body",
			"emoji_version": "12.0",
			"unicode_version": "12.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "12.0",
			"aliases": [
				"deaf_woman",
				"accessibility",
				"female",
				"women"
			]
		},
		"🙇": {
			"name": "person bowing",
			"slug": "person_bowing",
			"group": "People & Body",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "1.0",
			"aliases": [
				"person_bowing",
				"respectiful",
				"apology",
				"bow",
				"boy",
				"cute",
				"deeply",
				"dogeza",
				"gesture",
				"man",
				"massage",
				"respect",
				"sorry",
				"thanks"
			]
		},
		"🙇‍♂️": {
			"name": "man bowing",
			"slug": "man_bowing",
			"group": "People & Body",
			"emoji_version": "4.0",
			"unicode_version": "4.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "4.0",
			"aliases": [
				"man_bowing",
				"man",
				"male",
				"boy",
				"apology",
				"bow",
				"deeply",
				"favor",
				"gesture",
				"men",
				"respect",
				"sorry",
				"thanks"
			]
		},
		"🙇‍♀️": {
			"name": "woman bowing",
			"slug": "woman_bowing",
			"group": "People & Body",
			"emoji_version": "4.0",
			"unicode_version": "4.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "4.0",
			"aliases": [
				"woman_bowing",
				"woman",
				"female",
				"girl",
				"apology",
				"bow",
				"deeply",
				"favor",
				"gesture",
				"respect",
				"sorry",
				"thanks",
				"women"
			]
		},
		"🤦": {
			"name": "person facepalming",
			"slug": "person_facepalming",
			"group": "People & Body",
			"emoji_version": "3.0",
			"unicode_version": "3.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "3.0",
			"aliases": [
				"person_facepalming",
				"disappointed",
				"disbelief",
				"exasperation",
				"face",
				"facepalm",
				"head",
				"hitting",
				"palm",
				"picard",
				"smh"
			]
		},
		"🤦‍♂️": {
			"name": "man facepalming",
			"slug": "man_facepalming",
			"group": "People & Body",
			"emoji_version": "4.0",
			"unicode_version": "4.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "4.0",
			"aliases": [
				"man_facepalming",
				"man",
				"male",
				"boy",
				"disbelief",
				"exasperation",
				"face",
				"facepalm",
				"men",
				"palm"
			]
		},
		"🤦‍♀️": {
			"name": "woman facepalming",
			"slug": "woman_facepalming",
			"group": "People & Body",
			"emoji_version": "4.0",
			"unicode_version": "4.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "4.0",
			"aliases": [
				"woman_facepalming",
				"woman",
				"female",
				"girl",
				"disbelief",
				"exasperation",
				"face",
				"facepalm",
				"palm",
				"women"
			]
		},
		"🤷": {
			"name": "person shrugging",
			"slug": "person_shrugging",
			"group": "People & Body",
			"emoji_version": "3.0",
			"unicode_version": "3.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "3.0",
			"aliases": [
				"person_shrugging",
				"regardless",
				"doubt",
				"ignorance",
				"indifference",
				"shrug",
				"shruggie",
				"¯\\"
			]
		},
		"🤷‍♂️": {
			"name": "man shrugging",
			"slug": "man_shrugging",
			"group": "People & Body",
			"emoji_version": "4.0",
			"unicode_version": "4.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "4.0",
			"aliases": [
				"man_shrugging",
				"man",
				"male",
				"boy",
				"confused",
				"indifferent",
				"doubt",
				"ignorance",
				"indifference",
				"men",
				"shrug"
			]
		},
		"🤷‍♀️": {
			"name": "woman shrugging",
			"slug": "woman_shrugging",
			"group": "People & Body",
			"emoji_version": "4.0",
			"unicode_version": "4.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "4.0",
			"aliases": [
				"woman_shrugging",
				"woman",
				"female",
				"girl",
				"confused",
				"indifferent",
				"doubt",
				"ignorance",
				"indifference",
				"shrug",
				"women"
			]
		},
		"🧑‍⚕️": {
			"name": "health worker",
			"slug": "health_worker",
			"group": "People & Body",
			"emoji_version": "12.1",
			"unicode_version": "12.1",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "12.1",
			"aliases": [
				"health_worker",
				"hospital",
				"dentist",
				"doctor",
				"healthcare",
				"md",
				"nurse",
				"physician",
				"professional",
				"therapist"
			]
		},
		"👨‍⚕️": {
			"name": "man health worker",
			"slug": "man_health_worker",
			"group": "People & Body",
			"emoji_version": "4.0",
			"unicode_version": "4.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "4.0",
			"aliases": [
				"man_health_worker",
				"doctor",
				"nurse",
				"therapist",
				"healthcare",
				"man",
				"human",
				"dentist",
				"male",
				"md",
				"men",
				"physician",
				"professional"
			]
		},
		"👩‍⚕️": {
			"name": "woman health worker",
			"slug": "woman_health_worker",
			"group": "People & Body",
			"emoji_version": "4.0",
			"unicode_version": "4.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "4.0",
			"aliases": [
				"woman_health_worker",
				"doctor",
				"nurse",
				"therapist",
				"healthcare",
				"woman",
				"human",
				"dentist",
				"female",
				"md",
				"physician",
				"professional",
				"women"
			]
		},
		"🧑‍🎓": {
			"name": "student",
			"slug": "student",
			"group": "People & Body",
			"emoji_version": "12.1",
			"unicode_version": "12.1",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "12.1",
			"aliases": [
				"student",
				"learn",
				"education",
				"graduate",
				"pupil",
				"school"
			]
		},
		"👨‍🎓": {
			"name": "man student",
			"slug": "man_student",
			"group": "People & Body",
			"emoji_version": "4.0",
			"unicode_version": "4.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "4.0",
			"aliases": [
				"man_student",
				"graduate",
				"man",
				"human",
				"education",
				"graduation",
				"male",
				"men",
				"pupil",
				"school"
			]
		},
		"👩‍🎓": {
			"name": "woman student",
			"slug": "woman_student",
			"group": "People & Body",
			"emoji_version": "4.0",
			"unicode_version": "4.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "4.0",
			"aliases": [
				"woman_student",
				"graduate",
				"woman",
				"human",
				"education",
				"female",
				"graduation",
				"pupil",
				"school",
				"women"
			]
		},
		"🧑‍🏫": {
			"name": "teacher",
			"slug": "teacher",
			"group": "People & Body",
			"emoji_version": "12.1",
			"unicode_version": "12.1",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "12.1",
			"aliases": [
				"teacher",
				"professor",
				"education",
				"educator",
				"instructor"
			]
		},
		"👨‍🏫": {
			"name": "man teacher",
			"slug": "man_teacher",
			"group": "People & Body",
			"emoji_version": "4.0",
			"unicode_version": "4.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "4.0",
			"aliases": [
				"man_teacher",
				"instructor",
				"professor",
				"man",
				"human",
				"education",
				"educator",
				"male",
				"men",
				"school"
			]
		},
		"👩‍🏫": {
			"name": "woman teacher",
			"slug": "woman_teacher",
			"group": "People & Body",
			"emoji_version": "4.0",
			"unicode_version": "4.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "4.0",
			"aliases": [
				"woman_teacher",
				"instructor",
				"professor",
				"woman",
				"human",
				"education",
				"educator",
				"female",
				"school",
				"women"
			]
		},
		"🧑‍⚖️": {
			"name": "judge",
			"slug": "judge",
			"group": "People & Body",
			"emoji_version": "12.1",
			"unicode_version": "12.1",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "12.1",
			"aliases": [
				"judge",
				"law",
				"court",
				"justice",
				"scales"
			]
		},
		"👨‍⚖️": {
			"name": "man judge",
			"slug": "man_judge",
			"group": "People & Body",
			"emoji_version": "4.0",
			"unicode_version": "4.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "4.0",
			"aliases": [
				"man_judge",
				"justice",
				"court",
				"man",
				"human",
				"law",
				"male",
				"men",
				"scales"
			]
		},
		"👩‍⚖️": {
			"name": "woman judge",
			"slug": "woman_judge",
			"group": "People & Body",
			"emoji_version": "4.0",
			"unicode_version": "4.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "4.0",
			"aliases": [
				"woman_judge",
				"justice",
				"court",
				"woman",
				"human",
				"female",
				"law",
				"scales",
				"women"
			]
		},
		"🧑‍🌾": {
			"name": "farmer",
			"slug": "farmer",
			"group": "People & Body",
			"emoji_version": "12.1",
			"unicode_version": "12.1",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "12.1",
			"aliases": [
				"farmer",
				"crops",
				"farm",
				"farming",
				"gardener",
				"rancher",
				"worker"
			]
		},
		"👨‍🌾": {
			"name": "man farmer",
			"slug": "man_farmer",
			"group": "People & Body",
			"emoji_version": "4.0",
			"unicode_version": "4.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "4.0",
			"aliases": [
				"man_farmer",
				"rancher",
				"gardener",
				"man",
				"human",
				"farm",
				"farming",
				"male",
				"men",
				"worker"
			]
		},
		"👩‍🌾": {
			"name": "woman farmer",
			"slug": "woman_farmer",
			"group": "People & Body",
			"emoji_version": "4.0",
			"unicode_version": "4.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "4.0",
			"aliases": [
				"woman_farmer",
				"rancher",
				"gardener",
				"woman",
				"human",
				"farm",
				"farming",
				"female",
				"women",
				"worker"
			]
		},
		"🧑‍🍳": {
			"name": "cook",
			"slug": "cook",
			"group": "People & Body",
			"emoji_version": "12.1",
			"unicode_version": "12.1",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "12.1",
			"aliases": [
				"cook",
				"food",
				"kitchen",
				"culinary",
				"chef",
				"cooking",
				"service"
			]
		},
		"👨‍🍳": {
			"name": "man cook",
			"slug": "man_cook",
			"group": "People & Body",
			"emoji_version": "4.0",
			"unicode_version": "4.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "4.0",
			"aliases": [
				"man_cook",
				"chef",
				"man",
				"human",
				"cooking",
				"food",
				"male",
				"men",
				"service"
			]
		},
		"👩‍🍳": {
			"name": "woman cook",
			"slug": "woman_cook",
			"group": "People & Body",
			"emoji_version": "4.0",
			"unicode_version": "4.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "4.0",
			"aliases": [
				"woman_cook",
				"chef",
				"woman",
				"human",
				"cooking",
				"female",
				"food",
				"service",
				"women"
			]
		},
		"🧑‍🔧": {
			"name": "mechanic",
			"slug": "mechanic",
			"group": "People & Body",
			"emoji_version": "12.1",
			"unicode_version": "12.1",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "12.1",
			"aliases": [
				"mechanic",
				"worker",
				"technician",
				"electrician",
				"person",
				"plumber",
				"repair",
				"tradesperson"
			]
		},
		"👨‍🔧": {
			"name": "man mechanic",
			"slug": "man_mechanic",
			"group": "People & Body",
			"emoji_version": "4.0",
			"unicode_version": "4.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "4.0",
			"aliases": [
				"man_mechanic",
				"plumber",
				"man",
				"human",
				"wrench",
				"electrician",
				"male",
				"men",
				"person",
				"repair",
				"tradesperson"
			]
		},
		"👩‍🔧": {
			"name": "woman mechanic",
			"slug": "woman_mechanic",
			"group": "People & Body",
			"emoji_version": "4.0",
			"unicode_version": "4.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "4.0",
			"aliases": [
				"woman_mechanic",
				"plumber",
				"woman",
				"human",
				"wrench",
				"electrician",
				"female",
				"person",
				"repair",
				"tradesperson",
				"women"
			]
		},
		"🧑‍🏭": {
			"name": "factory worker",
			"slug": "factory_worker",
			"group": "People & Body",
			"emoji_version": "12.1",
			"unicode_version": "12.1",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "12.1",
			"aliases": [
				"factory_worker",
				"labor",
				"assembly",
				"industrial",
				"welder"
			]
		},
		"👨‍🏭": {
			"name": "man factory worker",
			"slug": "man_factory_worker",
			"group": "People & Body",
			"emoji_version": "4.0",
			"unicode_version": "4.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "4.0",
			"aliases": [
				"man_factory_worker",
				"assembly",
				"industrial",
				"man",
				"human",
				"male",
				"men",
				"welder"
			]
		},
		"👩‍🏭": {
			"name": "woman factory worker",
			"slug": "woman_factory_worker",
			"group": "People & Body",
			"emoji_version": "4.0",
			"unicode_version": "4.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "4.0",
			"aliases": [
				"woman_factory_worker",
				"assembly",
				"industrial",
				"woman",
				"human",
				"female",
				"welder",
				"women"
			]
		},
		"🧑‍💼": {
			"name": "office worker",
			"slug": "office_worker",
			"group": "People & Body",
			"emoji_version": "12.1",
			"unicode_version": "12.1",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "12.1",
			"aliases": [
				"office_worker",
				"business",
				"accountant",
				"adviser",
				"analyst",
				"architect",
				"banker",
				"clerk",
				"manager"
			]
		},
		"👨‍💼": {
			"name": "man office worker",
			"slug": "man_office_worker",
			"group": "People & Body",
			"emoji_version": "4.0",
			"unicode_version": "4.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "4.0",
			"aliases": [
				"man_office_worker",
				"business",
				"manager",
				"man",
				"human",
				"accountant",
				"adviser",
				"analyst",
				"architect",
				"banker",
				"businessman",
				"ceo",
				"clerk",
				"male",
				"men"
			]
		},
		"👩‍💼": {
			"name": "woman office worker",
			"slug": "woman_office_worker",
			"group": "People & Body",
			"emoji_version": "4.0",
			"unicode_version": "4.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "4.0",
			"aliases": [
				"woman_office_worker",
				"business",
				"manager",
				"woman",
				"human",
				"accountant",
				"adviser",
				"analyst",
				"architect",
				"banker",
				"businesswoman",
				"ceo",
				"clerk",
				"female",
				"women"
			]
		},
		"🧑‍🔬": {
			"name": "scientist",
			"slug": "scientist",
			"group": "People & Body",
			"emoji_version": "12.1",
			"unicode_version": "12.1",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "12.1",
			"aliases": [
				"scientist",
				"chemistry",
				"biologist",
				"chemist",
				"engineer",
				"lab",
				"mathematician",
				"physicist",
				"technician"
			]
		},
		"👨‍🔬": {
			"name": "man scientist",
			"slug": "man_scientist",
			"group": "People & Body",
			"emoji_version": "4.0",
			"unicode_version": "4.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "4.0",
			"aliases": [
				"man_scientist",
				"biologist",
				"chemist",
				"engineer",
				"physicist",
				"man",
				"human",
				"lab",
				"male",
				"mathematician",
				"men",
				"research",
				"technician"
			]
		},
		"👩‍🔬": {
			"name": "woman scientist",
			"slug": "woman_scientist",
			"group": "People & Body",
			"emoji_version": "4.0",
			"unicode_version": "4.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "4.0",
			"aliases": [
				"woman_scientist",
				"biologist",
				"chemist",
				"engineer",
				"physicist",
				"woman",
				"human",
				"female",
				"lab",
				"mathematician",
				"research",
				"technician",
				"women"
			]
		},
		"🧑‍💻": {
			"name": "technologist",
			"slug": "technologist",
			"group": "People & Body",
			"emoji_version": "12.1",
			"unicode_version": "12.1",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "12.1",
			"aliases": [
				"technologist",
				"computer",
				"coder",
				"engineer",
				"laptop",
				"software",
				"technology",
				"developer"
			]
		},
		"👨‍💻": {
			"name": "man technologist",
			"slug": "man_technologist",
			"group": "People & Body",
			"emoji_version": "4.0",
			"unicode_version": "4.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "4.0",
			"aliases": [
				"man_technologist",
				"coder",
				"developer",
				"engineer",
				"programmer",
				"software",
				"man",
				"human",
				"laptop",
				"computer",
				"blogger",
				"male",
				"men",
				"technology"
			]
		},
		"👩‍💻": {
			"name": "woman technologist",
			"slug": "woman_technologist",
			"group": "People & Body",
			"emoji_version": "4.0",
			"unicode_version": "4.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "4.0",
			"aliases": [
				"woman_technologist",
				"coder",
				"developer",
				"engineer",
				"programmer",
				"software",
				"woman",
				"human",
				"laptop",
				"computer",
				"blogger",
				"female",
				"technology",
				"women"
			]
		},
		"🧑‍🎤": {
			"name": "singer",
			"slug": "singer",
			"group": "People & Body",
			"emoji_version": "12.1",
			"unicode_version": "12.1",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "12.1",
			"aliases": [
				"singer",
				"song",
				"artist",
				"performer",
				"actor",
				"entertainer",
				"music",
				"musician",
				"rock",
				"rocker",
				"rockstar",
				"star"
			]
		},
		"👨‍🎤": {
			"name": "man singer",
			"slug": "man_singer",
			"group": "People & Body",
			"emoji_version": "4.0",
			"unicode_version": "4.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "4.0",
			"aliases": [
				"man_singer",
				"rockstar",
				"entertainer",
				"man",
				"human",
				"actor",
				"aladdin",
				"bowie",
				"male",
				"men",
				"music",
				"musician",
				"rock",
				"rocker",
				"sane",
				"star"
			]
		},
		"👩‍🎤": {
			"name": "woman singer",
			"slug": "woman_singer",
			"group": "People & Body",
			"emoji_version": "4.0",
			"unicode_version": "4.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "4.0",
			"aliases": [
				"woman_singer",
				"rockstar",
				"entertainer",
				"woman",
				"human",
				"actor",
				"female",
				"music",
				"musician",
				"rock",
				"rocker",
				"star",
				"women"
			]
		},
		"🧑‍🎨": {
			"name": "artist",
			"slug": "artist",
			"group": "People & Body",
			"emoji_version": "12.1",
			"unicode_version": "12.1",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "12.1",
			"aliases": [
				"artist",
				"painting",
				"draw",
				"creativity",
				"art",
				"paint",
				"painter",
				"palette"
			]
		},
		"👨‍🎨": {
			"name": "man artist",
			"slug": "man_artist",
			"group": "People & Body",
			"emoji_version": "4.0",
			"unicode_version": "4.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "4.0",
			"aliases": [
				"man_artist",
				"painter",
				"man",
				"human",
				"art",
				"male",
				"men",
				"paint",
				"palette"
			]
		},
		"👩‍🎨": {
			"name": "woman artist",
			"slug": "woman_artist",
			"group": "People & Body",
			"emoji_version": "4.0",
			"unicode_version": "4.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "4.0",
			"aliases": [
				"woman_artist",
				"painter",
				"woman",
				"human",
				"art",
				"female",
				"paint",
				"palette",
				"women"
			]
		},
		"🧑‍✈️": {
			"name": "pilot",
			"slug": "pilot",
			"group": "People & Body",
			"emoji_version": "12.1",
			"unicode_version": "12.1",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "12.1",
			"aliases": [
				"pilot",
				"fly",
				"plane",
				"airplane",
				"aviation",
				"aviator"
			]
		},
		"👨‍✈️": {
			"name": "man pilot",
			"slug": "man_pilot",
			"group": "People & Body",
			"emoji_version": "4.0",
			"unicode_version": "4.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "4.0",
			"aliases": [
				"man_pilot",
				"aviator",
				"plane",
				"man",
				"human",
				"airplane",
				"aviation",
				"male",
				"men"
			]
		},
		"👩‍✈️": {
			"name": "woman pilot",
			"slug": "woman_pilot",
			"group": "People & Body",
			"emoji_version": "4.0",
			"unicode_version": "4.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "4.0",
			"aliases": [
				"woman_pilot",
				"aviator",
				"plane",
				"woman",
				"human",
				"airplane",
				"aviation",
				"female",
				"women"
			]
		},
		"🧑‍🚀": {
			"name": "astronaut",
			"slug": "astronaut",
			"group": "People & Body",
			"emoji_version": "12.1",
			"unicode_version": "12.1",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "12.1",
			"aliases": [
				"astronaut",
				"outerspace",
				"moon",
				"planets",
				"rocket",
				"space",
				"stars"
			]
		},
		"👨‍🚀": {
			"name": "man astronaut",
			"slug": "man_astronaut",
			"group": "People & Body",
			"emoji_version": "4.0",
			"unicode_version": "4.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "4.0",
			"aliases": [
				"man_astronaut",
				"space",
				"rocket",
				"man",
				"human",
				"cosmonaut",
				"male",
				"men",
				"moon",
				"planets",
				"stars"
			]
		},
		"👩‍🚀": {
			"name": "woman astronaut",
			"slug": "woman_astronaut",
			"group": "People & Body",
			"emoji_version": "4.0",
			"unicode_version": "4.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "4.0",
			"aliases": [
				"woman_astronaut",
				"space",
				"rocket",
				"woman",
				"human",
				"cosmonaut",
				"female",
				"moon",
				"planets",
				"stars",
				"women"
			]
		},
		"🧑‍🚒": {
			"name": "firefighter",
			"slug": "firefighter",
			"group": "People & Body",
			"emoji_version": "12.1",
			"unicode_version": "12.1",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "12.1",
			"aliases": [
				"firefighter",
				"fire",
				"firetruck"
			]
		},
		"👨‍🚒": {
			"name": "man firefighter",
			"slug": "man_firefighter",
			"group": "People & Body",
			"emoji_version": "4.0",
			"unicode_version": "4.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "4.0",
			"aliases": [
				"man_firefighter",
				"fireman",
				"man",
				"human",
				"fire",
				"firetruck",
				"male",
				"men"
			]
		},
		"👩‍🚒": {
			"name": "woman firefighter",
			"slug": "woman_firefighter",
			"group": "People & Body",
			"emoji_version": "4.0",
			"unicode_version": "4.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "4.0",
			"aliases": [
				"woman_firefighter",
				"fireman",
				"woman",
				"human",
				"female",
				"fire",
				"firetruck",
				"women"
			]
		},
		"👮": {
			"name": "police officer",
			"slug": "police_officer",
			"group": "People & Body",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "1.0",
			"aliases": [
				"police_officer",
				"cop",
				"law",
				"policeman",
				"policewoman"
			]
		},
		"👮‍♂️": {
			"name": "man police officer",
			"slug": "man_police_officer",
			"group": "People & Body",
			"emoji_version": "4.0",
			"unicode_version": "4.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "4.0",
			"aliases": [
				"man_police_officer",
				"man",
				"police",
				"law",
				"legal",
				"enforcement",
				"arrest",
				"911",
				"cop",
				"male",
				"men",
				"policeman"
			]
		},
		"👮‍♀️": {
			"name": "woman police officer",
			"slug": "woman_police_officer",
			"group": "People & Body",
			"emoji_version": "4.0",
			"unicode_version": "4.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "4.0",
			"aliases": [
				"woman_police_officer",
				"woman",
				"police",
				"law",
				"legal",
				"enforcement",
				"arrest",
				"911",
				"female",
				"cop",
				"policewoman",
				"women"
			]
		},
		"🕵️": {
			"name": "detective",
			"slug": "detective",
			"group": "People & Body",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "2.0",
			"aliases": [
				"detective",
				"human",
				"spy",
				"eye",
				"or",
				"private",
				"sleuth"
			]
		},
		"🕵️‍♂️": {
			"name": "man detective",
			"slug": "man_detective",
			"group": "People & Body",
			"emoji_version": "4.0",
			"unicode_version": "4.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "4.0",
			"aliases": [
				"man_detective",
				"crime",
				"male",
				"men",
				"sleuth",
				"spy"
			]
		},
		"🕵️‍♀️": {
			"name": "woman detective",
			"slug": "woman_detective",
			"group": "People & Body",
			"emoji_version": "4.0",
			"unicode_version": "4.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "4.0",
			"aliases": [
				"woman_detective",
				"human",
				"spy",
				"detective",
				"female",
				"woman",
				"sleuth",
				"women"
			]
		},
		"💂": {
			"name": "guard",
			"slug": "guard",
			"group": "People & Body",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "1.0",
			"aliases": [
				"guard",
				"protect",
				"british",
				"guardsman"
			]
		},
		"💂‍♂️": {
			"name": "man guard",
			"slug": "man_guard",
			"group": "People & Body",
			"emoji_version": "4.0",
			"unicode_version": "4.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "4.0",
			"aliases": [
				"man_guard",
				"uk",
				"gb",
				"british",
				"male",
				"guy",
				"royal",
				"guardsman",
				"men"
			]
		},
		"💂‍♀️": {
			"name": "woman guard",
			"slug": "woman_guard",
			"group": "People & Body",
			"emoji_version": "4.0",
			"unicode_version": "4.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "4.0",
			"aliases": [
				"woman_guard",
				"uk",
				"gb",
				"british",
				"female",
				"royal",
				"woman",
				"guardsman",
				"guardswoman",
				"women"
			]
		},
		"🥷": {
			"name": "ninja",
			"slug": "ninja",
			"group": "People & Body",
			"emoji_version": "13.0",
			"unicode_version": "13.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "13.0",
			"aliases": [
				"ninja",
				"ninjutsu",
				"skills",
				"japanese",
				"fighter",
				"hidden",
				"stealth"
			]
		},
		"👷": {
			"name": "construction worker",
			"slug": "construction_worker",
			"group": "People & Body",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "1.0",
			"aliases": [
				"construction_worker",
				"labor",
				"build",
				"builder",
				"face",
				"hard",
				"hat",
				"helmet",
				"safety",
				"add_ci",
				"update_ci"
			]
		},
		"👷‍♂️": {
			"name": "man construction worker",
			"slug": "man_construction_worker",
			"group": "People & Body",
			"emoji_version": "4.0",
			"unicode_version": "4.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "4.0",
			"aliases": [
				"man_construction_worker",
				"male",
				"human",
				"wip",
				"guy",
				"build",
				"construction",
				"worker",
				"labor",
				"helmet",
				"men"
			]
		},
		"👷‍♀️": {
			"name": "woman construction worker",
			"slug": "woman_construction_worker",
			"group": "People & Body",
			"emoji_version": "4.0",
			"unicode_version": "4.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "4.0",
			"aliases": [
				"woman_construction_worker",
				"female",
				"human",
				"wip",
				"build",
				"construction",
				"worker",
				"labor",
				"woman",
				"helmet",
				"women"
			]
		},
		"🫅": {
			"name": "person with crown",
			"slug": "person_with_crown",
			"group": "People & Body",
			"emoji_version": "14.0",
			"unicode_version": "14.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "14.0",
			"aliases": [
				"person with crown",
				"royalty",
				"power",
				"monarch",
				"noble",
				"regal"
			]
		},
		"🤴": {
			"name": "prince",
			"slug": "prince",
			"group": "People & Body",
			"emoji_version": "3.0",
			"unicode_version": "3.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "3.0",
			"aliases": [
				"prince",
				"boy",
				"man",
				"male",
				"crown",
				"royal",
				"king",
				"fairy",
				"fantasy",
				"men",
				"tale"
			]
		},
		"👸": {
			"name": "princess",
			"slug": "princess",
			"group": "People & Body",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "1.0",
			"aliases": [
				"princess",
				"girl",
				"woman",
				"female",
				"blond",
				"crown",
				"royal",
				"queen",
				"blonde",
				"fairy",
				"fantasy",
				"tale",
				"tiara",
				"women"
			]
		},
		"👳": {
			"name": "person wearing turban",
			"slug": "person_wearing_turban",
			"group": "People & Body",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "1.0",
			"aliases": [
				"person_wearing_turban",
				"headdress",
				"arab",
				"man",
				"muslim",
				"sikh"
			]
		},
		"👳‍♂️": {
			"name": "man wearing turban",
			"slug": "man_wearing_turban",
			"group": "People & Body",
			"emoji_version": "4.0",
			"unicode_version": "4.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "4.0",
			"aliases": [
				"man_wearing_turban",
				"male",
				"indian",
				"hinduism",
				"arabs",
				"men"
			]
		},
		"👳‍♀️": {
			"name": "woman wearing turban",
			"slug": "woman_wearing_turban",
			"group": "People & Body",
			"emoji_version": "4.0",
			"unicode_version": "4.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "4.0",
			"aliases": [
				"woman_wearing_turban",
				"female",
				"indian",
				"hinduism",
				"arabs",
				"woman",
				"women"
			]
		},
		"👲": {
			"name": "person with skullcap",
			"slug": "person_with_skullcap",
			"group": "People & Body",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "1.0",
			"aliases": [
				"man_with_skullcap",
				"male",
				"boy",
				"chinese",
				"asian",
				"cap",
				"gua",
				"hat",
				"mao",
				"person",
				"pi"
			]
		},
		"🧕": {
			"name": "woman with headscarf",
			"slug": "woman_with_headscarf",
			"group": "People & Body",
			"emoji_version": "5.0",
			"unicode_version": "5.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "5.0",
			"aliases": [
				"woman_with_headscarf",
				"female",
				"hijab",
				"mantilla",
				"tichel"
			]
		},
		"🤵": {
			"name": "person in tuxedo",
			"slug": "person_in_tuxedo",
			"group": "People & Body",
			"emoji_version": "3.0",
			"unicode_version": "3.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "3.0",
			"aliases": [
				"man_in_tuxedo",
				"couple",
				"marriage",
				"wedding",
				"groom",
				"male",
				"men",
				"person",
				"suit"
			]
		},
		"🤵‍♂️": {
			"name": "man in tuxedo",
			"slug": "man_in_tuxedo",
			"group": "People & Body",
			"emoji_version": "13.0",
			"unicode_version": "13.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "13.0",
			"aliases": [
				"man in tuxedo",
				"formal",
				"fashion",
				"groom",
				"male",
				"men",
				"person",
				"suit",
				"wedding"
			]
		},
		"🤵‍♀️": {
			"name": "woman in tuxedo",
			"slug": "woman_in_tuxedo",
			"group": "People & Body",
			"emoji_version": "13.0",
			"unicode_version": "13.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "13.0",
			"aliases": [
				"woman in tuxedo",
				"formal",
				"fashion",
				"female",
				"wedding",
				"women"
			]
		},
		"👰": {
			"name": "person with veil",
			"slug": "person_with_veil",
			"group": "People & Body",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "1.0",
			"aliases": [
				"bride_with_veil",
				"couple",
				"marriage",
				"wedding",
				"woman",
				"bride",
				"person"
			]
		},
		"👰‍♂️": {
			"name": "man with veil",
			"slug": "man_with_veil",
			"group": "People & Body",
			"emoji_version": "13.0",
			"unicode_version": "13.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "13.0",
			"aliases": [
				"man with veil",
				"wedding",
				"marriage",
				"bride",
				"male",
				"men"
			]
		},
		"👰‍♀️": {
			"name": "woman with veil",
			"slug": "woman_with_veil",
			"group": "People & Body",
			"emoji_version": "13.0",
			"unicode_version": "13.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "13.0",
			"aliases": [
				"woman with veil",
				"wedding",
				"marriage",
				"bride",
				"female",
				"women"
			]
		},
		"🤰": {
			"name": "pregnant woman",
			"slug": "pregnant_woman",
			"group": "People & Body",
			"emoji_version": "3.0",
			"unicode_version": "3.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "3.0",
			"aliases": [
				"pregnant_woman",
				"baby",
				"female",
				"pregnancy",
				"pregnant\xA0lady",
				"women"
			]
		},
		"🫃": {
			"name": "pregnant man",
			"slug": "pregnant_man",
			"group": "People & Body",
			"emoji_version": "14.0",
			"unicode_version": "14.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "14.0",
			"aliases": [
				"pregnant man",
				"baby",
				"belly",
				"bloated",
				"full"
			]
		},
		"🫄": {
			"name": "pregnant person",
			"slug": "pregnant_person",
			"group": "People & Body",
			"emoji_version": "14.0",
			"unicode_version": "14.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "14.0",
			"aliases": [
				"pregnant person",
				"baby",
				"belly",
				"bloated",
				"full"
			]
		},
		"🤱": {
			"name": "breast-feeding",
			"slug": "breast_feeding",
			"group": "People & Body",
			"emoji_version": "5.0",
			"unicode_version": "5.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "5.0",
			"aliases": [
				"breast_feeding",
				"nursing",
				"baby",
				"breastfeeding",
				"child",
				"female",
				"infant",
				"milk",
				"mother",
				"woman",
				"women"
			]
		},
		"👩‍🍼": {
			"name": "woman feeding baby",
			"slug": "woman_feeding_baby",
			"group": "People & Body",
			"emoji_version": "13.0",
			"unicode_version": "13.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "13.0",
			"aliases": [
				"woman feeding baby",
				"birth",
				"food",
				"bottle",
				"child",
				"female",
				"infant",
				"milk",
				"nursing",
				"women"
			]
		},
		"👨‍🍼": {
			"name": "man feeding baby",
			"slug": "man_feeding_baby",
			"group": "People & Body",
			"emoji_version": "13.0",
			"unicode_version": "13.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "13.0",
			"aliases": [
				"man feeding baby",
				"birth",
				"food",
				"bottle",
				"child",
				"infant",
				"male",
				"men",
				"milk",
				"nursing"
			]
		},
		"🧑‍🍼": {
			"name": "person feeding baby",
			"slug": "person_feeding_baby",
			"group": "People & Body",
			"emoji_version": "13.0",
			"unicode_version": "13.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "13.0",
			"aliases": [
				"person feeding baby",
				"birth",
				"food",
				"bottle",
				"child",
				"infant",
				"milk",
				"nursing"
			]
		},
		"👼": {
			"name": "baby angel",
			"slug": "baby_angel",
			"group": "People & Body",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "1.0",
			"aliases": [
				"baby_angel",
				"heaven",
				"wings",
				"halo",
				"cherub",
				"cupid",
				"face",
				"fairy",
				"fantasy",
				"putto",
				"tale"
			]
		},
		"🎅": {
			"name": "Santa Claus",
			"slug": "santa_claus",
			"group": "People & Body",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "1.0",
			"aliases": [
				"santa_claus",
				"festival",
				"man",
				"male",
				"xmas",
				"father christmas",
				"activity",
				"celebration",
				"men",
				"nicholas",
				"saint",
				"sinterklaas"
			]
		},
		"🤶": {
			"name": "Mrs. Claus",
			"slug": "mrs_claus",
			"group": "People & Body",
			"emoji_version": "3.0",
			"unicode_version": "3.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "3.0",
			"aliases": [
				"mrs_claus",
				"woman",
				"female",
				"xmas",
				"mother christmas",
				"activity",
				"celebration",
				"mrs.",
				"santa",
				"women"
			]
		},
		"🧑‍🎄": {
			"name": "Mx Claus",
			"slug": "mx_claus",
			"group": "People & Body",
			"emoji_version": "13.0",
			"unicode_version": "13.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "13.0",
			"aliases": [
				"mx claus",
				"christmas",
				"activity",
				"celebration",
				"mx.",
				"santa"
			]
		},
		"🦸": {
			"name": "superhero",
			"slug": "superhero",
			"group": "People & Body",
			"emoji_version": "11.0",
			"unicode_version": "11.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "11.0",
			"aliases": [
				"superhero",
				"marvel",
				"fantasy",
				"good",
				"hero",
				"heroine",
				"superpower",
				"superpowers"
			]
		},
		"🦸‍♂️": {
			"name": "man superhero",
			"slug": "man_superhero",
			"group": "People & Body",
			"emoji_version": "11.0",
			"unicode_version": "11.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "11.0",
			"aliases": [
				"man_superhero",
				"man",
				"male",
				"good",
				"hero",
				"superpowers",
				"fantasy",
				"men",
				"superpower"
			]
		},
		"🦸‍♀️": {
			"name": "woman superhero",
			"slug": "woman_superhero",
			"group": "People & Body",
			"emoji_version": "11.0",
			"unicode_version": "11.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "11.0",
			"aliases": [
				"woman_superhero",
				"woman",
				"female",
				"good",
				"heroine",
				"superpowers",
				"fantasy",
				"hero",
				"superpower",
				"women"
			]
		},
		"🦹": {
			"name": "supervillain",
			"slug": "supervillain",
			"group": "People & Body",
			"emoji_version": "11.0",
			"unicode_version": "11.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "11.0",
			"aliases": [
				"supervillain",
				"marvel",
				"bad",
				"criminal",
				"evil",
				"fantasy",
				"superpower",
				"superpowers",
				"villain"
			]
		},
		"🦹‍♂️": {
			"name": "man supervillain",
			"slug": "man_supervillain",
			"group": "People & Body",
			"emoji_version": "11.0",
			"unicode_version": "11.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "11.0",
			"aliases": [
				"man_supervillain",
				"man",
				"male",
				"evil",
				"bad",
				"criminal",
				"hero",
				"superpowers",
				"fantasy",
				"men",
				"superpower",
				"villain"
			]
		},
		"🦹‍♀️": {
			"name": "woman supervillain",
			"slug": "woman_supervillain",
			"group": "People & Body",
			"emoji_version": "11.0",
			"unicode_version": "11.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "11.0",
			"aliases": [
				"woman_supervillain",
				"woman",
				"female",
				"evil",
				"bad",
				"criminal",
				"heroine",
				"superpowers",
				"fantasy",
				"superpower",
				"villain",
				"women"
			]
		},
		"🧙": {
			"name": "mage",
			"slug": "mage",
			"group": "People & Body",
			"emoji_version": "5.0",
			"unicode_version": "5.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "5.0",
			"aliases": [
				"mage",
				"magic",
				"fantasy",
				"sorcerer",
				"sorceress",
				"witch",
				"wizard"
			]
		},
		"🧙‍♂️": {
			"name": "man mage",
			"slug": "man_mage",
			"group": "People & Body",
			"emoji_version": "5.0",
			"unicode_version": "5.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "5.0",
			"aliases": [
				"man_mage",
				"man",
				"male",
				"mage",
				"sorcerer",
				"fantasy",
				"men",
				"wizard"
			]
		},
		"🧙‍♀️": {
			"name": "woman mage",
			"slug": "woman_mage",
			"group": "People & Body",
			"emoji_version": "5.0",
			"unicode_version": "5.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "5.0",
			"aliases": [
				"woman_mage",
				"woman",
				"female",
				"mage",
				"witch",
				"fantasy",
				"sorceress",
				"wizard",
				"women"
			]
		},
		"🧚": {
			"name": "fairy",
			"slug": "fairy",
			"group": "People & Body",
			"emoji_version": "5.0",
			"unicode_version": "5.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "5.0",
			"aliases": [
				"fairy",
				"wings",
				"magical",
				"fantasy",
				"oberon",
				"puck",
				"titania"
			]
		},
		"🧚‍♂️": {
			"name": "man fairy",
			"slug": "man_fairy",
			"group": "People & Body",
			"emoji_version": "5.0",
			"unicode_version": "5.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "5.0",
			"aliases": [
				"man_fairy",
				"man",
				"male",
				"fantasy",
				"men",
				"oberon",
				"puck"
			]
		},
		"🧚‍♀️": {
			"name": "woman fairy",
			"slug": "woman_fairy",
			"group": "People & Body",
			"emoji_version": "5.0",
			"unicode_version": "5.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "5.0",
			"aliases": [
				"woman_fairy",
				"woman",
				"female",
				"fantasy",
				"titania",
				"wings",
				"women"
			]
		},
		"🧛": {
			"name": "vampire",
			"slug": "vampire",
			"group": "People & Body",
			"emoji_version": "5.0",
			"unicode_version": "5.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "5.0",
			"aliases": [
				"vampire",
				"blood",
				"twilight",
				"dracula",
				"fantasy",
				"undead"
			]
		},
		"🧛‍♂️": {
			"name": "man vampire",
			"slug": "man_vampire",
			"group": "People & Body",
			"emoji_version": "5.0",
			"unicode_version": "5.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "5.0",
			"aliases": [
				"man_vampire",
				"man",
				"male",
				"dracula",
				"fantasy",
				"men",
				"undead"
			]
		},
		"🧛‍♀️": {
			"name": "woman vampire",
			"slug": "woman_vampire",
			"group": "People & Body",
			"emoji_version": "5.0",
			"unicode_version": "5.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "5.0",
			"aliases": [
				"woman_vampire",
				"woman",
				"female",
				"fantasy",
				"undead",
				"unded",
				"women"
			]
		},
		"🧜": {
			"name": "merperson",
			"slug": "merperson",
			"group": "People & Body",
			"emoji_version": "5.0",
			"unicode_version": "5.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "5.0",
			"aliases": [
				"merperson",
				"sea",
				"fantasy",
				"merboy",
				"mergirl",
				"mermaid",
				"merman",
				"merwoman"
			]
		},
		"🧜‍♂️": {
			"name": "merman",
			"slug": "merman",
			"group": "People & Body",
			"emoji_version": "5.0",
			"unicode_version": "5.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "5.0",
			"aliases": [
				"merman",
				"man",
				"male",
				"triton",
				"fantasy",
				"men",
				"mermaid"
			]
		},
		"🧜‍♀️": {
			"name": "mermaid",
			"slug": "mermaid",
			"group": "People & Body",
			"emoji_version": "5.0",
			"unicode_version": "5.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "5.0",
			"aliases": [
				"mermaid",
				"woman",
				"female",
				"merwoman",
				"ariel",
				"fantasy",
				"women"
			]
		},
		"🧝": {
			"name": "elf",
			"slug": "elf",
			"group": "People & Body",
			"emoji_version": "5.0",
			"unicode_version": "5.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "5.0",
			"aliases": [
				"elf",
				"magical",
				"ears",
				"fantasy",
				"legolas",
				"pointed"
			]
		},
		"🧝‍♂️": {
			"name": "man elf",
			"slug": "man_elf",
			"group": "People & Body",
			"emoji_version": "5.0",
			"unicode_version": "5.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "5.0",
			"aliases": [
				"man_elf",
				"man",
				"male",
				"ears",
				"fantasy",
				"magical",
				"men",
				"pointed"
			]
		},
		"🧝‍♀️": {
			"name": "woman elf",
			"slug": "woman_elf",
			"group": "People & Body",
			"emoji_version": "5.0",
			"unicode_version": "5.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "5.0",
			"aliases": [
				"woman_elf",
				"woman",
				"female",
				"ears",
				"fantasy",
				"magical",
				"pointed",
				"women"
			]
		},
		"🧞": {
			"name": "genie",
			"slug": "genie",
			"group": "People & Body",
			"emoji_version": "5.0",
			"unicode_version": "5.0",
			"skin_tone_support": false,
			"aliases": [
				"genie",
				"magical",
				"wishes",
				"djinn",
				"djinni",
				"fantasy",
				"jinni"
			]
		},
		"🧞‍♂️": {
			"name": "man genie",
			"slug": "man_genie",
			"group": "People & Body",
			"emoji_version": "5.0",
			"unicode_version": "5.0",
			"skin_tone_support": false,
			"aliases": [
				"man_genie",
				"man",
				"male",
				"djinn",
				"fantasy",
				"men"
			]
		},
		"🧞‍♀️": {
			"name": "woman genie",
			"slug": "woman_genie",
			"group": "People & Body",
			"emoji_version": "5.0",
			"unicode_version": "5.0",
			"skin_tone_support": false,
			"aliases": [
				"woman_genie",
				"woman",
				"female",
				"djinn",
				"fantasy",
				"women"
			]
		},
		"🧟": {
			"name": "zombie",
			"slug": "zombie",
			"group": "People & Body",
			"emoji_version": "5.0",
			"unicode_version": "5.0",
			"skin_tone_support": false,
			"aliases": [
				"zombie",
				"dead",
				"fantasy",
				"undead",
				"walking"
			]
		},
		"🧟‍♂️": {
			"name": "man zombie",
			"slug": "man_zombie",
			"group": "People & Body",
			"emoji_version": "5.0",
			"unicode_version": "5.0",
			"skin_tone_support": false,
			"aliases": [
				"man_zombie",
				"man",
				"male",
				"dracula",
				"undead",
				"walking dead",
				"fantasy",
				"men"
			]
		},
		"🧟‍♀️": {
			"name": "woman zombie",
			"slug": "woman_zombie",
			"group": "People & Body",
			"emoji_version": "5.0",
			"unicode_version": "5.0",
			"skin_tone_support": false,
			"aliases": [
				"woman_zombie",
				"woman",
				"female",
				"undead",
				"walking dead",
				"fantasy",
				"women"
			]
		},
		"🧌": {
			"name": "troll",
			"slug": "troll",
			"group": "People & Body",
			"emoji_version": "14.0",
			"unicode_version": "14.0",
			"skin_tone_support": false,
			"aliases": [
				"troll",
				"mystical",
				"monster",
				"fairy",
				"fantasy",
				"tale",
				"shrek"
			]
		},
		"🫈": {
			"name": "hairy creature",
			"slug": "hairy_creature",
			"group": "People & Body",
			"emoji_version": "17.0",
			"unicode_version": "17.0",
			"skin_tone_support": false,
			"aliases": [
				"hairy creature",
				"sasquatch",
				"bigfoot",
				"treeman"
			]
		},
		"💆": {
			"name": "person getting massage",
			"slug": "person_getting_massage",
			"group": "People & Body",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "1.0",
			"aliases": [
				"person_getting_massage",
				"relax",
				"face",
				"head",
				"massaging",
				"salon",
				"spa"
			]
		},
		"💆‍♂️": {
			"name": "man getting massage",
			"slug": "man_getting_massage",
			"group": "People & Body",
			"emoji_version": "4.0",
			"unicode_version": "4.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "4.0",
			"aliases": [
				"man_getting_massage",
				"male",
				"boy",
				"man",
				"head",
				"face",
				"men",
				"salon",
				"spa"
			]
		},
		"💆‍♀️": {
			"name": "woman getting massage",
			"slug": "woman_getting_massage",
			"group": "People & Body",
			"emoji_version": "4.0",
			"unicode_version": "4.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "4.0",
			"aliases": [
				"woman_getting_massage",
				"female",
				"girl",
				"woman",
				"head",
				"face",
				"salon",
				"spa",
				"women"
			]
		},
		"💇": {
			"name": "person getting haircut",
			"slug": "person_getting_haircut",
			"group": "People & Body",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "1.0",
			"aliases": [
				"person_getting_haircut",
				"hairstyle",
				"barber",
				"beauty",
				"cutting",
				"hair",
				"hairdresser",
				"parlor"
			]
		},
		"💇‍♂️": {
			"name": "man getting haircut",
			"slug": "man_getting_haircut",
			"group": "People & Body",
			"emoji_version": "4.0",
			"unicode_version": "4.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "4.0",
			"aliases": [
				"man_getting_haircut",
				"male",
				"boy",
				"man",
				"barber",
				"beauty",
				"men",
				"parlor"
			]
		},
		"💇‍♀️": {
			"name": "woman getting haircut",
			"slug": "woman_getting_haircut",
			"group": "People & Body",
			"emoji_version": "4.0",
			"unicode_version": "4.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "4.0",
			"aliases": [
				"woman_getting_haircut",
				"female",
				"girl",
				"woman",
				"barber",
				"beauty",
				"parlor",
				"women"
			]
		},
		"🚶": {
			"name": "person walking",
			"slug": "person_walking",
			"group": "People & Body",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "1.0",
			"aliases": [
				"person_walking",
				"move",
				"hike",
				"pedestrian",
				"walk",
				"walker"
			]
		},
		"🚶‍♂️": {
			"name": "man walking",
			"slug": "man_walking",
			"group": "People & Body",
			"emoji_version": "4.0",
			"unicode_version": "4.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "4.0",
			"aliases": [
				"man_walking",
				"human",
				"feet",
				"steps",
				"hike",
				"male",
				"men",
				"pedestrian",
				"walk"
			]
		},
		"🚶‍♀️": {
			"name": "woman walking",
			"slug": "woman_walking",
			"group": "People & Body",
			"emoji_version": "4.0",
			"unicode_version": "4.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "4.0",
			"aliases": [
				"woman_walking",
				"human",
				"feet",
				"steps",
				"woman",
				"female",
				"hike",
				"pedestrian",
				"walk",
				"women"
			]
		},
		"🚶‍➡️": {
			"name": "person walking facing right",
			"slug": "person_walking_facing_right",
			"group": "People & Body",
			"emoji_version": "15.1",
			"unicode_version": "15.1",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "15.1",
			"aliases": [
				"person walking facing right",
				"peerson",
				"exercise"
			]
		},
		"🚶‍♀️‍➡️": {
			"name": "woman walking facing right",
			"slug": "woman_walking_facing_right",
			"group": "People & Body",
			"emoji_version": "15.1",
			"unicode_version": "15.1",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "15.1",
			"aliases": [
				"woman walking facing right",
				"person",
				"exercise"
			]
		},
		"🚶‍♂️‍➡️": {
			"name": "man walking facing right",
			"slug": "man_walking_facing_right",
			"group": "People & Body",
			"emoji_version": "15.1",
			"unicode_version": "15.1",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "15.1",
			"aliases": [
				"man walking facing right",
				"person",
				"exercise"
			]
		},
		"🧍": {
			"name": "person standing",
			"slug": "person_standing",
			"group": "People & Body",
			"emoji_version": "12.0",
			"unicode_version": "12.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "12.0",
			"aliases": [
				"person_standing",
				"still",
				"stand"
			]
		},
		"🧍‍♂️": {
			"name": "man standing",
			"slug": "man_standing",
			"group": "People & Body",
			"emoji_version": "12.0",
			"unicode_version": "12.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "12.0",
			"aliases": [
				"man_standing",
				"still",
				"male",
				"men",
				"stand"
			]
		},
		"🧍‍♀️": {
			"name": "woman standing",
			"slug": "woman_standing",
			"group": "People & Body",
			"emoji_version": "12.0",
			"unicode_version": "12.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "12.0",
			"aliases": [
				"woman_standing",
				"still",
				"female",
				"stand",
				"women"
			]
		},
		"🧎": {
			"name": "person kneeling",
			"slug": "person_kneeling",
			"group": "People & Body",
			"emoji_version": "12.0",
			"unicode_version": "12.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "12.0",
			"aliases": [
				"person_kneeling",
				"pray",
				"respectful",
				"kneel"
			]
		},
		"🧎‍♂️": {
			"name": "man kneeling",
			"slug": "man_kneeling",
			"group": "People & Body",
			"emoji_version": "12.0",
			"unicode_version": "12.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "12.0",
			"aliases": [
				"man_kneeling",
				"pray",
				"respectful",
				"kneel",
				"male",
				"men"
			]
		},
		"🧎‍♀️": {
			"name": "woman kneeling",
			"slug": "woman_kneeling",
			"group": "People & Body",
			"emoji_version": "12.0",
			"unicode_version": "12.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "12.0",
			"aliases": [
				"woman_kneeling",
				"respectful",
				"pray",
				"female",
				"kneel",
				"women"
			]
		},
		"🧎‍➡️": {
			"name": "person kneeling facing right",
			"slug": "person_kneeling_facing_right",
			"group": "People & Body",
			"emoji_version": "15.1",
			"unicode_version": "15.1",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "15.1",
			"aliases": ["person kneeling facing right", "pray"]
		},
		"🧎‍♀️‍➡️": {
			"name": "woman kneeling facing right",
			"slug": "woman_kneeling_facing_right",
			"group": "People & Body",
			"emoji_version": "15.1",
			"unicode_version": "15.1",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "15.1",
			"aliases": [
				"woman kneeling facing right",
				"pray",
				"worship"
			]
		},
		"🧎‍♂️‍➡️": {
			"name": "man kneeling facing right",
			"slug": "man_kneeling_facing_right",
			"group": "People & Body",
			"emoji_version": "15.1",
			"unicode_version": "15.1",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "15.1",
			"aliases": [
				"man kneeling facing right",
				"pray",
				"worship"
			]
		},
		"🧑‍🦯": {
			"name": "person with white cane",
			"slug": "person_with_white_cane",
			"group": "People & Body",
			"emoji_version": "12.1",
			"unicode_version": "12.1",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "12.1",
			"aliases": [
				"person_with_probing_cane",
				"blind",
				"accessibility",
				"white"
			]
		},
		"🧑‍🦯‍➡️": {
			"name": "person with white cane facing right",
			"slug": "person_with_white_cane_facing_right",
			"group": "People & Body",
			"emoji_version": "15.1",
			"unicode_version": "15.1",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "15.1",
			"aliases": [
				"person with white cane facing right",
				"walk",
				"walk",
				"visually impaired",
				"blind"
			]
		},
		"👨‍🦯": {
			"name": "man with white cane",
			"slug": "man_with_white_cane",
			"group": "People & Body",
			"emoji_version": "12.0",
			"unicode_version": "12.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "12.0",
			"aliases": [
				"man_with_probing_cane",
				"blind",
				"accessibility",
				"male",
				"men",
				"white"
			]
		},
		"👨‍🦯‍➡️": {
			"name": "man with white cane facing right",
			"slug": "man_with_white_cane_facing_right",
			"group": "People & Body",
			"emoji_version": "15.1",
			"unicode_version": "15.1",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "15.1",
			"aliases": [
				"man with white cane facing right",
				"visually impaired",
				"blind",
				"walk",
				"stick"
			]
		},
		"👩‍🦯": {
			"name": "woman with white cane",
			"slug": "woman_with_white_cane",
			"group": "People & Body",
			"emoji_version": "12.0",
			"unicode_version": "12.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "12.0",
			"aliases": [
				"woman_with_probing_cane",
				"blind",
				"accessibility",
				"female",
				"white",
				"women"
			]
		},
		"👩‍🦯‍➡️": {
			"name": "woman with white cane facing right",
			"slug": "woman_with_white_cane_facing_right",
			"group": "People & Body",
			"emoji_version": "15.1",
			"unicode_version": "15.1",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "15.1",
			"aliases": [
				"woman with white cane facing right",
				"stick",
				"visually impaired",
				"blind"
			]
		},
		"🧑‍🦼": {
			"name": "person in motorized wheelchair",
			"slug": "person_in_motorized_wheelchair",
			"group": "People & Body",
			"emoji_version": "12.1",
			"unicode_version": "12.1",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "12.1",
			"aliases": [
				"person_in_motorized_wheelchair",
				"disability",
				"accessibility"
			]
		},
		"🧑‍🦼‍➡️": {
			"name": "person in motorized wheelchair facing right",
			"slug": "person_in_motorized_wheelchair_facing_right",
			"group": "People & Body",
			"emoji_version": "15.1",
			"unicode_version": "15.1",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "15.1",
			"aliases": [
				"person in motorized wheelchair facing right",
				"accessibility",
				"disability"
			]
		},
		"👨‍🦼": {
			"name": "man in motorized wheelchair",
			"slug": "man_in_motorized_wheelchair",
			"group": "People & Body",
			"emoji_version": "12.0",
			"unicode_version": "12.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "12.0",
			"aliases": [
				"man_in_motorized_wheelchair",
				"disability",
				"accessibility",
				"male",
				"men"
			]
		},
		"👨‍🦼‍➡️": {
			"name": "man in motorized wheelchair facing right",
			"slug": "man_in_motorized_wheelchair_facing_right",
			"group": "People & Body",
			"emoji_version": "15.1",
			"unicode_version": "15.1",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "15.1",
			"aliases": [
				"man in motorized wheelchair facing right",
				"disability",
				"accessibility",
				"mobility"
			]
		},
		"👩‍🦼": {
			"name": "woman in motorized wheelchair",
			"slug": "woman_in_motorized_wheelchair",
			"group": "People & Body",
			"emoji_version": "12.0",
			"unicode_version": "12.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "12.0",
			"aliases": [
				"woman_in_motorized_wheelchair",
				"disability",
				"accessibility",
				"female",
				"women"
			]
		},
		"👩‍🦼‍➡️": {
			"name": "woman in motorized wheelchair facing right",
			"slug": "woman_in_motorized_wheelchair_facing_right",
			"group": "People & Body",
			"emoji_version": "15.1",
			"unicode_version": "15.1",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "15.1",
			"aliases": [
				"woman in motorized wheelchair facing right",
				"mobility",
				"accessibility",
				"disability"
			]
		},
		"🧑‍🦽": {
			"name": "person in manual wheelchair",
			"slug": "person_in_manual_wheelchair",
			"group": "People & Body",
			"emoji_version": "12.1",
			"unicode_version": "12.1",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "12.1",
			"aliases": [
				"person_in_manual_wheelchair",
				"disability",
				"accessibility"
			]
		},
		"🧑‍🦽‍➡️": {
			"name": "person in manual wheelchair facing right",
			"slug": "person_in_manual_wheelchair_facing_right",
			"group": "People & Body",
			"emoji_version": "15.1",
			"unicode_version": "15.1",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "15.1",
			"aliases": [
				"person in manual wheelchair facing right",
				"mobility",
				"accessibility",
				"disability"
			]
		},
		"👨‍🦽": {
			"name": "man in manual wheelchair",
			"slug": "man_in_manual_wheelchair",
			"group": "People & Body",
			"emoji_version": "12.0",
			"unicode_version": "12.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "12.0",
			"aliases": [
				"man_in_manual_wheelchair",
				"disability",
				"accessibility",
				"male",
				"men"
			]
		},
		"👨‍🦽‍➡️": {
			"name": "man in manual wheelchair facing right",
			"slug": "man_in_manual_wheelchair_facing_right",
			"group": "People & Body",
			"emoji_version": "15.1",
			"unicode_version": "15.1",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "15.1",
			"aliases": [
				"man in manual wheelchair facing right",
				"mobility",
				"accessibility",
				"disability"
			]
		},
		"👩‍🦽": {
			"name": "woman in manual wheelchair",
			"slug": "woman_in_manual_wheelchair",
			"group": "People & Body",
			"emoji_version": "12.0",
			"unicode_version": "12.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "12.0",
			"aliases": [
				"woman_in_manual_wheelchair",
				"disability",
				"accessibility",
				"female",
				"women"
			]
		},
		"👩‍🦽‍➡️": {
			"name": "woman in manual wheelchair facing right",
			"slug": "woman_in_manual_wheelchair_facing_right",
			"group": "People & Body",
			"emoji_version": "15.1",
			"unicode_version": "15.1",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "15.1",
			"aliases": [
				"woman in manual wheelchair facing right",
				"disability",
				"mobility",
				"accessibility"
			]
		},
		"🏃": {
			"name": "person running",
			"slug": "person_running",
			"group": "People & Body",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "1.0",
			"aliases": [
				"person_running",
				"move",
				"exercise",
				"jogging",
				"marathon",
				"run",
				"runner",
				"workout"
			]
		},
		"🏃‍♂️": {
			"name": "man running",
			"slug": "man_running",
			"group": "People & Body",
			"emoji_version": "4.0",
			"unicode_version": "4.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "4.0",
			"aliases": [
				"man_running",
				"man",
				"walking",
				"exercise",
				"race",
				"running",
				"male",
				"marathon",
				"men",
				"racing",
				"runner",
				"workout"
			]
		},
		"🏃‍♀️": {
			"name": "woman running",
			"slug": "woman_running",
			"group": "People & Body",
			"emoji_version": "4.0",
			"unicode_version": "4.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "4.0",
			"aliases": [
				"woman_running",
				"woman",
				"walking",
				"exercise",
				"race",
				"running",
				"female",
				"boy",
				"marathon",
				"racing",
				"runner",
				"women",
				"workout"
			]
		},
		"🏃‍➡️": {
			"name": "person running facing right",
			"slug": "person_running_facing_right",
			"group": "People & Body",
			"emoji_version": "15.1",
			"unicode_version": "15.1",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "15.1",
			"aliases": [
				"person running facing right",
				"exercise",
				"jog"
			]
		},
		"🏃‍♀️‍➡️": {
			"name": "woman running facing right",
			"slug": "woman_running_facing_right",
			"group": "People & Body",
			"emoji_version": "15.1",
			"unicode_version": "15.1",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "15.1",
			"aliases": [
				"woman running facing right",
				"exercise",
				"jog"
			]
		},
		"🏃‍♂️‍➡️": {
			"name": "man running facing right",
			"slug": "man_running_facing_right",
			"group": "People & Body",
			"emoji_version": "15.1",
			"unicode_version": "15.1",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "15.1",
			"aliases": [
				"man running facing right",
				"jog",
				"exercise"
			]
		},
		"🧑‍🩰": {
			"name": "ballet dancer",
			"slug": "ballet_dancer",
			"group": "People & Body",
			"emoji_version": "17.0",
			"unicode_version": "17.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "17.0",
			"aliases": ["ballet dancer"]
		},
		"💃": {
			"name": "woman dancing",
			"slug": "woman_dancing",
			"group": "People & Body",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "1.0",
			"aliases": [
				"woman_dancing",
				"female",
				"girl",
				"woman",
				"fun",
				"dance",
				"dancer",
				"dress",
				"red",
				"salsa",
				"women"
			]
		},
		"🕺": {
			"name": "man dancing",
			"slug": "man_dancing",
			"group": "People & Body",
			"emoji_version": "3.0",
			"unicode_version": "3.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "3.0",
			"aliases": [
				"man_dancing",
				"male",
				"boy",
				"fun",
				"dancer",
				"dance",
				"disco",
				"men"
			]
		},
		"🕴️": {
			"name": "person in suit levitating",
			"slug": "person_in_suit_levitating",
			"group": "People & Body",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "4.0",
			"aliases": [
				"man_in_suit_levitating",
				"suit",
				"business",
				"levitate",
				"hover",
				"jump",
				"boy",
				"hovering",
				"jabsco",
				"male",
				"men",
				"person",
				"rude",
				"walt"
			]
		},
		"👯": {
			"name": "people with bunny ears",
			"slug": "people_with_bunny_ears",
			"group": "People & Body",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "17.0",
			"aliases": [
				"people_with_bunny_ears",
				"perform",
				"costume",
				"dancer",
				"dancing",
				"ear",
				"partying",
				"wearing",
				"women"
			]
		},
		"👯‍♂️": {
			"name": "men with bunny ears",
			"slug": "men_with_bunny_ears",
			"group": "People & Body",
			"emoji_version": "4.0",
			"unicode_version": "4.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "17.0",
			"aliases": [
				"men_with_bunny_ears",
				"male",
				"bunny",
				"men",
				"boys",
				"dancer",
				"dancing",
				"ear",
				"man",
				"partying",
				"wearing"
			]
		},
		"👯‍♀️": {
			"name": "women with bunny ears",
			"slug": "women_with_bunny_ears",
			"group": "People & Body",
			"emoji_version": "4.0",
			"unicode_version": "4.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "17.0",
			"aliases": [
				"women_with_bunny_ears",
				"female",
				"bunny",
				"women",
				"girls",
				"dancer",
				"dancing",
				"ear",
				"partying",
				"people",
				"wearing"
			]
		},
		"🧖": {
			"name": "person in steamy room",
			"slug": "person_in_steamy_room",
			"group": "People & Body",
			"emoji_version": "5.0",
			"unicode_version": "5.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "5.0",
			"aliases": [
				"person_in_steamy_room",
				"relax",
				"spa",
				"hamam",
				"sauna",
				"steam",
				"steambath"
			]
		},
		"🧖‍♂️": {
			"name": "man in steamy room",
			"slug": "man_in_steamy_room",
			"group": "People & Body",
			"emoji_version": "5.0",
			"unicode_version": "5.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "5.0",
			"aliases": [
				"man_in_steamy_room",
				"male",
				"man",
				"spa",
				"steamroom",
				"sauna",
				"hamam",
				"men",
				"steam",
				"steambath"
			]
		},
		"🧖‍♀️": {
			"name": "woman in steamy room",
			"slug": "woman_in_steamy_room",
			"group": "People & Body",
			"emoji_version": "5.0",
			"unicode_version": "5.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "5.0",
			"aliases": [
				"woman_in_steamy_room",
				"female",
				"woman",
				"spa",
				"steamroom",
				"sauna",
				"hamam",
				"steam",
				"steambath",
				"women"
			]
		},
		"🧗": {
			"name": "person climbing",
			"slug": "person_climbing",
			"group": "People & Body",
			"emoji_version": "5.0",
			"unicode_version": "5.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "5.0",
			"aliases": [
				"person_climbing",
				"sport",
				"bouldering",
				"climber",
				"rock"
			]
		},
		"🧗‍♂️": {
			"name": "man climbing",
			"slug": "man_climbing",
			"group": "People & Body",
			"emoji_version": "5.0",
			"unicode_version": "5.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "5.0",
			"aliases": [
				"man_climbing",
				"sports",
				"hobby",
				"man",
				"male",
				"rock",
				"bouldering",
				"climber",
				"men"
			]
		},
		"🧗‍♀️": {
			"name": "woman climbing",
			"slug": "woman_climbing",
			"group": "People & Body",
			"emoji_version": "5.0",
			"unicode_version": "5.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "5.0",
			"aliases": [
				"woman_climbing",
				"sports",
				"hobby",
				"woman",
				"female",
				"rock",
				"bouldering",
				"climber",
				"women"
			]
		},
		"🤺": {
			"name": "person fencing",
			"slug": "person_fencing",
			"group": "People & Body",
			"emoji_version": "3.0",
			"unicode_version": "3.0",
			"skin_tone_support": false,
			"aliases": [
				"person_fencing",
				"sports",
				"fencing",
				"sword",
				"fencer"
			]
		},
		"🏇": {
			"name": "horse racing",
			"slug": "horse_racing",
			"group": "People & Body",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "1.0",
			"aliases": [
				"horse_racing",
				"animal",
				"betting",
				"competition",
				"gambling",
				"luck",
				"jockey",
				"race",
				"racehorse"
			]
		},
		"⛷️": {
			"name": "skier",
			"slug": "skier",
			"group": "People & Body",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"skier",
				"sports",
				"winter",
				"snow",
				"ski"
			]
		},
		"🏂": {
			"name": "snowboarder",
			"slug": "snowboarder",
			"group": "People & Body",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "1.0",
			"aliases": [
				"snowboarder",
				"sports",
				"winter",
				"ski",
				"snow",
				"snowboard",
				"snowboarding"
			]
		},
		"🏌️": {
			"name": "person golfing",
			"slug": "person_golfing",
			"group": "People & Body",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "4.0",
			"aliases": [
				"person_golfing",
				"sports",
				"business",
				"ball",
				"club",
				"golf",
				"golfer"
			]
		},
		"🏌️‍♂️": {
			"name": "man golfing",
			"slug": "man_golfing",
			"group": "People & Body",
			"emoji_version": "4.0",
			"unicode_version": "4.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "4.0",
			"aliases": [
				"man_golfing",
				"sport",
				"ball",
				"golf",
				"golfer",
				"male",
				"men"
			]
		},
		"🏌️‍♀️": {
			"name": "woman golfing",
			"slug": "woman_golfing",
			"group": "People & Body",
			"emoji_version": "4.0",
			"unicode_version": "4.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "4.0",
			"aliases": [
				"woman_golfing",
				"sports",
				"business",
				"woman",
				"female",
				"ball",
				"golf",
				"golfer",
				"women"
			]
		},
		"🏄": {
			"name": "person surfing",
			"slug": "person_surfing",
			"group": "People & Body",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "1.0",
			"aliases": [
				"person_surfing",
				"sport",
				"sea",
				"surf",
				"surfer"
			]
		},
		"🏄‍♂️": {
			"name": "man surfing",
			"slug": "man_surfing",
			"group": "People & Body",
			"emoji_version": "4.0",
			"unicode_version": "4.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "4.0",
			"aliases": [
				"man_surfing",
				"sports",
				"ocean",
				"sea",
				"summer",
				"beach",
				"male",
				"men",
				"surfer"
			]
		},
		"🏄‍♀️": {
			"name": "woman surfing",
			"slug": "woman_surfing",
			"group": "People & Body",
			"emoji_version": "4.0",
			"unicode_version": "4.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "4.0",
			"aliases": [
				"woman_surfing",
				"sports",
				"ocean",
				"sea",
				"summer",
				"beach",
				"woman",
				"female",
				"surfer",
				"women"
			]
		},
		"🚣": {
			"name": "person rowing boat",
			"slug": "person_rowing_boat",
			"group": "People & Body",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "1.0",
			"aliases": [
				"person_rowing_boat",
				"sport",
				"move",
				"paddles",
				"rowboat",
				"vehicle"
			]
		},
		"🚣‍♂️": {
			"name": "man rowing boat",
			"slug": "man_rowing_boat",
			"group": "People & Body",
			"emoji_version": "4.0",
			"unicode_version": "4.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "4.0",
			"aliases": [
				"man_rowing_boat",
				"sports",
				"hobby",
				"water",
				"ship",
				"male",
				"men",
				"rowboat",
				"vehicle"
			]
		},
		"🚣‍♀️": {
			"name": "woman rowing boat",
			"slug": "woman_rowing_boat",
			"group": "People & Body",
			"emoji_version": "4.0",
			"unicode_version": "4.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "4.0",
			"aliases": [
				"woman_rowing_boat",
				"sports",
				"hobby",
				"water",
				"ship",
				"woman",
				"female",
				"rowboat",
				"vehicle",
				"women"
			]
		},
		"🏊": {
			"name": "person swimming",
			"slug": "person_swimming",
			"group": "People & Body",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "1.0",
			"aliases": [
				"person_swimming",
				"sport",
				"pool",
				"swim",
				"swimmer"
			]
		},
		"🏊‍♂️": {
			"name": "man swimming",
			"slug": "man_swimming",
			"group": "People & Body",
			"emoji_version": "4.0",
			"unicode_version": "4.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "4.0",
			"aliases": [
				"man_swimming",
				"sports",
				"exercise",
				"human",
				"athlete",
				"water",
				"summer",
				"male",
				"men",
				"swim",
				"swimmer"
			]
		},
		"🏊‍♀️": {
			"name": "woman swimming",
			"slug": "woman_swimming",
			"group": "People & Body",
			"emoji_version": "4.0",
			"unicode_version": "4.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "4.0",
			"aliases": [
				"woman_swimming",
				"sports",
				"exercise",
				"human",
				"athlete",
				"water",
				"summer",
				"woman",
				"female",
				"swim",
				"swimmer",
				"women"
			]
		},
		"⛹️": {
			"name": "person bouncing ball",
			"slug": "person_bouncing_ball",
			"group": "People & Body",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "2.0",
			"aliases": [
				"person_bouncing_ball",
				"sports",
				"human",
				"basketball",
				"player"
			]
		},
		"⛹️‍♂️": {
			"name": "man bouncing ball",
			"slug": "man_bouncing_ball",
			"group": "People & Body",
			"emoji_version": "4.0",
			"unicode_version": "4.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "4.0",
			"aliases": [
				"man_bouncing_ball",
				"sport",
				"basketball",
				"male",
				"men",
				"player"
			]
		},
		"⛹️‍♀️": {
			"name": "woman bouncing ball",
			"slug": "woman_bouncing_ball",
			"group": "People & Body",
			"emoji_version": "4.0",
			"unicode_version": "4.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "4.0",
			"aliases": [
				"woman_bouncing_ball",
				"sports",
				"human",
				"woman",
				"female",
				"basketball",
				"player",
				"women"
			]
		},
		"🏋️": {
			"name": "person lifting weights",
			"slug": "person_lifting_weights",
			"group": "People & Body",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "2.0",
			"aliases": [
				"person_lifting_weights",
				"sports",
				"training",
				"exercise",
				"bodybuilder",
				"gym",
				"lifter",
				"weight",
				"weightlifter",
				"workout"
			]
		},
		"🏋️‍♂️": {
			"name": "man lifting weights",
			"slug": "man_lifting_weights",
			"group": "People & Body",
			"emoji_version": "4.0",
			"unicode_version": "4.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "4.0",
			"aliases": [
				"man_lifting_weights",
				"sport",
				"gym",
				"lifter",
				"male",
				"men",
				"weight",
				"weightlifter",
				"workout"
			]
		},
		"🏋️‍♀️": {
			"name": "woman lifting weights",
			"slug": "woman_lifting_weights",
			"group": "People & Body",
			"emoji_version": "4.0",
			"unicode_version": "4.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "4.0",
			"aliases": [
				"woman_lifting_weights",
				"sports",
				"training",
				"exercise",
				"woman",
				"female",
				"gym",
				"lifter",
				"weight",
				"weightlifter",
				"women",
				"workout"
			]
		},
		"🚴": {
			"name": "person biking",
			"slug": "person_biking",
			"group": "People & Body",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "1.0",
			"aliases": [
				"person_biking",
				"bicycle",
				"bike",
				"cyclist",
				"sport",
				"move",
				"bicyclist"
			]
		},
		"🚴‍♂️": {
			"name": "man biking",
			"slug": "man_biking",
			"group": "People & Body",
			"emoji_version": "4.0",
			"unicode_version": "4.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "4.0",
			"aliases": [
				"man_biking",
				"bicycle",
				"bike",
				"cyclist",
				"sports",
				"exercise",
				"hipster",
				"bicyclist",
				"male",
				"men"
			]
		},
		"🚴‍♀️": {
			"name": "woman biking",
			"slug": "woman_biking",
			"group": "People & Body",
			"emoji_version": "4.0",
			"unicode_version": "4.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "4.0",
			"aliases": [
				"woman_biking",
				"bicycle",
				"bike",
				"cyclist",
				"sports",
				"exercise",
				"hipster",
				"woman",
				"female",
				"bicyclist",
				"women"
			]
		},
		"🚵": {
			"name": "person mountain biking",
			"slug": "person_mountain_biking",
			"group": "People & Body",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "1.0",
			"aliases": [
				"person_mountain_biking",
				"bicycle",
				"bike",
				"cyclist",
				"sport",
				"move",
				"bicyclist",
				"biker"
			]
		},
		"🚵‍♂️": {
			"name": "man mountain biking",
			"slug": "man_mountain_biking",
			"group": "People & Body",
			"emoji_version": "4.0",
			"unicode_version": "4.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "4.0",
			"aliases": [
				"man_mountain_biking",
				"bicycle",
				"bike",
				"cyclist",
				"transportation",
				"sports",
				"human",
				"race",
				"bicyclist",
				"biker",
				"male",
				"men"
			]
		},
		"🚵‍♀️": {
			"name": "woman mountain biking",
			"slug": "woman_mountain_biking",
			"group": "People & Body",
			"emoji_version": "4.0",
			"unicode_version": "4.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "4.0",
			"aliases": [
				"woman_mountain_biking",
				"bicycle",
				"bike",
				"cyclist",
				"transportation",
				"sports",
				"human",
				"race",
				"woman",
				"female",
				"bicyclist",
				"biker",
				"women"
			]
		},
		"🤸": {
			"name": "person cartwheeling",
			"slug": "person_cartwheeling",
			"group": "People & Body",
			"emoji_version": "3.0",
			"unicode_version": "3.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "3.0",
			"aliases": [
				"person_cartwheeling",
				"sport",
				"gymnastic",
				"cartwheel",
				"doing",
				"gymnast",
				"gymnastics"
			]
		},
		"🤸‍♂️": {
			"name": "man cartwheeling",
			"slug": "man_cartwheeling",
			"group": "People & Body",
			"emoji_version": "4.0",
			"unicode_version": "4.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "4.0",
			"aliases": [
				"man_cartwheeling",
				"gymnastics",
				"cartwheel",
				"doing",
				"male",
				"men"
			]
		},
		"🤸‍♀️": {
			"name": "woman cartwheeling",
			"slug": "woman_cartwheeling",
			"group": "People & Body",
			"emoji_version": "4.0",
			"unicode_version": "4.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "4.0",
			"aliases": [
				"woman_cartwheeling",
				"gymnastics",
				"cartwheel",
				"doing",
				"female",
				"women"
			]
		},
		"🤼": {
			"name": "people wrestling",
			"slug": "people_wrestling",
			"group": "People & Body",
			"emoji_version": "3.0",
			"unicode_version": "3.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "17.0",
			"aliases": [
				"people_wrestling",
				"sport",
				"wrestle",
				"wrestler",
				"wrestlers"
			]
		},
		"🤼‍♂️": {
			"name": "men wrestling",
			"slug": "men_wrestling",
			"group": "People & Body",
			"emoji_version": "4.0",
			"unicode_version": "4.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "17.0",
			"aliases": [
				"men_wrestling",
				"sports",
				"wrestlers",
				"male",
				"man",
				"wrestle",
				"wrestler"
			]
		},
		"🤼‍♀️": {
			"name": "women wrestling",
			"slug": "women_wrestling",
			"group": "People & Body",
			"emoji_version": "4.0",
			"unicode_version": "4.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "17.0",
			"aliases": [
				"women_wrestling",
				"sports",
				"wrestlers",
				"female",
				"woman",
				"wrestle",
				"wrestler"
			]
		},
		"🤽": {
			"name": "person playing water polo",
			"slug": "person_playing_water_polo",
			"group": "People & Body",
			"emoji_version": "3.0",
			"unicode_version": "3.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "3.0",
			"aliases": ["person_playing_water_polo", "sport"]
		},
		"🤽‍♂️": {
			"name": "man playing water polo",
			"slug": "man_playing_water_polo",
			"group": "People & Body",
			"emoji_version": "4.0",
			"unicode_version": "4.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "4.0",
			"aliases": [
				"man_playing_water_polo",
				"sports",
				"pool",
				"male",
				"men"
			]
		},
		"🤽‍♀️": {
			"name": "woman playing water polo",
			"slug": "woman_playing_water_polo",
			"group": "People & Body",
			"emoji_version": "4.0",
			"unicode_version": "4.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "4.0",
			"aliases": [
				"woman_playing_water_polo",
				"sports",
				"pool",
				"female",
				"women"
			]
		},
		"🤾": {
			"name": "person playing handball",
			"slug": "person_playing_handball",
			"group": "People & Body",
			"emoji_version": "3.0",
			"unicode_version": "3.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "3.0",
			"aliases": [
				"person_playing_handball",
				"sport",
				"ball"
			]
		},
		"🤾‍♂️": {
			"name": "man playing handball",
			"slug": "man_playing_handball",
			"group": "People & Body",
			"emoji_version": "4.0",
			"unicode_version": "4.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "4.0",
			"aliases": [
				"man_playing_handball",
				"sports",
				"ball",
				"male",
				"men"
			]
		},
		"🤾‍♀️": {
			"name": "woman playing handball",
			"slug": "woman_playing_handball",
			"group": "People & Body",
			"emoji_version": "4.0",
			"unicode_version": "4.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "4.0",
			"aliases": [
				"woman_playing_handball",
				"sports",
				"ball",
				"female",
				"women"
			]
		},
		"🤹": {
			"name": "person juggling",
			"slug": "person_juggling",
			"group": "People & Body",
			"emoji_version": "3.0",
			"unicode_version": "3.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "3.0",
			"aliases": [
				"person_juggling",
				"performance",
				"balance",
				"juggle",
				"juggler",
				"multitask",
				"skill"
			]
		},
		"🤹‍♂️": {
			"name": "man juggling",
			"slug": "man_juggling",
			"group": "People & Body",
			"emoji_version": "4.0",
			"unicode_version": "4.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "4.0",
			"aliases": [
				"man_juggling",
				"juggle",
				"balance",
				"skill",
				"multitask",
				"juggler",
				"male",
				"men"
			]
		},
		"🤹‍♀️": {
			"name": "woman juggling",
			"slug": "woman_juggling",
			"group": "People & Body",
			"emoji_version": "4.0",
			"unicode_version": "4.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "4.0",
			"aliases": [
				"woman_juggling",
				"juggle",
				"balance",
				"skill",
				"multitask",
				"female",
				"juggler",
				"women"
			]
		},
		"🧘": {
			"name": "person in lotus position",
			"slug": "person_in_lotus_position",
			"group": "People & Body",
			"emoji_version": "5.0",
			"unicode_version": "5.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "5.0",
			"aliases": [
				"person_in_lotus_position",
				"meditate",
				"meditation",
				"serenity",
				"yoga"
			]
		},
		"🧘‍♂️": {
			"name": "man in lotus position",
			"slug": "man_in_lotus_position",
			"group": "People & Body",
			"emoji_version": "5.0",
			"unicode_version": "5.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "5.0",
			"aliases": [
				"man_in_lotus_position",
				"man",
				"male",
				"meditation",
				"yoga",
				"serenity",
				"zen",
				"mindfulness",
				"men"
			]
		},
		"🧘‍♀️": {
			"name": "woman in lotus position",
			"slug": "woman_in_lotus_position",
			"group": "People & Body",
			"emoji_version": "5.0",
			"unicode_version": "5.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "5.0",
			"aliases": [
				"woman_in_lotus_position",
				"woman",
				"female",
				"meditation",
				"yoga",
				"serenity",
				"zen",
				"mindfulness",
				"women"
			]
		},
		"🛀": {
			"name": "person taking bath",
			"slug": "person_taking_bath",
			"group": "People & Body",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "1.0",
			"aliases": [
				"person_taking_bath",
				"clean",
				"shower",
				"bathroom",
				"bathing",
				"bathtub",
				"hot"
			]
		},
		"🛌": {
			"name": "person in bed",
			"slug": "person_in_bed",
			"group": "People & Body",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "4.0",
			"aliases": [
				"person_in_bed",
				"bed",
				"rest",
				"accommodation",
				"hotel",
				"sleep",
				"sleeping"
			]
		},
		"🧑‍🤝‍🧑": {
			"name": "people holding hands",
			"slug": "people_holding_hands",
			"group": "People & Body",
			"emoji_version": "12.0",
			"unicode_version": "12.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "12.0",
			"aliases": [
				"people_holding_hands",
				"friendship",
				"couple",
				"date",
				"gender",
				"hand",
				"hold",
				"inclusive",
				"neutral",
				"nonconforming"
			]
		},
		"👭": {
			"name": "women holding hands",
			"slug": "women_holding_hands",
			"group": "People & Body",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "12.0",
			"aliases": [
				"women_holding_hands",
				"pair",
				"friendship",
				"couple",
				"love",
				"like",
				"female",
				"people",
				"human",
				"date",
				"hand",
				"hold",
				"lesbian",
				"lgbt",
				"pride",
				"two",
				"woman"
			]
		},
		"👫": {
			"name": "woman and man holding hands",
			"slug": "woman_and_man_holding_hands",
			"group": "People & Body",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "12.0",
			"aliases": [
				"woman_and_man_holding_hands",
				"pair",
				"people",
				"human",
				"love",
				"date",
				"dating",
				"like",
				"affection",
				"valentines",
				"marriage",
				"couple",
				"female",
				"hand",
				"heterosexual",
				"hold",
				"male",
				"men",
				"straight",
				"women"
			]
		},
		"👬": {
			"name": "men holding hands",
			"slug": "men_holding_hands",
			"group": "People & Body",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "12.0",
			"aliases": [
				"men_holding_hands",
				"pair",
				"couple",
				"love",
				"like",
				"bromance",
				"friendship",
				"people",
				"human",
				"date",
				"gay",
				"hand",
				"hold",
				"lgbt",
				"male",
				"man",
				"pride",
				"two"
			]
		},
		"💏": {
			"name": "kiss",
			"slug": "kiss",
			"group": "People & Body",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "13.1",
			"aliases": [
				"kiss",
				"pair",
				"valentines",
				"love",
				"like",
				"dating",
				"marriage",
				"couple",
				"couplekiss",
				"female",
				"gender",
				"heart",
				"kissing",
				"male",
				"man",
				"men",
				"neutral",
				"romance",
				"woman",
				"women"
			]
		},
		"👩‍❤️‍💋‍👨": {
			"name": "kiss woman, man",
			"slug": "kiss_woman_man",
			"group": "People & Body",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "13.1",
			"aliases": [
				"kiss_woman_man",
				"love",
				"couple",
				"couplekiss",
				"female",
				"heart",
				"kissing",
				"male",
				"men",
				"romance",
				"women"
			]
		},
		"👨‍❤️‍💋‍👨": {
			"name": "kiss man, man",
			"slug": "kiss_man_man",
			"group": "People & Body",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "13.1",
			"aliases": [
				"kiss_man_man",
				"pair",
				"valentines",
				"love",
				"like",
				"dating",
				"marriage",
				"couple",
				"couplekiss",
				"gay",
				"heart",
				"kissing",
				"lgbt",
				"male",
				"men",
				"pride",
				"romance",
				"two"
			]
		},
		"👩‍❤️‍💋‍👩": {
			"name": "kiss woman, woman",
			"slug": "kiss_woman_woman",
			"group": "People & Body",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "13.1",
			"aliases": [
				"kiss_woman_woman",
				"pair",
				"valentines",
				"love",
				"like",
				"dating",
				"marriage",
				"couple",
				"couplekiss",
				"female",
				"heart",
				"kissing",
				"lesbian",
				"lgbt",
				"pride",
				"romance",
				"two",
				"women"
			]
		},
		"💑": {
			"name": "couple with heart",
			"slug": "couple_with_heart",
			"group": "People & Body",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "13.1",
			"aliases": [
				"couple_with_heart",
				"pair",
				"love",
				"like",
				"affection",
				"human",
				"dating",
				"valentines",
				"marriage",
				"female",
				"gender",
				"loving",
				"male",
				"man",
				"men",
				"neutral",
				"romance",
				"woman",
				"women"
			]
		},
		"👩‍❤️‍👨": {
			"name": "couple with heart woman, man",
			"slug": "couple_with_heart_woman_man",
			"group": "People & Body",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "13.1",
			"aliases": [
				"couple_with_heart_woman_man",
				"love",
				"female",
				"male",
				"men",
				"romance",
				"women"
			]
		},
		"👨‍❤️‍👨": {
			"name": "couple with heart man, man",
			"slug": "couple_with_heart_man_man",
			"group": "People & Body",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "13.1",
			"aliases": [
				"couple_with_heart_man_man",
				"pair",
				"love",
				"like",
				"affection",
				"human",
				"dating",
				"valentines",
				"marriage",
				"gay",
				"lgbt",
				"male",
				"men",
				"pride",
				"romance",
				"two"
			]
		},
		"👩‍❤️‍👩": {
			"name": "couple with heart woman, woman",
			"slug": "couple_with_heart_woman_woman",
			"group": "People & Body",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": true,
			"skin_tone_support_unicode_version": "13.1",
			"aliases": [
				"couple_with_heart_woman_woman",
				"pair",
				"love",
				"like",
				"affection",
				"human",
				"dating",
				"valentines",
				"marriage",
				"female",
				"lesbian",
				"lgbt",
				"pride",
				"romance",
				"two",
				"women"
			]
		},
		"👨‍👩‍👦": {
			"name": "family man, woman, boy",
			"slug": "family_man_woman_boy",
			"group": "People & Body",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"family_man_woman_boy",
				"love",
				"father",
				"mother",
				"son"
			]
		},
		"👨‍👩‍👧": {
			"name": "family man, woman, girl",
			"slug": "family_man_woman_girl",
			"group": "People & Body",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"family_man_woman_girl",
				"home",
				"parents",
				"people",
				"human",
				"child",
				"daughter",
				"father",
				"female",
				"male",
				"men",
				"mother",
				"women"
			]
		},
		"👨‍👩‍👧‍👦": {
			"name": "family man, woman, girl, boy",
			"slug": "family_man_woman_girl_boy",
			"group": "People & Body",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"family_man_woman_girl_boy",
				"home",
				"parents",
				"people",
				"human",
				"children",
				"child",
				"daughter",
				"father",
				"female",
				"male",
				"men",
				"mother",
				"son",
				"women"
			]
		},
		"👨‍👩‍👦‍👦": {
			"name": "family man, woman, boy, boy",
			"slug": "family_man_woman_boy_boy",
			"group": "People & Body",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"family_man_woman_boy_boy",
				"home",
				"parents",
				"people",
				"human",
				"children",
				"child",
				"father",
				"female",
				"male",
				"men",
				"mother",
				"sons",
				"two",
				"women"
			]
		},
		"👨‍👩‍👧‍👧": {
			"name": "family man, woman, girl, girl",
			"slug": "family_man_woman_girl_girl",
			"group": "People & Body",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"family_man_woman_girl_girl",
				"home",
				"parents",
				"people",
				"human",
				"children",
				"child",
				"daughters",
				"father",
				"female",
				"male",
				"men",
				"mother",
				"two",
				"women"
			]
		},
		"👨‍👨‍👦": {
			"name": "family man, man, boy",
			"slug": "family_man_man_boy",
			"group": "People & Body",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"family_man_man_boy",
				"home",
				"parents",
				"people",
				"human",
				"children",
				"child",
				"father",
				"fathers",
				"gay",
				"lgbt",
				"male",
				"men",
				"pride",
				"son",
				"two"
			]
		},
		"👨‍👨‍👧": {
			"name": "family man, man, girl",
			"slug": "family_man_man_girl",
			"group": "People & Body",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"family_man_man_girl",
				"home",
				"parents",
				"people",
				"human",
				"children",
				"child",
				"daughter",
				"father",
				"fathers",
				"gay",
				"lgbt",
				"male",
				"men",
				"pride",
				"two"
			]
		},
		"👨‍👨‍👧‍👦": {
			"name": "family man, man, girl, boy",
			"slug": "family_man_man_girl_boy",
			"group": "People & Body",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"family_man_man_girl_boy",
				"home",
				"parents",
				"people",
				"human",
				"children",
				"child",
				"daughter",
				"father",
				"fathers",
				"gay",
				"lgbt",
				"male",
				"men",
				"pride",
				"son",
				"two"
			]
		},
		"👨‍👨‍👦‍👦": {
			"name": "family man, man, boy, boy",
			"slug": "family_man_man_boy_boy",
			"group": "People & Body",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"family_man_man_boy_boy",
				"home",
				"parents",
				"people",
				"human",
				"children",
				"child",
				"father",
				"fathers",
				"gay",
				"lgbt",
				"male",
				"men",
				"pride",
				"sons",
				"two"
			]
		},
		"👨‍👨‍👧‍👧": {
			"name": "family man, man, girl, girl",
			"slug": "family_man_man_girl_girl",
			"group": "People & Body",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"family_man_man_girl_girl",
				"home",
				"parents",
				"people",
				"human",
				"children",
				"child",
				"daughters",
				"father",
				"fathers",
				"gay",
				"lgbt",
				"male",
				"men",
				"pride",
				"two"
			]
		},
		"👩‍👩‍👦": {
			"name": "family woman, woman, boy",
			"slug": "family_woman_woman_boy",
			"group": "People & Body",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"family_woman_woman_boy",
				"home",
				"parents",
				"people",
				"human",
				"children",
				"child",
				"female",
				"lesbian",
				"lgbt",
				"mother",
				"mothers",
				"pride",
				"son",
				"two",
				"women"
			]
		},
		"👩‍👩‍👧": {
			"name": "family woman, woman, girl",
			"slug": "family_woman_woman_girl",
			"group": "People & Body",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"family_woman_woman_girl",
				"home",
				"parents",
				"people",
				"human",
				"children",
				"child",
				"daughter",
				"female",
				"lesbian",
				"lgbt",
				"mother",
				"mothers",
				"pride",
				"two",
				"women"
			]
		},
		"👩‍👩‍👧‍👦": {
			"name": "family woman, woman, girl, boy",
			"slug": "family_woman_woman_girl_boy",
			"group": "People & Body",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"family_woman_woman_girl_boy",
				"home",
				"parents",
				"people",
				"human",
				"children",
				"child",
				"daughter",
				"female",
				"lesbian",
				"lgbt",
				"mother",
				"mothers",
				"pride",
				"son",
				"two",
				"women"
			]
		},
		"👩‍👩‍👦‍👦": {
			"name": "family woman, woman, boy, boy",
			"slug": "family_woman_woman_boy_boy",
			"group": "People & Body",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"family_woman_woman_boy_boy",
				"home",
				"parents",
				"people",
				"human",
				"children",
				"child",
				"female",
				"lesbian",
				"lgbt",
				"mother",
				"mothers",
				"pride",
				"sons",
				"two",
				"women"
			]
		},
		"👩‍👩‍👧‍👧": {
			"name": "family woman, woman, girl, girl",
			"slug": "family_woman_woman_girl_girl",
			"group": "People & Body",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"family_woman_woman_girl_girl",
				"home",
				"parents",
				"people",
				"human",
				"children",
				"child",
				"daughters",
				"female",
				"lesbian",
				"lgbt",
				"mother",
				"mothers",
				"pride",
				"two",
				"women"
			]
		},
		"👨‍👦": {
			"name": "family man, boy",
			"slug": "family_man_boy",
			"group": "People & Body",
			"emoji_version": "4.0",
			"unicode_version": "4.0",
			"skin_tone_support": false,
			"aliases": [
				"family_man_boy",
				"home",
				"parent",
				"people",
				"human",
				"child",
				"father",
				"male",
				"men",
				"son"
			]
		},
		"👨‍👦‍👦": {
			"name": "family man, boy, boy",
			"slug": "family_man_boy_boy",
			"group": "People & Body",
			"emoji_version": "4.0",
			"unicode_version": "4.0",
			"skin_tone_support": false,
			"aliases": [
				"family_man_boy_boy",
				"home",
				"parent",
				"people",
				"human",
				"children",
				"child",
				"father",
				"male",
				"men",
				"sons",
				"two"
			]
		},
		"👨‍👧": {
			"name": "family man, girl",
			"slug": "family_man_girl",
			"group": "People & Body",
			"emoji_version": "4.0",
			"unicode_version": "4.0",
			"skin_tone_support": false,
			"aliases": [
				"family_man_girl",
				"home",
				"parent",
				"people",
				"human",
				"child",
				"daughter",
				"father",
				"female",
				"male"
			]
		},
		"👨‍👧‍👦": {
			"name": "family man, girl, boy",
			"slug": "family_man_girl_boy",
			"group": "People & Body",
			"emoji_version": "4.0",
			"unicode_version": "4.0",
			"skin_tone_support": false,
			"aliases": [
				"family_man_girl_boy",
				"home",
				"parent",
				"people",
				"human",
				"children",
				"child",
				"daughter",
				"father",
				"male",
				"men",
				"son"
			]
		},
		"👨‍👧‍👧": {
			"name": "family man, girl, girl",
			"slug": "family_man_girl_girl",
			"group": "People & Body",
			"emoji_version": "4.0",
			"unicode_version": "4.0",
			"skin_tone_support": false,
			"aliases": [
				"family_man_girl_girl",
				"home",
				"parent",
				"people",
				"human",
				"children",
				"child",
				"daughters",
				"father",
				"female",
				"male",
				"two"
			]
		},
		"👩‍👦": {
			"name": "family woman, boy",
			"slug": "family_woman_boy",
			"group": "People & Body",
			"emoji_version": "4.0",
			"unicode_version": "4.0",
			"skin_tone_support": false,
			"aliases": [
				"family_woman_boy",
				"home",
				"parent",
				"people",
				"human",
				"child",
				"female",
				"mother",
				"son",
				"women"
			]
		},
		"👩‍👦‍👦": {
			"name": "family woman, boy, boy",
			"slug": "family_woman_boy_boy",
			"group": "People & Body",
			"emoji_version": "4.0",
			"unicode_version": "4.0",
			"skin_tone_support": false,
			"aliases": [
				"family_woman_boy_boy",
				"home",
				"parent",
				"people",
				"human",
				"children",
				"child",
				"female",
				"mother",
				"sons",
				"two",
				"women"
			]
		},
		"👩‍👧": {
			"name": "family woman, girl",
			"slug": "family_woman_girl",
			"group": "People & Body",
			"emoji_version": "4.0",
			"unicode_version": "4.0",
			"skin_tone_support": false,
			"aliases": [
				"family_woman_girl",
				"home",
				"parent",
				"people",
				"human",
				"child",
				"daughter",
				"female",
				"mother",
				"women"
			]
		},
		"👩‍👧‍👦": {
			"name": "family woman, girl, boy",
			"slug": "family_woman_girl_boy",
			"group": "People & Body",
			"emoji_version": "4.0",
			"unicode_version": "4.0",
			"skin_tone_support": false,
			"aliases": [
				"family_woman_girl_boy",
				"home",
				"parent",
				"people",
				"human",
				"children",
				"child",
				"daughter",
				"female",
				"male",
				"mother",
				"son"
			]
		},
		"👩‍👧‍👧": {
			"name": "family woman, girl, girl",
			"slug": "family_woman_girl_girl",
			"group": "People & Body",
			"emoji_version": "4.0",
			"unicode_version": "4.0",
			"skin_tone_support": false,
			"aliases": [
				"family_woman_girl_girl",
				"home",
				"parent",
				"people",
				"human",
				"children",
				"child",
				"daughters",
				"female",
				"mother",
				"two",
				"women"
			]
		},
		"🗣️": {
			"name": "speaking head",
			"slug": "speaking_head",
			"group": "People & Body",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"speaking_head",
				"user",
				"person",
				"human",
				"sing",
				"say",
				"talk",
				"face",
				"mansplaining",
				"shout",
				"shouting",
				"silhouette",
				"speak"
			]
		},
		"👤": {
			"name": "bust in silhouette",
			"slug": "bust_in_silhouette",
			"group": "People & Body",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"bust_in_silhouette",
				"user",
				"person",
				"human",
				"shadow"
			]
		},
		"👥": {
			"name": "busts in silhouette",
			"slug": "busts_in_silhouette",
			"group": "People & Body",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"busts_in_silhouette",
				"user",
				"person",
				"human",
				"group",
				"team",
				"bust",
				"people",
				"shadows",
				"silhouettes",
				"two",
				"users",
				"contributors"
			]
		},
		"🫂": {
			"name": "people hugging",
			"slug": "people_hugging",
			"group": "People & Body",
			"emoji_version": "13.0",
			"unicode_version": "13.0",
			"skin_tone_support": false,
			"aliases": [
				"people hugging",
				"care",
				"goodbye",
				"hello",
				"hug",
				"thanks"
			]
		},
		"👪": {
			"name": "family",
			"slug": "family",
			"group": "People & Body",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"family",
				"home",
				"parents",
				"child",
				"mom",
				"dad",
				"father",
				"mother",
				"people",
				"human",
				"boy",
				"female",
				"male",
				"man",
				"men",
				"woman",
				"women"
			]
		},
		"🧑‍🧑‍🧒": {
			"name": "family adult, adult, child",
			"slug": "family_adult_adult_child",
			"group": "People & Body",
			"emoji_version": "15.1",
			"unicode_version": "15.1",
			"skin_tone_support": false,
			"aliases": [
				"family adult, adult, child",
				"kid",
				"parents"
			]
		},
		"🧑‍🧑‍🧒‍🧒": {
			"name": "family adult, adult, child, child",
			"slug": "family_adult_adult_child_child",
			"group": "People & Body",
			"emoji_version": "15.1",
			"unicode_version": "15.1",
			"skin_tone_support": false,
			"aliases": [
				"family adult, adult, child, child",
				"children",
				"parents"
			]
		},
		"🧑‍🧒": {
			"name": "family adult, child",
			"slug": "family_adult_child",
			"group": "People & Body",
			"emoji_version": "15.1",
			"unicode_version": "15.1",
			"skin_tone_support": false,
			"aliases": [
				"family adult, child",
				"parent",
				"kid"
			]
		},
		"🧑‍🧒‍🧒": {
			"name": "family adult, child, child",
			"slug": "family_adult_child_child",
			"group": "People & Body",
			"emoji_version": "15.1",
			"unicode_version": "15.1",
			"skin_tone_support": false,
			"aliases": [
				"family adult, child, child",
				"parent",
				"children"
			]
		},
		"👣": {
			"name": "footprints",
			"slug": "footprints",
			"group": "People & Body",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"footprints",
				"feet",
				"tracking",
				"walking",
				"beach",
				"body",
				"clothing",
				"footprint",
				"footsteps",
				"print",
				"tracks"
			]
		},
		"🫆": {
			"name": "fingerprint",
			"slug": "fingerprint",
			"group": "People & Body",
			"emoji_version": "16.0",
			"unicode_version": "16.0",
			"skin_tone_support": false,
			"aliases": ["fingerprint"]
		},
		"🐵": {
			"name": "monkey face",
			"slug": "monkey_face",
			"group": "Animals & Nature",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"monkey_face",
				"animal",
				"nature",
				"circus",
				"head"
			]
		},
		"🐒": {
			"name": "monkey",
			"slug": "monkey",
			"group": "Animals & Nature",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"monkey",
				"animal",
				"nature",
				"banana",
				"circus",
				"cheeky"
			]
		},
		"🦍": {
			"name": "gorilla",
			"slug": "gorilla",
			"group": "Animals & Nature",
			"emoji_version": "3.0",
			"unicode_version": "3.0",
			"skin_tone_support": false,
			"aliases": [
				"gorilla",
				"animal",
				"nature",
				"circus"
			]
		},
		"🦧": {
			"name": "orangutan",
			"slug": "orangutan",
			"group": "Animals & Nature",
			"emoji_version": "12.0",
			"unicode_version": "12.0",
			"skin_tone_support": false,
			"aliases": [
				"orangutan",
				"animal",
				"ape"
			]
		},
		"🐶": {
			"name": "dog face",
			"slug": "dog_face",
			"group": "Animals & Nature",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"dog_face",
				"animal",
				"friend",
				"nature",
				"woof",
				"puppy",
				"pet",
				"faithful"
			]
		},
		"🐕": {
			"name": "dog",
			"slug": "dog",
			"group": "Animals & Nature",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"dog",
				"animal",
				"nature",
				"friend",
				"doge",
				"pet",
				"faithful",
				"dog2",
				"doggo"
			]
		},
		"🦮": {
			"name": "guide dog",
			"slug": "guide_dog",
			"group": "Animals & Nature",
			"emoji_version": "12.0",
			"unicode_version": "12.0",
			"skin_tone_support": false,
			"aliases": [
				"guide_dog",
				"animal",
				"blind",
				"accessibility",
				"eye",
				"seeing"
			]
		},
		"🐕‍🦺": {
			"name": "service dog",
			"slug": "service_dog",
			"group": "Animals & Nature",
			"emoji_version": "12.0",
			"unicode_version": "12.0",
			"skin_tone_support": false,
			"aliases": [
				"service_dog",
				"blind",
				"animal",
				"accessibility",
				"assistance"
			]
		},
		"🐩": {
			"name": "poodle",
			"slug": "poodle",
			"group": "Animals & Nature",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"poodle",
				"dog",
				"animal",
				"101",
				"nature",
				"pet",
				"miniature",
				"standard",
				"toy"
			]
		},
		"🐺": {
			"name": "wolf",
			"slug": "wolf",
			"group": "Animals & Nature",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"wolf",
				"animal",
				"nature",
				"wild",
				"face"
			]
		},
		"🦊": {
			"name": "fox",
			"slug": "fox",
			"group": "Animals & Nature",
			"emoji_version": "3.0",
			"unicode_version": "3.0",
			"skin_tone_support": false,
			"aliases": [
				"fox",
				"animal",
				"nature",
				"face"
			]
		},
		"🦝": {
			"name": "raccoon",
			"slug": "raccoon",
			"group": "Animals & Nature",
			"emoji_version": "11.0",
			"unicode_version": "11.0",
			"skin_tone_support": false,
			"aliases": [
				"raccoon",
				"animal",
				"nature",
				"curious",
				"face",
				"sly"
			]
		},
		"🐱": {
			"name": "cat face",
			"slug": "cat_face",
			"group": "Animals & Nature",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"cat_face",
				"animal",
				"meow",
				"nature",
				"pet",
				"kitten",
				"kitty"
			]
		},
		"🐈": {
			"name": "cat",
			"slug": "cat",
			"group": "Animals & Nature",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"cat",
				"animal",
				"meow",
				"pet",
				"cats",
				"cat2",
				"domestic",
				"feline",
				"housecat"
			]
		},
		"🐈‍⬛": {
			"name": "black cat",
			"slug": "black_cat",
			"group": "Animals & Nature",
			"emoji_version": "13.0",
			"unicode_version": "13.0",
			"skin_tone_support": false,
			"aliases": [
				"black cat",
				"superstition",
				"luck",
				"halloween",
				"pet",
				"unlucky"
			]
		},
		"🦁": {
			"name": "lion",
			"slug": "lion",
			"group": "Animals & Nature",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"lion",
				"animal",
				"nature",
				"face",
				"leo",
				"zodiac"
			]
		},
		"🐯": {
			"name": "tiger face",
			"slug": "tiger_face",
			"group": "Animals & Nature",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"tiger_face",
				"animal",
				"cat",
				"danger",
				"wild",
				"nature",
				"roar",
				"cute"
			]
		},
		"🐅": {
			"name": "tiger",
			"slug": "tiger",
			"group": "Animals & Nature",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"tiger",
				"animal",
				"nature",
				"roar",
				"bengal",
				"tiger2"
			]
		},
		"🐆": {
			"name": "leopard",
			"slug": "leopard",
			"group": "Animals & Nature",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"leopard",
				"animal",
				"nature",
				"african",
				"jaguar"
			]
		},
		"🐴": {
			"name": "horse face",
			"slug": "horse_face",
			"group": "Animals & Nature",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"horse_face",
				"animal",
				"brown",
				"nature",
				"head"
			]
		},
		"🫎": {
			"name": "moose",
			"slug": "moose",
			"group": "Animals & Nature",
			"emoji_version": "15.0",
			"unicode_version": "15.0",
			"skin_tone_support": false,
			"aliases": [
				"moose",
				"canada",
				"sweden",
				"sven",
				"cool"
			]
		},
		"🫏": {
			"name": "donkey",
			"slug": "donkey",
			"group": "Animals & Nature",
			"emoji_version": "15.0",
			"unicode_version": "15.0",
			"skin_tone_support": false,
			"aliases": [
				"donkey",
				"eeyore",
				"mule"
			]
		},
		"🐎": {
			"name": "horse",
			"slug": "horse",
			"group": "Animals & Nature",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"horse",
				"animal",
				"gamble",
				"luck",
				"equestrian",
				"galloping",
				"racehorse",
				"racing",
				"speed"
			]
		},
		"🦄": {
			"name": "unicorn",
			"slug": "unicorn",
			"group": "Animals & Nature",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"unicorn",
				"animal",
				"nature",
				"mystical",
				"face"
			]
		},
		"🦓": {
			"name": "zebra",
			"slug": "zebra",
			"group": "Animals & Nature",
			"emoji_version": "5.0",
			"unicode_version": "5.0",
			"skin_tone_support": false,
			"aliases": [
				"zebra",
				"animal",
				"nature",
				"stripes",
				"safari",
				"face",
				"stripe"
			]
		},
		"🦌": {
			"name": "deer",
			"slug": "deer",
			"group": "Animals & Nature",
			"emoji_version": "3.0",
			"unicode_version": "3.0",
			"skin_tone_support": false,
			"aliases": [
				"deer",
				"animal",
				"nature",
				"horns",
				"venison",
				"buck",
				"reindeer",
				"stag"
			]
		},
		"🦬": {
			"name": "bison",
			"slug": "bison",
			"group": "Animals & Nature",
			"emoji_version": "13.0",
			"unicode_version": "13.0",
			"skin_tone_support": false,
			"aliases": [
				"bison",
				"ox",
				"buffalo",
				"herd",
				"wisent"
			]
		},
		"🐮": {
			"name": "cow face",
			"slug": "cow_face",
			"group": "Animals & Nature",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"cow_face",
				"beef",
				"ox",
				"animal",
				"nature",
				"moo",
				"milk",
				"happy"
			]
		},
		"🐂": {
			"name": "ox",
			"slug": "ox",
			"group": "Animals & Nature",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"ox",
				"animal",
				"cow",
				"beef",
				"bull",
				"bullock",
				"oxen",
				"steer",
				"taurus",
				"zodiac"
			]
		},
		"🐃": {
			"name": "water buffalo",
			"slug": "water_buffalo",
			"group": "Animals & Nature",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"water_buffalo",
				"animal",
				"nature",
				"ox",
				"cow",
				"domestic"
			]
		},
		"🐄": {
			"name": "cow",
			"slug": "cow",
			"group": "Animals & Nature",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"cow",
				"beef",
				"ox",
				"animal",
				"nature",
				"moo",
				"milk",
				"cow2",
				"dairy"
			]
		},
		"🐷": {
			"name": "pig face",
			"slug": "pig_face",
			"group": "Animals & Nature",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"pig_face",
				"animal",
				"oink",
				"nature",
				"head"
			]
		},
		"🐖": {
			"name": "pig",
			"slug": "pig",
			"group": "Animals & Nature",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"pig",
				"animal",
				"nature",
				"hog",
				"pig2",
				"sow"
			]
		},
		"🐗": {
			"name": "boar",
			"slug": "boar",
			"group": "Animals & Nature",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"boar",
				"animal",
				"nature",
				"pig",
				"warthog",
				"wild"
			]
		},
		"🐽": {
			"name": "pig nose",
			"slug": "pig_nose",
			"group": "Animals & Nature",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"pig_nose",
				"animal",
				"oink",
				"face",
				"snout"
			]
		},
		"🐏": {
			"name": "ram",
			"slug": "ram",
			"group": "Animals & Nature",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"ram",
				"animal",
				"sheep",
				"nature",
				"aries",
				"male",
				"zodiac"
			]
		},
		"🐑": {
			"name": "ewe",
			"slug": "ewe",
			"group": "Animals & Nature",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"ewe",
				"animal",
				"nature",
				"wool",
				"shipit",
				"female",
				"lamb",
				"sheep"
			]
		},
		"🐐": {
			"name": "goat",
			"slug": "goat",
			"group": "Animals & Nature",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"goat",
				"animal",
				"nature",
				"capricorn",
				"zodiac"
			]
		},
		"🐪": {
			"name": "camel",
			"slug": "camel",
			"group": "Animals & Nature",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"camel",
				"animal",
				"hot",
				"desert",
				"hump",
				"arabian",
				"bump",
				"dromedary",
				"one"
			]
		},
		"🐫": {
			"name": "two-hump camel",
			"slug": "two_hump_camel",
			"group": "Animals & Nature",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"two_hump_camel",
				"animal",
				"nature",
				"hot",
				"desert",
				"hump",
				"asian",
				"bactrian",
				"bump"
			]
		},
		"🦙": {
			"name": "llama",
			"slug": "llama",
			"group": "Animals & Nature",
			"emoji_version": "11.0",
			"unicode_version": "11.0",
			"skin_tone_support": false,
			"aliases": [
				"llama",
				"animal",
				"nature",
				"alpaca",
				"guanaco",
				"vicuña",
				"wool"
			]
		},
		"🦒": {
			"name": "giraffe",
			"slug": "giraffe",
			"group": "Animals & Nature",
			"emoji_version": "5.0",
			"unicode_version": "5.0",
			"skin_tone_support": false,
			"aliases": [
				"giraffe",
				"animal",
				"nature",
				"spots",
				"safari",
				"face"
			]
		},
		"🐘": {
			"name": "elephant",
			"slug": "elephant",
			"group": "Animals & Nature",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"elephant",
				"animal",
				"nature",
				"nose",
				"th",
				"circus"
			]
		},
		"🦣": {
			"name": "mammoth",
			"slug": "mammoth",
			"group": "Animals & Nature",
			"emoji_version": "13.0",
			"unicode_version": "13.0",
			"skin_tone_support": false,
			"aliases": [
				"mammoth",
				"elephant",
				"tusks",
				"extinct",
				"extinction",
				"large",
				"tusk",
				"woolly"
			]
		},
		"🦏": {
			"name": "rhinoceros",
			"slug": "rhinoceros",
			"group": "Animals & Nature",
			"emoji_version": "3.0",
			"unicode_version": "3.0",
			"skin_tone_support": false,
			"aliases": [
				"rhinoceros",
				"animal",
				"nature",
				"horn",
				"rhino"
			]
		},
		"🦛": {
			"name": "hippopotamus",
			"slug": "hippopotamus",
			"group": "Animals & Nature",
			"emoji_version": "11.0",
			"unicode_version": "11.0",
			"skin_tone_support": false,
			"aliases": [
				"hippopotamus",
				"animal",
				"nature",
				"hippo"
			]
		},
		"🐭": {
			"name": "mouse face",
			"slug": "mouse_face",
			"group": "Animals & Nature",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"mouse_face",
				"animal",
				"nature",
				"cheese_wedge",
				"rodent"
			]
		},
		"🐁": {
			"name": "mouse",
			"slug": "mouse",
			"group": "Animals & Nature",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"mouse",
				"animal",
				"nature",
				"rodent",
				"dormouse",
				"mice",
				"mouse2"
			]
		},
		"🐀": {
			"name": "rat",
			"slug": "rat",
			"group": "Animals & Nature",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"rat",
				"animal",
				"mouse",
				"rodent"
			]
		},
		"🐹": {
			"name": "hamster",
			"slug": "hamster",
			"group": "Animals & Nature",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"hamster",
				"animal",
				"nature",
				"face",
				"pet"
			]
		},
		"🐰": {
			"name": "rabbit face",
			"slug": "rabbit_face",
			"group": "Animals & Nature",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"rabbit_face",
				"animal",
				"nature",
				"pet",
				"spring",
				"magic",
				"bunny",
				"easter"
			]
		},
		"🐇": {
			"name": "rabbit",
			"slug": "rabbit",
			"group": "Animals & Nature",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"rabbit",
				"animal",
				"nature",
				"pet",
				"magic",
				"spring",
				"bunny",
				"rabbit2"
			]
		},
		"🐿️": {
			"name": "chipmunk",
			"slug": "chipmunk",
			"group": "Animals & Nature",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"chipmunk",
				"animal",
				"nature",
				"rodent",
				"squirrel"
			]
		},
		"🦫": {
			"name": "beaver",
			"slug": "beaver",
			"group": "Animals & Nature",
			"emoji_version": "13.0",
			"unicode_version": "13.0",
			"skin_tone_support": false,
			"aliases": [
				"beaver",
				"animal",
				"rodent",
				"dam"
			]
		},
		"🦔": {
			"name": "hedgehog",
			"slug": "hedgehog",
			"group": "Animals & Nature",
			"emoji_version": "5.0",
			"unicode_version": "5.0",
			"skin_tone_support": false,
			"aliases": [
				"hedgehog",
				"animal",
				"nature",
				"spiny",
				"face"
			]
		},
		"🦇": {
			"name": "bat",
			"slug": "bat",
			"group": "Animals & Nature",
			"emoji_version": "3.0",
			"unicode_version": "3.0",
			"skin_tone_support": false,
			"aliases": [
				"bat",
				"animal",
				"nature",
				"blind",
				"vampire",
				"batman"
			]
		},
		"🐻": {
			"name": "bear",
			"slug": "bear",
			"group": "Animals & Nature",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"bear",
				"animal",
				"nature",
				"wild",
				"face",
				"teddy"
			]
		},
		"🐻‍❄️": {
			"name": "polar bear",
			"slug": "polar_bear",
			"group": "Animals & Nature",
			"emoji_version": "13.0",
			"unicode_version": "13.0",
			"skin_tone_support": false,
			"aliases": [
				"polar bear",
				"animal",
				"arctic",
				"face",
				"white"
			]
		},
		"🐨": {
			"name": "koala",
			"slug": "koala",
			"group": "Animals & Nature",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"koala",
				"animal",
				"nature",
				"bear",
				"face",
				"marsupial"
			]
		},
		"🐼": {
			"name": "panda",
			"slug": "panda",
			"group": "Animals & Nature",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"panda",
				"animal",
				"nature",
				"face"
			]
		},
		"🦥": {
			"name": "sloth",
			"slug": "sloth",
			"group": "Animals & Nature",
			"emoji_version": "12.0",
			"unicode_version": "12.0",
			"skin_tone_support": false,
			"aliases": [
				"sloth",
				"animal",
				"lazy",
				"slow"
			]
		},
		"🦦": {
			"name": "otter",
			"slug": "otter",
			"group": "Animals & Nature",
			"emoji_version": "12.0",
			"unicode_version": "12.0",
			"skin_tone_support": false,
			"aliases": [
				"otter",
				"animal",
				"fishing",
				"playful"
			]
		},
		"🦨": {
			"name": "skunk",
			"slug": "skunk",
			"group": "Animals & Nature",
			"emoji_version": "12.0",
			"unicode_version": "12.0",
			"skin_tone_support": false,
			"aliases": [
				"skunk",
				"animal",
				"smelly",
				"stink"
			]
		},
		"🦘": {
			"name": "kangaroo",
			"slug": "kangaroo",
			"group": "Animals & Nature",
			"emoji_version": "11.0",
			"unicode_version": "11.0",
			"skin_tone_support": false,
			"aliases": [
				"kangaroo",
				"animal",
				"nature",
				"australia",
				"joey",
				"hop",
				"marsupial",
				"jump",
				"roo"
			]
		},
		"🦡": {
			"name": "badger",
			"slug": "badger",
			"group": "Animals & Nature",
			"emoji_version": "11.0",
			"unicode_version": "11.0",
			"skin_tone_support": false,
			"aliases": [
				"badger",
				"animal",
				"nature",
				"honey",
				"pester"
			]
		},
		"🐾": {
			"name": "paw prints",
			"slug": "paw_prints",
			"group": "Animals & Nature",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"paw_prints",
				"animal",
				"tracking",
				"footprints",
				"dog",
				"cat",
				"pet",
				"feet",
				"kitten",
				"print",
				"puppy"
			]
		},
		"🦃": {
			"name": "turkey",
			"slug": "turkey",
			"group": "Animals & Nature",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"turkey",
				"animal",
				"bird",
				"thanksgiving",
				"wild"
			]
		},
		"🐔": {
			"name": "chicken",
			"slug": "chicken",
			"group": "Animals & Nature",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"chicken",
				"animal",
				"cluck",
				"nature",
				"bird",
				"hen"
			]
		},
		"🐓": {
			"name": "rooster",
			"slug": "rooster",
			"group": "Animals & Nature",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"rooster",
				"animal",
				"nature",
				"chicken",
				"bird",
				"cock",
				"cockerel"
			]
		},
		"🐣": {
			"name": "hatching chick",
			"slug": "hatching_chick",
			"group": "Animals & Nature",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"hatching_chick",
				"animal",
				"chicken",
				"egg",
				"born",
				"baby",
				"bird"
			]
		},
		"🐤": {
			"name": "baby chick",
			"slug": "baby_chick",
			"group": "Animals & Nature",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"baby_chick",
				"animal",
				"chicken",
				"bird",
				"yellow"
			]
		},
		"🐥": {
			"name": "front-facing baby chick",
			"slug": "front_facing_baby_chick",
			"group": "Animals & Nature",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"front_facing_baby_chick",
				"animal",
				"chicken",
				"baby",
				"bird",
				"hatched",
				"standing"
			]
		},
		"🐦": {
			"name": "bird",
			"slug": "bird",
			"group": "Animals & Nature",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"bird",
				"animal",
				"nature",
				"fly",
				"tweet",
				"spring"
			]
		},
		"🐧": {
			"name": "penguin",
			"slug": "penguin",
			"group": "Animals & Nature",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"penguin",
				"animal",
				"nature",
				"bird"
			]
		},
		"🕊️": {
			"name": "dove",
			"slug": "dove",
			"group": "Animals & Nature",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"dove",
				"animal",
				"bird",
				"fly",
				"peace"
			]
		},
		"🦅": {
			"name": "eagle",
			"slug": "eagle",
			"group": "Animals & Nature",
			"emoji_version": "3.0",
			"unicode_version": "3.0",
			"skin_tone_support": false,
			"aliases": [
				"eagle",
				"animal",
				"nature",
				"bird",
				"bald"
			]
		},
		"🦆": {
			"name": "duck",
			"slug": "duck",
			"group": "Animals & Nature",
			"emoji_version": "3.0",
			"unicode_version": "3.0",
			"skin_tone_support": false,
			"aliases": [
				"duck",
				"animal",
				"nature",
				"bird",
				"mallard"
			]
		},
		"🦢": {
			"name": "swan",
			"slug": "swan",
			"group": "Animals & Nature",
			"emoji_version": "11.0",
			"unicode_version": "11.0",
			"skin_tone_support": false,
			"aliases": [
				"swan",
				"animal",
				"nature",
				"bird",
				"cygnet",
				"duckling",
				"ugly"
			]
		},
		"🦉": {
			"name": "owl",
			"slug": "owl",
			"group": "Animals & Nature",
			"emoji_version": "3.0",
			"unicode_version": "3.0",
			"skin_tone_support": false,
			"aliases": [
				"owl",
				"animal",
				"nature",
				"bird",
				"hoot",
				"wise"
			]
		},
		"🦤": {
			"name": "dodo",
			"slug": "dodo",
			"group": "Animals & Nature",
			"emoji_version": "13.0",
			"unicode_version": "13.0",
			"skin_tone_support": false,
			"aliases": [
				"dodo",
				"animal",
				"bird",
				"extinct",
				"extinction",
				"large",
				"mauritius",
				"obsolete"
			]
		},
		"🪶": {
			"name": "feather",
			"slug": "feather",
			"group": "Animals & Nature",
			"emoji_version": "13.0",
			"unicode_version": "13.0",
			"skin_tone_support": false,
			"aliases": [
				"feather",
				"bird",
				"fly",
				"flight",
				"light",
				"plumage"
			]
		},
		"🦩": {
			"name": "flamingo",
			"slug": "flamingo",
			"group": "Animals & Nature",
			"emoji_version": "12.0",
			"unicode_version": "12.0",
			"skin_tone_support": false,
			"aliases": [
				"flamingo",
				"animal",
				"flamboyant",
				"tropical"
			]
		},
		"🦚": {
			"name": "peacock",
			"slug": "peacock",
			"group": "Animals & Nature",
			"emoji_version": "11.0",
			"unicode_version": "11.0",
			"skin_tone_support": false,
			"aliases": [
				"peacock",
				"animal",
				"nature",
				"peahen",
				"bird",
				"ostentatious",
				"proud"
			]
		},
		"🦜": {
			"name": "parrot",
			"slug": "parrot",
			"group": "Animals & Nature",
			"emoji_version": "11.0",
			"unicode_version": "11.0",
			"skin_tone_support": false,
			"aliases": [
				"parrot",
				"animal",
				"nature",
				"bird",
				"pirate",
				"talk"
			]
		},
		"🪽": {
			"name": "wing",
			"slug": "wing",
			"group": "Animals & Nature",
			"emoji_version": "15.0",
			"unicode_version": "15.0",
			"skin_tone_support": false,
			"aliases": [
				"wing",
				"angel",
				"birds",
				"flying",
				"fly"
			]
		},
		"🐦‍⬛": {
			"name": "black bird",
			"slug": "black_bird",
			"group": "Animals & Nature",
			"emoji_version": "15.0",
			"unicode_version": "15.0",
			"skin_tone_support": false,
			"aliases": ["black bird", "crow"]
		},
		"🪿": {
			"name": "goose",
			"slug": "goose",
			"group": "Animals & Nature",
			"emoji_version": "15.0",
			"unicode_version": "15.0",
			"skin_tone_support": false,
			"aliases": [
				"goose",
				"silly",
				"jemima",
				"goosebumps",
				"honk"
			]
		},
		"🐦‍🔥": {
			"name": "phoenix",
			"slug": "phoenix",
			"group": "Animals & Nature",
			"emoji_version": "15.1",
			"unicode_version": "15.1",
			"skin_tone_support": false,
			"aliases": [
				"phoenix",
				"immortal",
				"bird",
				"mythtical",
				"reborn"
			]
		},
		"🐸": {
			"name": "frog",
			"slug": "frog",
			"group": "Animals & Nature",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"frog",
				"animal",
				"nature",
				"croak",
				"toad",
				"face"
			]
		},
		"🐊": {
			"name": "crocodile",
			"slug": "crocodile",
			"group": "Animals & Nature",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"crocodile",
				"animal",
				"nature",
				"reptile",
				"lizard",
				"alligator",
				"croc"
			]
		},
		"🐢": {
			"name": "turtle",
			"slug": "turtle",
			"group": "Animals & Nature",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"turtle",
				"animal",
				"slow",
				"nature",
				"tortoise",
				"terrapin"
			]
		},
		"🦎": {
			"name": "lizard",
			"slug": "lizard",
			"group": "Animals & Nature",
			"emoji_version": "3.0",
			"unicode_version": "3.0",
			"skin_tone_support": false,
			"aliases": [
				"lizard",
				"animal",
				"nature",
				"reptile",
				"gecko"
			]
		},
		"🐍": {
			"name": "snake",
			"slug": "snake",
			"group": "Animals & Nature",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"snake",
				"animal",
				"evil",
				"nature",
				"hiss",
				"python",
				"bearer",
				"ophiuchus",
				"serpent",
				"zodiac"
			]
		},
		"🐲": {
			"name": "dragon face",
			"slug": "dragon_face",
			"group": "Animals & Nature",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"dragon_face",
				"animal",
				"myth",
				"nature",
				"chinese",
				"green",
				"fairy",
				"head",
				"tale"
			]
		},
		"🐉": {
			"name": "dragon",
			"slug": "dragon",
			"group": "Animals & Nature",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"dragon",
				"animal",
				"myth",
				"nature",
				"chinese",
				"green",
				"fairy",
				"tale"
			]
		},
		"🦕": {
			"name": "sauropod",
			"slug": "sauropod",
			"group": "Animals & Nature",
			"emoji_version": "5.0",
			"unicode_version": "5.0",
			"skin_tone_support": false,
			"aliases": [
				"sauropod",
				"animal",
				"nature",
				"dinosaur",
				"brachiosaurus",
				"brontosaurus",
				"diplodocus",
				"extinct"
			]
		},
		"🦖": {
			"name": "T-Rex",
			"slug": "t_rex",
			"group": "Animals & Nature",
			"emoji_version": "5.0",
			"unicode_version": "5.0",
			"skin_tone_support": false,
			"aliases": [
				"t_rex",
				"animal",
				"nature",
				"dinosaur",
				"tyrannosaurus",
				"extinct",
				"trex"
			]
		},
		"🐳": {
			"name": "spouting whale",
			"slug": "spouting_whale",
			"group": "Animals & Nature",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"spouting_whale",
				"animal",
				"nature",
				"sea",
				"ocean",
				"cute",
				"face"
			]
		},
		"🐋": {
			"name": "whale",
			"slug": "whale",
			"group": "Animals & Nature",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"whale",
				"animal",
				"nature",
				"sea",
				"ocean",
				"whale2"
			]
		},
		"🐬": {
			"name": "dolphin",
			"slug": "dolphin",
			"group": "Animals & Nature",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"dolphin",
				"animal",
				"nature",
				"fish",
				"sea",
				"ocean",
				"flipper",
				"fins",
				"beach"
			]
		},
		"🫍": {
			"name": "orca",
			"slug": "orca",
			"group": "Animals & Nature",
			"emoji_version": "17.0",
			"unicode_version": "17.0",
			"skin_tone_support": false,
			"aliases": [
				"orca",
				"ocean",
				"whale",
				"dolphin",
				"animal"
			]
		},
		"🦭": {
			"name": "seal",
			"slug": "seal",
			"group": "Animals & Nature",
			"emoji_version": "13.0",
			"unicode_version": "13.0",
			"skin_tone_support": false,
			"aliases": [
				"seal",
				"animal",
				"creature",
				"sea",
				"lion"
			]
		},
		"🐟": {
			"name": "fish",
			"slug": "fish",
			"group": "Animals & Nature",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"fish",
				"animal",
				"food",
				"nature",
				"freshwater",
				"pisces",
				"zodiac"
			]
		},
		"🐠": {
			"name": "tropical fish",
			"slug": "tropical_fish",
			"group": "Animals & Nature",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"tropical_fish",
				"animal",
				"swim",
				"ocean",
				"beach",
				"nemo",
				"blue",
				"yellow"
			]
		},
		"🐡": {
			"name": "blowfish",
			"slug": "blowfish",
			"group": "Animals & Nature",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"blowfish",
				"animal",
				"nature",
				"food",
				"sea",
				"ocean",
				"fish",
				"fugu",
				"pufferfish"
			]
		},
		"🦈": {
			"name": "shark",
			"slug": "shark",
			"group": "Animals & Nature",
			"emoji_version": "3.0",
			"unicode_version": "3.0",
			"skin_tone_support": false,
			"aliases": [
				"shark",
				"animal",
				"nature",
				"fish",
				"sea",
				"ocean",
				"jaws",
				"fins",
				"beach",
				"great",
				"white"
			]
		},
		"🐙": {
			"name": "octopus",
			"slug": "octopus",
			"group": "Animals & Nature",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"octopus",
				"animal",
				"creature",
				"ocean",
				"sea",
				"nature",
				"beach"
			]
		},
		"🐚": {
			"name": "spiral shell",
			"slug": "spiral_shell",
			"group": "Animals & Nature",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"spiral_shell",
				"nature",
				"sea",
				"beach",
				"seashell"
			]
		},
		"🪸": {
			"name": "coral",
			"slug": "coral",
			"group": "Animals & Nature",
			"emoji_version": "14.0",
			"unicode_version": "14.0",
			"skin_tone_support": false,
			"aliases": [
				"coral",
				"ocean",
				"sea",
				"reef"
			]
		},
		"🪼": {
			"name": "jellyfish",
			"slug": "jellyfish",
			"group": "Animals & Nature",
			"emoji_version": "15.0",
			"unicode_version": "15.0",
			"skin_tone_support": false,
			"aliases": [
				"jellyfish",
				"sting",
				"tentacles"
			]
		},
		"🦀": {
			"name": "crab",
			"slug": "crab",
			"group": "Animals & Nature",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"crab",
				"animal",
				"crustacean",
				"cancer",
				"zodiac"
			]
		},
		"🦞": {
			"name": "lobster",
			"slug": "lobster",
			"group": "Animals & Nature",
			"emoji_version": "11.0",
			"unicode_version": "11.0",
			"skin_tone_support": false,
			"aliases": [
				"lobster",
				"animal",
				"nature",
				"bisque",
				"claws",
				"seafood"
			]
		},
		"🦐": {
			"name": "shrimp",
			"slug": "shrimp",
			"group": "Animals & Nature",
			"emoji_version": "3.0",
			"unicode_version": "3.0",
			"skin_tone_support": false,
			"aliases": [
				"shrimp",
				"animal",
				"ocean",
				"nature",
				"seafood",
				"food",
				"prawn",
				"shellfish",
				"small"
			]
		},
		"🦑": {
			"name": "squid",
			"slug": "squid",
			"group": "Animals & Nature",
			"emoji_version": "3.0",
			"unicode_version": "3.0",
			"skin_tone_support": false,
			"aliases": [
				"squid",
				"animal",
				"nature",
				"ocean",
				"sea",
				"food",
				"molusc"
			]
		},
		"🦪": {
			"name": "oyster",
			"slug": "oyster",
			"group": "Animals & Nature",
			"emoji_version": "12.0",
			"unicode_version": "12.0",
			"skin_tone_support": false,
			"aliases": [
				"oyster",
				"food",
				"diving",
				"pearl"
			]
		},
		"🐌": {
			"name": "snail",
			"slug": "snail",
			"group": "Animals & Nature",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"snail",
				"slow",
				"animal",
				"shell",
				"garden",
				"slug"
			]
		},
		"🦋": {
			"name": "butterfly",
			"slug": "butterfly",
			"group": "Animals & Nature",
			"emoji_version": "3.0",
			"unicode_version": "3.0",
			"skin_tone_support": false,
			"aliases": [
				"butterfly",
				"animal",
				"insect",
				"nature",
				"caterpillar",
				"pretty"
			]
		},
		"🐛": {
			"name": "bug",
			"slug": "bug",
			"group": "Animals & Nature",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"bug",
				"animal",
				"insect",
				"nature",
				"worm",
				"caterpillar"
			]
		},
		"🐜": {
			"name": "ant",
			"slug": "ant",
			"group": "Animals & Nature",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"ant",
				"animal",
				"insect",
				"nature",
				"bug"
			]
		},
		"🐝": {
			"name": "honeybee",
			"slug": "honeybee",
			"group": "Animals & Nature",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"honeybee",
				"animal",
				"insect",
				"nature",
				"bug",
				"spring",
				"honey",
				"bee",
				"bumblebee"
			]
		},
		"🪲": {
			"name": "beetle",
			"slug": "beetle",
			"group": "Animals & Nature",
			"emoji_version": "13.0",
			"unicode_version": "13.0",
			"skin_tone_support": false,
			"aliases": [
				"beetle",
				"insect",
				"bug"
			]
		},
		"🐞": {
			"name": "lady beetle",
			"slug": "lady_beetle",
			"group": "Animals & Nature",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"lady_beetle",
				"animal",
				"insect",
				"nature",
				"ladybug",
				"bug",
				"ladybird"
			]
		},
		"🦗": {
			"name": "cricket",
			"slug": "cricket",
			"group": "Animals & Nature",
			"emoji_version": "5.0",
			"unicode_version": "5.0",
			"skin_tone_support": false,
			"aliases": [
				"cricket",
				"animal",
				"chirp",
				"grasshopper",
				"insect",
				"orthoptera"
			]
		},
		"🪳": {
			"name": "cockroach",
			"slug": "cockroach",
			"group": "Animals & Nature",
			"emoji_version": "13.0",
			"unicode_version": "13.0",
			"skin_tone_support": false,
			"aliases": [
				"cockroach",
				"insect",
				"pests",
				"pest",
				"roach"
			]
		},
		"🕷️": {
			"name": "spider",
			"slug": "spider",
			"group": "Animals & Nature",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"spider",
				"animal",
				"arachnid",
				"insect"
			]
		},
		"🕸️": {
			"name": "spider web",
			"slug": "spider_web",
			"group": "Animals & Nature",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"spider_web",
				"animal",
				"insect",
				"arachnid",
				"silk",
				"cobweb",
				"spiderweb"
			]
		},
		"🦂": {
			"name": "scorpion",
			"slug": "scorpion",
			"group": "Animals & Nature",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"scorpion",
				"animal",
				"arachnid",
				"scorpio",
				"scorpius",
				"zodiac"
			]
		},
		"🦟": {
			"name": "mosquito",
			"slug": "mosquito",
			"group": "Animals & Nature",
			"emoji_version": "11.0",
			"unicode_version": "11.0",
			"skin_tone_support": false,
			"aliases": [
				"mosquito",
				"animal",
				"nature",
				"insect",
				"malaria",
				"disease",
				"fever",
				"pest",
				"virus"
			]
		},
		"🪰": {
			"name": "fly",
			"slug": "fly",
			"group": "Animals & Nature",
			"emoji_version": "13.0",
			"unicode_version": "13.0",
			"skin_tone_support": false,
			"aliases": [
				"fly",
				"insect",
				"disease",
				"maggot",
				"pest",
				"rotting"
			]
		},
		"🪱": {
			"name": "worm",
			"slug": "worm",
			"group": "Animals & Nature",
			"emoji_version": "13.0",
			"unicode_version": "13.0",
			"skin_tone_support": false,
			"aliases": [
				"worm",
				"animal",
				"annelid",
				"earthworm",
				"parasite"
			]
		},
		"🦠": {
			"name": "microbe",
			"slug": "microbe",
			"group": "Animals & Nature",
			"emoji_version": "11.0",
			"unicode_version": "11.0",
			"skin_tone_support": false,
			"aliases": [
				"microbe",
				"amoeba",
				"bacteria",
				"germs",
				"virus",
				"covid",
				"cell",
				"coronavirus",
				"germ",
				"microorganism"
			]
		},
		"💐": {
			"name": "bouquet",
			"slug": "bouquet",
			"group": "Animals & Nature",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"bouquet",
				"flowers",
				"nature",
				"spring",
				"flower",
				"plant",
				"romance"
			]
		},
		"🌸": {
			"name": "cherry blossom",
			"slug": "cherry_blossom",
			"group": "Animals & Nature",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"cherry_blossom",
				"nature",
				"plant",
				"spring",
				"flower",
				"pink",
				"sakura"
			]
		},
		"💮": {
			"name": "white flower",
			"slug": "white_flower",
			"group": "Animals & Nature",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"white_flower",
				"japanese",
				"spring",
				"blossom",
				"cherry",
				"doily",
				"done",
				"paper",
				"stamp",
				"well"
			]
		},
		"🪷": {
			"name": "lotus",
			"slug": "lotus",
			"group": "Animals & Nature",
			"emoji_version": "14.0",
			"unicode_version": "14.0",
			"skin_tone_support": false,
			"aliases": [
				"lotus",
				"flower",
				"calm",
				"meditation",
				"buddhism",
				"hinduism",
				"india",
				"purity",
				"vietnam"
			]
		},
		"🏵️": {
			"name": "rosette",
			"slug": "rosette",
			"group": "Animals & Nature",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"rosette",
				"flower",
				"decoration",
				"military",
				"plant"
			]
		},
		"🌹": {
			"name": "rose",
			"slug": "rose",
			"group": "Animals & Nature",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"rose",
				"flowers",
				"valentines",
				"love",
				"spring",
				"flower",
				"plant",
				"red"
			]
		},
		"🥀": {
			"name": "wilted flower",
			"slug": "wilted_flower",
			"group": "Animals & Nature",
			"emoji_version": "3.0",
			"unicode_version": "3.0",
			"skin_tone_support": false,
			"aliases": [
				"wilted_flower",
				"plant",
				"nature",
				"flower",
				"rose",
				"dead",
				"drooping"
			]
		},
		"🌺": {
			"name": "hibiscus",
			"slug": "hibiscus",
			"group": "Animals & Nature",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"hibiscus",
				"plant",
				"vegetable",
				"flowers",
				"beach",
				"flower"
			]
		},
		"🌻": {
			"name": "sunflower",
			"slug": "sunflower",
			"group": "Animals & Nature",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"sunflower",
				"nature",
				"plant",
				"fall",
				"flower",
				"sun",
				"yellow"
			]
		},
		"🌼": {
			"name": "blossom",
			"slug": "blossom",
			"group": "Animals & Nature",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"blossom",
				"nature",
				"flowers",
				"yellow",
				"blossoming\xA0flower",
				"daisy",
				"flower",
				"plant"
			]
		},
		"🌷": {
			"name": "tulip",
			"slug": "tulip",
			"group": "Animals & Nature",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"tulip",
				"flowers",
				"plant",
				"nature",
				"summer",
				"spring",
				"flower"
			]
		},
		"🪻": {
			"name": "hyacinth",
			"slug": "hyacinth",
			"group": "Animals & Nature",
			"emoji_version": "15.0",
			"unicode_version": "15.0",
			"skin_tone_support": false,
			"aliases": [
				"hyacinth",
				"flower",
				"lavender"
			]
		},
		"🌱": {
			"name": "seedling",
			"slug": "seedling",
			"group": "Animals & Nature",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"seedling",
				"plant",
				"nature",
				"grass",
				"lawn",
				"spring",
				"sprout",
				"sprouting",
				"young",
				"seed"
			]
		},
		"🪴": {
			"name": "potted plant",
			"slug": "potted_plant",
			"group": "Animals & Nature",
			"emoji_version": "13.0",
			"unicode_version": "13.0",
			"skin_tone_support": false,
			"aliases": [
				"potted plant",
				"greenery",
				"house",
				"boring",
				"grow",
				"houseplant",
				"nurturing",
				"useless"
			]
		},
		"🌲": {
			"name": "evergreen tree",
			"slug": "evergreen_tree",
			"group": "Animals & Nature",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"evergreen_tree",
				"plant",
				"nature",
				"fir",
				"pine",
				"wood"
			]
		},
		"🌳": {
			"name": "deciduous tree",
			"slug": "deciduous_tree",
			"group": "Animals & Nature",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"deciduous_tree",
				"plant",
				"nature",
				"rounded",
				"shedding",
				"wood"
			]
		},
		"🌴": {
			"name": "palm tree",
			"slug": "palm_tree",
			"group": "Animals & Nature",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"palm_tree",
				"plant",
				"vegetable",
				"nature",
				"summer",
				"beach",
				"mojito",
				"tropical",
				"coconut"
			]
		},
		"🌵": {
			"name": "cactus",
			"slug": "cactus",
			"group": "Animals & Nature",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"cactus",
				"vegetable",
				"plant",
				"nature",
				"desert"
			]
		},
		"🌾": {
			"name": "sheaf of rice",
			"slug": "sheaf_of_rice",
			"group": "Animals & Nature",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"sheaf_of_rice",
				"nature",
				"plant",
				"crop",
				"ear",
				"farming",
				"grain",
				"wheat"
			]
		},
		"🌿": {
			"name": "herb",
			"slug": "herb",
			"group": "Animals & Nature",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"herb",
				"vegetable",
				"plant",
				"medicine",
				"weed",
				"grass",
				"lawn",
				"crop",
				"leaf"
			]
		},
		"☘️": {
			"name": "shamrock",
			"slug": "shamrock",
			"group": "Animals & Nature",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"shamrock",
				"vegetable",
				"plant",
				"nature",
				"irish",
				"clover",
				"trefoil"
			]
		},
		"🍀": {
			"name": "four leaf clover",
			"slug": "four_leaf_clover",
			"group": "Animals & Nature",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"four_leaf_clover",
				"vegetable",
				"plant",
				"nature",
				"lucky",
				"irish",
				"ireland",
				"luck"
			]
		},
		"🍁": {
			"name": "maple leaf",
			"slug": "maple_leaf",
			"group": "Animals & Nature",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"maple_leaf",
				"nature",
				"plant",
				"vegetable",
				"ca",
				"fall",
				"canada",
				"canadian",
				"falling"
			]
		},
		"🍂": {
			"name": "fallen leaf",
			"slug": "fallen_leaf",
			"group": "Animals & Nature",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"fallen_leaf",
				"nature",
				"plant",
				"vegetable",
				"leaves",
				"autumn",
				"brown",
				"fall",
				"falling"
			]
		},
		"🍃": {
			"name": "leaf fluttering in wind",
			"slug": "leaf_fluttering_in_wind",
			"group": "Animals & Nature",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"leaf_fluttering_in_wind",
				"nature",
				"plant",
				"tree",
				"vegetable",
				"grass",
				"lawn",
				"spring",
				"blow",
				"flutter",
				"green",
				"leaves"
			]
		},
		"🪹": {
			"name": "empty nest",
			"slug": "empty_nest",
			"group": "Animals & Nature",
			"emoji_version": "14.0",
			"unicode_version": "14.0",
			"skin_tone_support": false,
			"aliases": [
				"empty nest",
				"bird",
				"nesting"
			]
		},
		"🪺": {
			"name": "nest with eggs",
			"slug": "nest_with_eggs",
			"group": "Animals & Nature",
			"emoji_version": "14.0",
			"unicode_version": "14.0",
			"skin_tone_support": false,
			"aliases": [
				"nest with eggs",
				"bird",
				"nesting"
			]
		},
		"🍄": {
			"name": "mushroom",
			"slug": "mushroom",
			"group": "Animals & Nature",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"mushroom",
				"plant",
				"vegetable",
				"fungus",
				"shroom",
				"toadstool"
			]
		},
		"🪾": {
			"name": "leafless tree",
			"slug": "leafless_tree",
			"group": "Animals & Nature",
			"emoji_version": "16.0",
			"unicode_version": "16.0",
			"skin_tone_support": false,
			"aliases": ["leafless tree"]
		},
		"🍇": {
			"name": "grapes",
			"slug": "grapes",
			"group": "Food & Drink",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"grapes",
				"fruit",
				"food",
				"wine",
				"grape",
				"plant"
			]
		},
		"🍈": {
			"name": "melon",
			"slug": "melon",
			"group": "Food & Drink",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"melon",
				"fruit",
				"nature",
				"food",
				"cantaloupe",
				"honeydew",
				"muskmelon",
				"plant"
			]
		},
		"🍉": {
			"name": "watermelon",
			"slug": "watermelon",
			"group": "Food & Drink",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"watermelon",
				"fruit",
				"food",
				"picnic",
				"summer",
				"plant"
			]
		},
		"🍊": {
			"name": "tangerine",
			"slug": "tangerine",
			"group": "Food & Drink",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"tangerine",
				"food",
				"fruit",
				"nature",
				"orange",
				"mandarin",
				"plant"
			]
		},
		"🍋": {
			"name": "lemon",
			"slug": "lemon",
			"group": "Food & Drink",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"lemon",
				"fruit",
				"nature",
				"citrus",
				"lemonade",
				"plant"
			]
		},
		"🍋‍🟩": {
			"name": "lime",
			"slug": "lime",
			"group": "Food & Drink",
			"emoji_version": "15.1",
			"unicode_version": "15.1",
			"skin_tone_support": false,
			"aliases": [
				"lime",
				"fruit",
				"acidic",
				"citric"
			]
		},
		"🍌": {
			"name": "banana",
			"slug": "banana",
			"group": "Food & Drink",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"banana",
				"fruit",
				"food",
				"monkey",
				"plant",
				"plantain"
			]
		},
		"🍍": {
			"name": "pineapple",
			"slug": "pineapple",
			"group": "Food & Drink",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"pineapple",
				"fruit",
				"nature",
				"food",
				"plant"
			]
		},
		"🥭": {
			"name": "mango",
			"slug": "mango",
			"group": "Food & Drink",
			"emoji_version": "11.0",
			"unicode_version": "11.0",
			"skin_tone_support": false,
			"aliases": [
				"mango",
				"fruit",
				"food",
				"tropical"
			]
		},
		"🍎": {
			"name": "red apple",
			"slug": "red_apple",
			"group": "Food & Drink",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"red_apple",
				"fruit",
				"mac",
				"school",
				"delicious",
				"plant"
			]
		},
		"🍏": {
			"name": "green apple",
			"slug": "green_apple",
			"group": "Food & Drink",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"green_apple",
				"fruit",
				"nature",
				"delicious",
				"golden",
				"granny",
				"plant",
				"smith"
			]
		},
		"🍐": {
			"name": "pear",
			"slug": "pear",
			"group": "Food & Drink",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"pear",
				"fruit",
				"nature",
				"food",
				"plant"
			]
		},
		"🍑": {
			"name": "peach",
			"slug": "peach",
			"group": "Food & Drink",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"peach",
				"fruit",
				"nature",
				"food",
				"bottom",
				"butt",
				"plant"
			]
		},
		"🍒": {
			"name": "cherries",
			"slug": "cherries",
			"group": "Food & Drink",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"cherries",
				"food",
				"fruit",
				"berries",
				"cherry",
				"plant",
				"red",
				"wild"
			]
		},
		"🍓": {
			"name": "strawberry",
			"slug": "strawberry",
			"group": "Food & Drink",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"strawberry",
				"fruit",
				"food",
				"nature",
				"berry",
				"plant"
			]
		},
		"🫐": {
			"name": "blueberries",
			"slug": "blueberries",
			"group": "Food & Drink",
			"emoji_version": "13.0",
			"unicode_version": "13.0",
			"skin_tone_support": false,
			"aliases": [
				"blueberries",
				"fruit",
				"berry",
				"bilberry",
				"blue",
				"blueberry"
			]
		},
		"🥝": {
			"name": "kiwi fruit",
			"slug": "kiwi_fruit",
			"group": "Food & Drink",
			"emoji_version": "3.0",
			"unicode_version": "3.0",
			"skin_tone_support": false,
			"aliases": [
				"kiwi_fruit",
				"fruit",
				"food",
				"chinese",
				"gooseberry",
				"kiwifruit"
			]
		},
		"🍅": {
			"name": "tomato",
			"slug": "tomato",
			"group": "Food & Drink",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"tomato",
				"fruit",
				"vegetable",
				"nature",
				"food",
				"plant"
			]
		},
		"🫒": {
			"name": "olive",
			"slug": "olive",
			"group": "Food & Drink",
			"emoji_version": "13.0",
			"unicode_version": "13.0",
			"skin_tone_support": false,
			"aliases": [
				"olive",
				"fruit",
				"food",
				"olives"
			]
		},
		"🥥": {
			"name": "coconut",
			"slug": "coconut",
			"group": "Food & Drink",
			"emoji_version": "5.0",
			"unicode_version": "5.0",
			"skin_tone_support": false,
			"aliases": [
				"coconut",
				"fruit",
				"nature",
				"food",
				"palm",
				"cocoanut",
				"colada",
				"piña"
			]
		},
		"🥑": {
			"name": "avocado",
			"slug": "avocado",
			"group": "Food & Drink",
			"emoji_version": "3.0",
			"unicode_version": "3.0",
			"skin_tone_support": false,
			"aliases": [
				"avocado",
				"fruit",
				"food"
			]
		},
		"🍆": {
			"name": "eggplant",
			"slug": "eggplant",
			"group": "Food & Drink",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"eggplant",
				"vegetable",
				"nature",
				"food",
				"aubergine",
				"phallic",
				"plant",
				"purple"
			]
		},
		"🥔": {
			"name": "potato",
			"slug": "potato",
			"group": "Food & Drink",
			"emoji_version": "3.0",
			"unicode_version": "3.0",
			"skin_tone_support": false,
			"aliases": [
				"potato",
				"food",
				"tuber",
				"vegatable",
				"starch",
				"baked",
				"idaho",
				"vegetable"
			]
		},
		"🥕": {
			"name": "carrot",
			"slug": "carrot",
			"group": "Food & Drink",
			"emoji_version": "3.0",
			"unicode_version": "3.0",
			"skin_tone_support": false,
			"aliases": [
				"carrot",
				"vegetable",
				"food",
				"orange"
			]
		},
		"🌽": {
			"name": "ear of corn",
			"slug": "ear_of_corn",
			"group": "Food & Drink",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"ear_of_corn",
				"food",
				"vegetable",
				"plant",
				"cob",
				"maize",
				"maze"
			]
		},
		"🌶️": {
			"name": "hot pepper",
			"slug": "hot_pepper",
			"group": "Food & Drink",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"hot_pepper",
				"food",
				"spicy",
				"chilli",
				"chili",
				"plant"
			]
		},
		"🫑": {
			"name": "bell pepper",
			"slug": "bell_pepper",
			"group": "Food & Drink",
			"emoji_version": "13.0",
			"unicode_version": "13.0",
			"skin_tone_support": false,
			"aliases": [
				"bell pepper",
				"fruit",
				"plant",
				"capsicum",
				"vegetable"
			]
		},
		"🥒": {
			"name": "cucumber",
			"slug": "cucumber",
			"group": "Food & Drink",
			"emoji_version": "3.0",
			"unicode_version": "3.0",
			"skin_tone_support": false,
			"aliases": [
				"cucumber",
				"fruit",
				"food",
				"pickle",
				"gherkin",
				"vegetable"
			]
		},
		"🥬": {
			"name": "leafy green",
			"slug": "leafy_green",
			"group": "Food & Drink",
			"emoji_version": "11.0",
			"unicode_version": "11.0",
			"skin_tone_support": false,
			"aliases": [
				"leafy_green",
				"food",
				"vegetable",
				"plant",
				"bok choy",
				"cabbage",
				"kale",
				"lettuce",
				"chinese",
				"cos",
				"greens",
				"romaine"
			]
		},
		"🥦": {
			"name": "broccoli",
			"slug": "broccoli",
			"group": "Food & Drink",
			"emoji_version": "5.0",
			"unicode_version": "5.0",
			"skin_tone_support": false,
			"aliases": [
				"broccoli",
				"fruit",
				"food",
				"vegetable",
				"cabbage",
				"wild"
			]
		},
		"🧄": {
			"name": "garlic",
			"slug": "garlic",
			"group": "Food & Drink",
			"emoji_version": "12.0",
			"unicode_version": "12.0",
			"skin_tone_support": false,
			"aliases": [
				"garlic",
				"food",
				"spice",
				"cook",
				"flavoring",
				"plant",
				"vegetable"
			]
		},
		"🧅": {
			"name": "onion",
			"slug": "onion",
			"group": "Food & Drink",
			"emoji_version": "12.0",
			"unicode_version": "12.0",
			"skin_tone_support": false,
			"aliases": [
				"onion",
				"cook",
				"food",
				"spice",
				"flavoring",
				"plant",
				"vegetable"
			]
		},
		"🥜": {
			"name": "peanuts",
			"slug": "peanuts",
			"group": "Food & Drink",
			"emoji_version": "3.0",
			"unicode_version": "3.0",
			"skin_tone_support": false,
			"aliases": [
				"peanuts",
				"food",
				"nut",
				"nuts",
				"peanut",
				"vegetable"
			]
		},
		"🫘": {
			"name": "beans",
			"slug": "beans",
			"group": "Food & Drink",
			"emoji_version": "14.0",
			"unicode_version": "14.0",
			"skin_tone_support": false,
			"aliases": [
				"beans",
				"food",
				"kidney",
				"legume"
			]
		},
		"🌰": {
			"name": "chestnut",
			"slug": "chestnut",
			"group": "Food & Drink",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"chestnut",
				"food",
				"squirrel",
				"acorn",
				"nut",
				"plant"
			]
		},
		"🫚": {
			"name": "ginger root",
			"slug": "ginger_root",
			"group": "Food & Drink",
			"emoji_version": "15.0",
			"unicode_version": "15.0",
			"skin_tone_support": false,
			"aliases": [
				"ginger root",
				"spice",
				"yellow",
				"cooking",
				"gingerbread"
			]
		},
		"🫛": {
			"name": "pea pod",
			"slug": "pea_pod",
			"group": "Food & Drink",
			"emoji_version": "15.0",
			"unicode_version": "15.0",
			"skin_tone_support": false,
			"aliases": [
				"pea pod",
				"cozy",
				"green"
			]
		},
		"🍄‍🟫": {
			"name": "brown mushroom",
			"slug": "brown_mushroom",
			"group": "Food & Drink",
			"emoji_version": "15.1",
			"unicode_version": "15.1",
			"skin_tone_support": false,
			"aliases": [
				"brown mushroom",
				"toadstool",
				"fungus"
			]
		},
		"🫜": {
			"name": "root vegetable",
			"slug": "root_vegetable",
			"group": "Food & Drink",
			"emoji_version": "16.0",
			"unicode_version": "16.0",
			"skin_tone_support": false,
			"aliases": ["root vegetable", "radish"]
		},
		"🍞": {
			"name": "bread",
			"slug": "bread",
			"group": "Food & Drink",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"bread",
				"food",
				"wheat",
				"breakfast",
				"toast",
				"loaf"
			]
		},
		"🥐": {
			"name": "croissant",
			"slug": "croissant",
			"group": "Food & Drink",
			"emoji_version": "3.0",
			"unicode_version": "3.0",
			"skin_tone_support": false,
			"aliases": [
				"croissant",
				"food",
				"bread",
				"french",
				"breakfast",
				"crescent",
				"roll"
			]
		},
		"🥖": {
			"name": "baguette bread",
			"slug": "baguette_bread",
			"group": "Food & Drink",
			"emoji_version": "3.0",
			"unicode_version": "3.0",
			"skin_tone_support": false,
			"aliases": [
				"baguette_bread",
				"food",
				"bread",
				"french",
				"france",
				"bakery"
			]
		},
		"🫓": {
			"name": "flatbread",
			"slug": "flatbread",
			"group": "Food & Drink",
			"emoji_version": "13.0",
			"unicode_version": "13.0",
			"skin_tone_support": false,
			"aliases": [
				"flatbread",
				"flour",
				"food",
				"bakery",
				"arepa",
				"bread",
				"flat",
				"lavash",
				"naan",
				"pita"
			]
		},
		"🥨": {
			"name": "pretzel",
			"slug": "pretzel",
			"group": "Food & Drink",
			"emoji_version": "5.0",
			"unicode_version": "5.0",
			"skin_tone_support": false,
			"aliases": [
				"pretzel",
				"food",
				"bread",
				"twisted",
				"germany",
				"bakery",
				"soft",
				"twist"
			]
		},
		"🥯": {
			"name": "bagel",
			"slug": "bagel",
			"group": "Food & Drink",
			"emoji_version": "11.0",
			"unicode_version": "11.0",
			"skin_tone_support": false,
			"aliases": [
				"bagel",
				"food",
				"bread",
				"bakery",
				"schmear",
				"jewish_bakery",
				"breakfast",
				"cheese",
				"cream"
			]
		},
		"🥞": {
			"name": "pancakes",
			"slug": "pancakes",
			"group": "Food & Drink",
			"emoji_version": "3.0",
			"unicode_version": "3.0",
			"skin_tone_support": false,
			"aliases": [
				"pancakes",
				"food",
				"breakfast",
				"flapjacks",
				"hotcakes",
				"brunch",
				"crêpe",
				"crêpes",
				"hotcake",
				"pancake"
			]
		},
		"🧇": {
			"name": "waffle",
			"slug": "waffle",
			"group": "Food & Drink",
			"emoji_version": "12.0",
			"unicode_version": "12.0",
			"skin_tone_support": false,
			"aliases": [
				"waffle",
				"food",
				"breakfast",
				"brunch",
				"indecisive",
				"iron"
			]
		},
		"🧀": {
			"name": "cheese wedge",
			"slug": "cheese_wedge",
			"group": "Food & Drink",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"cheese_wedge",
				"food",
				"chadder",
				"swiss"
			]
		},
		"🍖": {
			"name": "meat on bone",
			"slug": "meat_on_bone",
			"group": "Food & Drink",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"meat_on_bone",
				"good",
				"food",
				"drumstick",
				"barbecue",
				"bbq",
				"manga"
			]
		},
		"🍗": {
			"name": "poultry leg",
			"slug": "poultry_leg",
			"group": "Food & Drink",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"poultry_leg",
				"food",
				"meat",
				"drumstick",
				"bird",
				"chicken",
				"turkey",
				"bone"
			]
		},
		"🥩": {
			"name": "cut of meat",
			"slug": "cut_of_meat",
			"group": "Food & Drink",
			"emoji_version": "5.0",
			"unicode_version": "5.0",
			"skin_tone_support": false,
			"aliases": [
				"cut_of_meat",
				"food",
				"cow",
				"meat",
				"cut",
				"chop",
				"lambchop",
				"porkchop",
				"steak"
			]
		},
		"🥓": {
			"name": "bacon",
			"slug": "bacon",
			"group": "Food & Drink",
			"emoji_version": "3.0",
			"unicode_version": "3.0",
			"skin_tone_support": false,
			"aliases": [
				"bacon",
				"food",
				"breakfast",
				"pork",
				"pig",
				"meat",
				"brunch",
				"rashers"
			]
		},
		"🍔": {
			"name": "hamburger",
			"slug": "hamburger",
			"group": "Food & Drink",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"hamburger",
				"meat",
				"fast food",
				"beef",
				"cheeseburger",
				"mcdonalds",
				"burger king"
			]
		},
		"🍟": {
			"name": "french fries",
			"slug": "french_fries",
			"group": "Food & Drink",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"french_fries",
				"chips",
				"snack",
				"fast food",
				"potato",
				"mcdonald's"
			]
		},
		"🍕": {
			"name": "pizza",
			"slug": "pizza",
			"group": "Food & Drink",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"pizza",
				"food",
				"party",
				"italy",
				"cheese",
				"pepperoni",
				"slice"
			]
		},
		"🌭": {
			"name": "hot dog",
			"slug": "hot_dog",
			"group": "Food & Drink",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"hot_dog",
				"food",
				"frankfurter",
				"america",
				"hotdog",
				"redhot",
				"sausage",
				"wiener"
			]
		},
		"🥪": {
			"name": "sandwich",
			"slug": "sandwich",
			"group": "Food & Drink",
			"emoji_version": "5.0",
			"unicode_version": "5.0",
			"skin_tone_support": false,
			"aliases": [
				"sandwich",
				"food",
				"lunch",
				"bread",
				"toast",
				"bakery",
				"cheese",
				"deli",
				"meat",
				"vegetables"
			]
		},
		"🌮": {
			"name": "taco",
			"slug": "taco",
			"group": "Food & Drink",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"taco",
				"food",
				"mexican"
			]
		},
		"🌯": {
			"name": "burrito",
			"slug": "burrito",
			"group": "Food & Drink",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"burrito",
				"food",
				"mexican",
				"wrap"
			]
		},
		"🫔": {
			"name": "tamale",
			"slug": "tamale",
			"group": "Food & Drink",
			"emoji_version": "13.0",
			"unicode_version": "13.0",
			"skin_tone_support": false,
			"aliases": [
				"tamale",
				"food",
				"masa",
				"mexican",
				"tamal",
				"wrapped"
			]
		},
		"🥙": {
			"name": "stuffed flatbread",
			"slug": "stuffed_flatbread",
			"group": "Food & Drink",
			"emoji_version": "3.0",
			"unicode_version": "3.0",
			"skin_tone_support": false,
			"aliases": [
				"stuffed_flatbread",
				"food",
				"flatbread",
				"stuffed",
				"gyro",
				"mediterranean",
				"doner",
				"falafel",
				"kebab",
				"pita",
				"sandwich",
				"shawarma"
			]
		},
		"🧆": {
			"name": "falafel",
			"slug": "falafel",
			"group": "Food & Drink",
			"emoji_version": "12.0",
			"unicode_version": "12.0",
			"skin_tone_support": false,
			"aliases": [
				"falafel",
				"food",
				"mediterranean",
				"chickpea",
				"falfel",
				"meatball"
			]
		},
		"🥚": {
			"name": "egg",
			"slug": "egg",
			"group": "Food & Drink",
			"emoji_version": "3.0",
			"unicode_version": "3.0",
			"skin_tone_support": false,
			"aliases": [
				"egg",
				"food",
				"chicken",
				"breakfast",
				"easter_egg"
			]
		},
		"🍳": {
			"name": "cooking",
			"slug": "cooking",
			"group": "Food & Drink",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"cooking",
				"food",
				"breakfast",
				"kitchen",
				"egg",
				"skillet",
				"fried",
				"frying",
				"pan"
			]
		},
		"🥘": {
			"name": "shallow pan of food",
			"slug": "shallow_pan_of_food",
			"group": "Food & Drink",
			"emoji_version": "3.0",
			"unicode_version": "3.0",
			"skin_tone_support": false,
			"aliases": [
				"shallow_pan_of_food",
				"food",
				"cooking",
				"casserole",
				"paella",
				"skillet",
				"curry"
			]
		},
		"🍲": {
			"name": "pot of food",
			"slug": "pot_of_food",
			"group": "Food & Drink",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"pot_of_food",
				"food",
				"meat",
				"soup",
				"hot pot",
				"bowl",
				"stew"
			]
		},
		"🫕": {
			"name": "fondue",
			"slug": "fondue",
			"group": "Food & Drink",
			"emoji_version": "13.0",
			"unicode_version": "13.0",
			"skin_tone_support": false,
			"aliases": [
				"fondue",
				"cheese",
				"pot",
				"food",
				"chocolate",
				"melted",
				"swiss"
			]
		},
		"🥣": {
			"name": "bowl with spoon",
			"slug": "bowl_with_spoon",
			"group": "Food & Drink",
			"emoji_version": "5.0",
			"unicode_version": "5.0",
			"skin_tone_support": false,
			"aliases": [
				"bowl_with_spoon",
				"food",
				"breakfast",
				"cereal",
				"oatmeal",
				"porridge",
				"congee",
				"tableware"
			]
		},
		"🥗": {
			"name": "green salad",
			"slug": "green_salad",
			"group": "Food & Drink",
			"emoji_version": "3.0",
			"unicode_version": "3.0",
			"skin_tone_support": false,
			"aliases": [
				"green_salad",
				"food",
				"healthy",
				"lettuce",
				"vegetable"
			]
		},
		"🍿": {
			"name": "popcorn",
			"slug": "popcorn",
			"group": "Food & Drink",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"popcorn",
				"food",
				"movie theater",
				"films",
				"snack",
				"drama",
				"corn",
				"popping"
			]
		},
		"🧈": {
			"name": "butter",
			"slug": "butter",
			"group": "Food & Drink",
			"emoji_version": "12.0",
			"unicode_version": "12.0",
			"skin_tone_support": false,
			"aliases": [
				"butter",
				"food",
				"cook",
				"dairy"
			]
		},
		"🧂": {
			"name": "salt",
			"slug": "salt",
			"group": "Food & Drink",
			"emoji_version": "11.0",
			"unicode_version": "11.0",
			"skin_tone_support": false,
			"aliases": [
				"salt",
				"condiment",
				"shaker"
			]
		},
		"🥫": {
			"name": "canned food",
			"slug": "canned_food",
			"group": "Food & Drink",
			"emoji_version": "5.0",
			"unicode_version": "5.0",
			"skin_tone_support": false,
			"aliases": [
				"canned_food",
				"food",
				"soup",
				"tomatoes",
				"can",
				"preserve",
				"tin",
				"tinned"
			]
		},
		"🍱": {
			"name": "bento box",
			"slug": "bento_box",
			"group": "Food & Drink",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"bento_box",
				"food",
				"japanese",
				"box",
				"lunch",
				"assets"
			]
		},
		"🍘": {
			"name": "rice cracker",
			"slug": "rice_cracker",
			"group": "Food & Drink",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"rice_cracker",
				"food",
				"japanese",
				"snack",
				"senbei"
			]
		},
		"🍙": {
			"name": "rice ball",
			"slug": "rice_ball",
			"group": "Food & Drink",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"rice_ball",
				"food",
				"japanese",
				"onigiri",
				"omusubi"
			]
		},
		"🍚": {
			"name": "cooked rice",
			"slug": "cooked_rice",
			"group": "Food & Drink",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"cooked_rice",
				"food",
				"asian",
				"boiled",
				"bowl",
				"steamed"
			]
		},
		"🍛": {
			"name": "curry rice",
			"slug": "curry_rice",
			"group": "Food & Drink",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"curry_rice",
				"food",
				"spicy",
				"hot",
				"indian"
			]
		},
		"🍜": {
			"name": "steaming bowl",
			"slug": "steaming_bowl",
			"group": "Food & Drink",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"steaming_bowl",
				"food",
				"japanese",
				"noodle",
				"chopsticks",
				"ramen",
				"noodles",
				"soup"
			]
		},
		"🍝": {
			"name": "spaghetti",
			"slug": "spaghetti",
			"group": "Food & Drink",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"spaghetti",
				"food",
				"italian",
				"pasta",
				"noodle"
			]
		},
		"🍠": {
			"name": "roasted sweet potato",
			"slug": "roasted_sweet_potato",
			"group": "Food & Drink",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"roasted_sweet_potato",
				"food",
				"nature",
				"plant",
				"goguma",
				"yam"
			]
		},
		"🍢": {
			"name": "oden",
			"slug": "oden",
			"group": "Food & Drink",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"oden",
				"skewer",
				"food",
				"japanese",
				"kebab",
				"seafood",
				"stick"
			]
		},
		"🍣": {
			"name": "sushi",
			"slug": "sushi",
			"group": "Food & Drink",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"sushi",
				"food",
				"fish",
				"japanese",
				"rice",
				"sashimi",
				"seafood"
			]
		},
		"🍤": {
			"name": "fried shrimp",
			"slug": "fried_shrimp",
			"group": "Food & Drink",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"fried_shrimp",
				"food",
				"animal",
				"appetizer",
				"summer",
				"prawn",
				"tempura"
			]
		},
		"🍥": {
			"name": "fish cake with swirl",
			"slug": "fish_cake_with_swirl",
			"group": "Food & Drink",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"fish_cake_with_swirl",
				"food",
				"japan",
				"sea",
				"beach",
				"narutomaki",
				"pink",
				"swirl",
				"kamaboko",
				"surimi",
				"ramen",
				"design",
				"fishcake",
				"pastry"
			]
		},
		"🥮": {
			"name": "moon cake",
			"slug": "moon_cake",
			"group": "Food & Drink",
			"emoji_version": "11.0",
			"unicode_version": "11.0",
			"skin_tone_support": false,
			"aliases": [
				"moon_cake",
				"food",
				"autumn",
				"dessert",
				"festival",
				"mooncake",
				"yuèbǐng"
			]
		},
		"🍡": {
			"name": "dango",
			"slug": "dango",
			"group": "Food & Drink",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"dango",
				"food",
				"dessert",
				"sweet",
				"japanese",
				"barbecue",
				"meat",
				"balls",
				"green",
				"pink",
				"skewer",
				"stick",
				"white"
			]
		},
		"🥟": {
			"name": "dumpling",
			"slug": "dumpling",
			"group": "Food & Drink",
			"emoji_version": "5.0",
			"unicode_version": "5.0",
			"skin_tone_support": false,
			"aliases": [
				"dumpling",
				"food",
				"empanada",
				"pierogi",
				"potsticker",
				"gyoza",
				"gyōza",
				"jiaozi"
			]
		},
		"🥠": {
			"name": "fortune cookie",
			"slug": "fortune_cookie",
			"group": "Food & Drink",
			"emoji_version": "5.0",
			"unicode_version": "5.0",
			"skin_tone_support": false,
			"aliases": [
				"fortune_cookie",
				"food",
				"prophecy",
				"dessert"
			]
		},
		"🥡": {
			"name": "takeout box",
			"slug": "takeout_box",
			"group": "Food & Drink",
			"emoji_version": "5.0",
			"unicode_version": "5.0",
			"skin_tone_support": false,
			"aliases": [
				"takeout_box",
				"food",
				"leftovers",
				"chinese",
				"container",
				"out",
				"oyster",
				"pail",
				"take"
			]
		},
		"🍦": {
			"name": "soft ice cream",
			"slug": "soft_ice_cream",
			"group": "Food & Drink",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"soft_ice_cream",
				"food",
				"hot",
				"dessert",
				"summer",
				"icecream",
				"mr.",
				"serve",
				"sweet",
				"whippy"
			]
		},
		"🍧": {
			"name": "shaved ice",
			"slug": "shaved_ice",
			"group": "Food & Drink",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"shaved_ice",
				"hot",
				"dessert",
				"summer",
				"cone",
				"snow",
				"sweet"
			]
		},
		"🍨": {
			"name": "ice cream",
			"slug": "ice_cream",
			"group": "Food & Drink",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"ice_cream",
				"food",
				"hot",
				"dessert",
				"bowl",
				"sweet"
			]
		},
		"🍩": {
			"name": "doughnut",
			"slug": "doughnut",
			"group": "Food & Drink",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"doughnut",
				"food",
				"dessert",
				"snack",
				"sweet",
				"donut",
				"breakfast"
			]
		},
		"🍪": {
			"name": "cookie",
			"slug": "cookie",
			"group": "Food & Drink",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"cookie",
				"food",
				"snack",
				"oreo",
				"chocolate",
				"sweet",
				"dessert",
				"biscuit",
				"chip"
			]
		},
		"🎂": {
			"name": "birthday cake",
			"slug": "birthday_cake",
			"group": "Food & Drink",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"birthday_cake",
				"food",
				"dessert",
				"cake",
				"candles",
				"celebration",
				"party",
				"pastry",
				"sweet"
			]
		},
		"🍰": {
			"name": "shortcake",
			"slug": "shortcake",
			"group": "Food & Drink",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"shortcake",
				"food",
				"dessert",
				"cake",
				"pastry",
				"piece",
				"slice",
				"strawberry",
				"sweet"
			]
		},
		"🧁": {
			"name": "cupcake",
			"slug": "cupcake",
			"group": "Food & Drink",
			"emoji_version": "11.0",
			"unicode_version": "11.0",
			"skin_tone_support": false,
			"aliases": [
				"cupcake",
				"food",
				"dessert",
				"bakery",
				"sweet",
				"cake",
				"fairy",
				"pastry"
			]
		},
		"🥧": {
			"name": "pie",
			"slug": "pie",
			"group": "Food & Drink",
			"emoji_version": "5.0",
			"unicode_version": "5.0",
			"skin_tone_support": false,
			"aliases": [
				"pie",
				"food",
				"dessert",
				"pastry",
				"filling",
				"sweet"
			]
		},
		"🍫": {
			"name": "chocolate bar",
			"slug": "chocolate_bar",
			"group": "Food & Drink",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"chocolate_bar",
				"food",
				"snack",
				"dessert",
				"sweet",
				"candy"
			]
		},
		"🍬": {
			"name": "candy",
			"slug": "candy",
			"group": "Food & Drink",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"candy",
				"snack",
				"dessert",
				"sweet",
				"lolly"
			]
		},
		"🍭": {
			"name": "lollipop",
			"slug": "lollipop",
			"group": "Food & Drink",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"lollipop",
				"food",
				"snack",
				"candy",
				"sweet",
				"dessert",
				"lollypop",
				"sucker"
			]
		},
		"🍮": {
			"name": "custard",
			"slug": "custard",
			"group": "Food & Drink",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"custard",
				"dessert",
				"food",
				"pudding",
				"flan",
				"caramel",
				"creme",
				"sweet"
			]
		},
		"🍯": {
			"name": "honey pot",
			"slug": "honey_pot",
			"group": "Food & Drink",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"honey_pot",
				"bees",
				"sweet",
				"kitchen",
				"honeypot"
			]
		},
		"🍼": {
			"name": "baby bottle",
			"slug": "baby_bottle",
			"group": "Food & Drink",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"baby_bottle",
				"food",
				"container",
				"milk",
				"drink",
				"feeding"
			]
		},
		"🥛": {
			"name": "glass of milk",
			"slug": "glass_of_milk",
			"group": "Food & Drink",
			"emoji_version": "3.0",
			"unicode_version": "3.0",
			"skin_tone_support": false,
			"aliases": [
				"glass_of_milk",
				"beverage",
				"drink",
				"cow"
			]
		},
		"☕": {
			"name": "hot beverage",
			"slug": "hot_beverage",
			"group": "Food & Drink",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"hot_beverage",
				"beverage",
				"caffeine",
				"latte",
				"espresso",
				"coffee",
				"mug",
				"cafe",
				"chocolate",
				"drink",
				"steaming",
				"tea"
			]
		},
		"🫖": {
			"name": "teapot",
			"slug": "teapot",
			"group": "Food & Drink",
			"emoji_version": "13.0",
			"unicode_version": "13.0",
			"skin_tone_support": false,
			"aliases": [
				"teapot",
				"drink",
				"hot",
				"kettle",
				"pot",
				"tea"
			]
		},
		"🍵": {
			"name": "teacup without handle",
			"slug": "teacup_without_handle",
			"group": "Food & Drink",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"teacup_without_handle",
				"drink",
				"bowl",
				"breakfast",
				"green",
				"british",
				"beverage",
				"cup",
				"matcha",
				"tea"
			]
		},
		"🍶": {
			"name": "sake",
			"slug": "sake",
			"group": "Food & Drink",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"sake",
				"wine",
				"drink",
				"drunk",
				"beverage",
				"japanese",
				"alcohol",
				"booze",
				"bar",
				"bottle",
				"cup",
				"rice"
			]
		},
		"🍾": {
			"name": "bottle with popping cork",
			"slug": "bottle_with_popping_cork",
			"group": "Food & Drink",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"bottle_with_popping_cork",
				"drink",
				"wine",
				"bottle",
				"celebration",
				"bar",
				"bubbly",
				"champagne",
				"party",
				"sparkling"
			]
		},
		"🍷": {
			"name": "wine glass",
			"slug": "wine_glass",
			"group": "Food & Drink",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"wine_glass",
				"drink",
				"beverage",
				"drunk",
				"alcohol",
				"booze",
				"bar",
				"red"
			]
		},
		"🍸": {
			"name": "cocktail glass",
			"slug": "cocktail_glass",
			"group": "Food & Drink",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"cocktail_glass",
				"drink",
				"drunk",
				"alcohol",
				"beverage",
				"booze",
				"mojito",
				"bar",
				"martini"
			]
		},
		"🍹": {
			"name": "tropical drink",
			"slug": "tropical_drink",
			"group": "Food & Drink",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"tropical_drink",
				"beverage",
				"cocktail",
				"summer",
				"beach",
				"alcohol",
				"booze",
				"mojito",
				"bar",
				"fruit",
				"punch",
				"tiki",
				"vacation"
			]
		},
		"🍺": {
			"name": "beer mug",
			"slug": "beer_mug",
			"group": "Food & Drink",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"beer_mug",
				"relax",
				"beverage",
				"drink",
				"drunk",
				"party",
				"pub",
				"summer",
				"alcohol",
				"booze",
				"bar",
				"stein"
			]
		},
		"🍻": {
			"name": "clinking beer mugs",
			"slug": "clinking_beer_mugs",
			"group": "Food & Drink",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"clinking_beer_mugs",
				"relax",
				"beverage",
				"drink",
				"drunk",
				"party",
				"pub",
				"summer",
				"alcohol",
				"booze",
				"bar",
				"beers",
				"cheers",
				"clink",
				"drinks",
				"mug"
			]
		},
		"🥂": {
			"name": "clinking glasses",
			"slug": "clinking_glasses",
			"group": "Food & Drink",
			"emoji_version": "3.0",
			"unicode_version": "3.0",
			"skin_tone_support": false,
			"aliases": [
				"clinking_glasses",
				"beverage",
				"drink",
				"party",
				"alcohol",
				"celebrate",
				"cheers",
				"wine",
				"champagne",
				"toast",
				"celebration",
				"clink",
				"glass"
			]
		},
		"🥃": {
			"name": "tumbler glass",
			"slug": "tumbler_glass",
			"group": "Food & Drink",
			"emoji_version": "3.0",
			"unicode_version": "3.0",
			"skin_tone_support": false,
			"aliases": [
				"tumbler_glass",
				"drink",
				"beverage",
				"drunk",
				"alcohol",
				"liquor",
				"booze",
				"bourbon",
				"scotch",
				"whisky",
				"glass",
				"shot",
				"rum",
				"whiskey"
			]
		},
		"🫗": {
			"name": "pouring liquid",
			"slug": "pouring_liquid",
			"group": "Food & Drink",
			"emoji_version": "14.0",
			"unicode_version": "14.0",
			"skin_tone_support": false,
			"aliases": [
				"pouring liquid",
				"cup",
				"water",
				"drink",
				"empty",
				"glass",
				"spill"
			]
		},
		"🥤": {
			"name": "cup with straw",
			"slug": "cup_with_straw",
			"group": "Food & Drink",
			"emoji_version": "5.0",
			"unicode_version": "5.0",
			"skin_tone_support": false,
			"aliases": [
				"cup_with_straw",
				"drink",
				"soda",
				"go",
				"juice",
				"malt",
				"milkshake",
				"pop",
				"smoothie",
				"soft",
				"tableware",
				"water"
			]
		},
		"🧋": {
			"name": "bubble tea",
			"slug": "bubble_tea",
			"group": "Food & Drink",
			"emoji_version": "13.0",
			"unicode_version": "13.0",
			"skin_tone_support": false,
			"aliases": [
				"bubble tea",
				"taiwan",
				"boba",
				"milk tea",
				"straw",
				"momi",
				"pearl",
				"tapioca"
			]
		},
		"🧃": {
			"name": "beverage box",
			"slug": "beverage_box",
			"group": "Food & Drink",
			"emoji_version": "12.0",
			"unicode_version": "12.0",
			"skin_tone_support": false,
			"aliases": [
				"beverage_box",
				"drink",
				"juice",
				"straw",
				"sweet"
			]
		},
		"🧉": {
			"name": "mate",
			"slug": "mate",
			"group": "Food & Drink",
			"emoji_version": "12.0",
			"unicode_version": "12.0",
			"skin_tone_support": false,
			"aliases": [
				"mate",
				"drink",
				"tea",
				"beverage",
				"bombilla",
				"chimarrão",
				"cimarrón",
				"maté",
				"yerba"
			]
		},
		"🧊": {
			"name": "ice",
			"slug": "ice",
			"group": "Food & Drink",
			"emoji_version": "12.0",
			"unicode_version": "12.0",
			"skin_tone_support": false,
			"aliases": [
				"ice",
				"water",
				"cold",
				"cube",
				"iceberg"
			]
		},
		"🥢": {
			"name": "chopsticks",
			"slug": "chopsticks",
			"group": "Food & Drink",
			"emoji_version": "5.0",
			"unicode_version": "5.0",
			"skin_tone_support": false,
			"aliases": [
				"chopsticks",
				"food",
				"hashi",
				"jeotgarak",
				"kuaizi"
			]
		},
		"🍽️": {
			"name": "fork and knife with plate",
			"slug": "fork_and_knife_with_plate",
			"group": "Food & Drink",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"fork_and_knife_with_plate",
				"food",
				"eat",
				"meal",
				"lunch",
				"dinner",
				"restaurant",
				"cooking",
				"cutlery",
				"dining",
				"tableware"
			]
		},
		"🍴": {
			"name": "fork and knife",
			"slug": "fork_and_knife",
			"group": "Food & Drink",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"fork_and_knife",
				"cutlery",
				"kitchen",
				"cooking",
				"silverware",
				"tableware"
			]
		},
		"🥄": {
			"name": "spoon",
			"slug": "spoon",
			"group": "Food & Drink",
			"emoji_version": "3.0",
			"unicode_version": "3.0",
			"skin_tone_support": false,
			"aliases": [
				"spoon",
				"cutlery",
				"kitchen",
				"tableware"
			]
		},
		"🔪": {
			"name": "kitchen knife",
			"slug": "kitchen_knife",
			"group": "Food & Drink",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"kitchen_knife",
				"knife",
				"blade",
				"cutlery",
				"kitchen",
				"weapon",
				"butchers",
				"chop",
				"cooking",
				"cut",
				"hocho",
				"tool"
			]
		},
		"🫙": {
			"name": "jar",
			"slug": "jar",
			"group": "Food & Drink",
			"emoji_version": "14.0",
			"unicode_version": "14.0",
			"skin_tone_support": false,
			"aliases": [
				"jar",
				"container",
				"sauce",
				"condiment",
				"empty",
				"store"
			]
		},
		"🏺": {
			"name": "amphora",
			"slug": "amphora",
			"group": "Food & Drink",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"amphora",
				"vase",
				"jar",
				"aquarius",
				"cooking",
				"drink",
				"jug",
				"tool",
				"zodiac"
			]
		},
		"🌍": {
			"name": "globe showing Europe-Africa",
			"slug": "globe_showing_europe_africa",
			"group": "Travel & Places",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"globe_showing_europe_africa",
				"globe",
				"world",
				"earth",
				"international",
				"planet"
			]
		},
		"🌎": {
			"name": "globe showing Americas",
			"slug": "globe_showing_americas",
			"group": "Travel & Places",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"globe_showing_americas",
				"globe",
				"world",
				"USA",
				"earth",
				"international",
				"planet"
			]
		},
		"🌏": {
			"name": "globe showing Asia-Australia",
			"slug": "globe_showing_asia_australia",
			"group": "Travel & Places",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"globe_showing_asia_australia",
				"globe",
				"world",
				"east",
				"earth",
				"international",
				"planet"
			]
		},
		"🌐": {
			"name": "globe with meridians",
			"slug": "globe_with_meridians",
			"group": "Travel & Places",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"globe_with_meridians",
				"earth",
				"international",
				"world",
				"internet",
				"interweb",
				"i18n",
				"global",
				"web",
				"wide",
				"www",
				"internationalization",
				"localization"
			]
		},
		"🗺️": {
			"name": "world map",
			"slug": "world_map",
			"group": "Travel & Places",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"world_map",
				"location",
				"direction",
				"travel"
			]
		},
		"🗾": {
			"name": "map of Japan",
			"slug": "map_of_japan",
			"group": "Travel & Places",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"map_of_japan",
				"nation",
				"country",
				"japanese",
				"asia",
				"silhouette"
			]
		},
		"🧭": {
			"name": "compass",
			"slug": "compass",
			"group": "Travel & Places",
			"emoji_version": "11.0",
			"unicode_version": "11.0",
			"skin_tone_support": false,
			"aliases": [
				"compass",
				"magnetic",
				"navigation",
				"orienteering"
			]
		},
		"🏔️": {
			"name": "snow-capped mountain",
			"slug": "snow_capped_mountain",
			"group": "Travel & Places",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"snow_capped_mountain",
				"photo",
				"nature",
				"environment",
				"winter",
				"cold"
			]
		},
		"⛰️": {
			"name": "mountain",
			"slug": "mountain",
			"group": "Travel & Places",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"mountain",
				"photo",
				"nature",
				"environment"
			]
		},
		"🛘": {
			"name": "landslide",
			"slug": "landslide",
			"group": "Travel & Places",
			"emoji_version": "17.0",
			"unicode_version": "17.0",
			"skin_tone_support": false,
			"aliases": [
				"landslide",
				"disaster",
				"accident"
			]
		},
		"🌋": {
			"name": "volcano",
			"slug": "volcano",
			"group": "Travel & Places",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"volcano",
				"photo",
				"nature",
				"disaster",
				"eruption",
				"mountain",
				"weather"
			]
		},
		"🗻": {
			"name": "mount fuji",
			"slug": "mount_fuji",
			"group": "Travel & Places",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"mount_fuji",
				"photo",
				"mountain",
				"nature",
				"japanese",
				"capped",
				"san",
				"snow"
			]
		},
		"🏕️": {
			"name": "camping",
			"slug": "camping",
			"group": "Travel & Places",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"camping",
				"photo",
				"outdoors",
				"tent",
				"campsite"
			]
		},
		"🏖️": {
			"name": "beach with umbrella",
			"slug": "beach_with_umbrella",
			"group": "Travel & Places",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"beach_with_umbrella",
				"weather",
				"summer",
				"sunny",
				"sand",
				"mojito"
			]
		},
		"🏜️": {
			"name": "desert",
			"slug": "desert",
			"group": "Travel & Places",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"desert",
				"photo",
				"warm",
				"saharah"
			]
		},
		"🏝️": {
			"name": "desert island",
			"slug": "desert_island",
			"group": "Travel & Places",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"desert_island",
				"photo",
				"tropical",
				"mojito"
			]
		},
		"🏞️": {
			"name": "national park",
			"slug": "national_park",
			"group": "Travel & Places",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"national_park",
				"photo",
				"environment",
				"nature"
			]
		},
		"🏟️": {
			"name": "stadium",
			"slug": "stadium",
			"group": "Travel & Places",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"stadium",
				"photo",
				"place",
				"sports",
				"concert",
				"venue",
				"grandstand",
				"sport"
			]
		},
		"🏛️": {
			"name": "classical building",
			"slug": "classical_building",
			"group": "Travel & Places",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"classical_building",
				"art",
				"culture",
				"history"
			]
		},
		"🏗️": {
			"name": "building construction",
			"slug": "building_construction",
			"group": "Travel & Places",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"building_construction",
				"wip",
				"working",
				"progress",
				"crane",
				"architectural"
			]
		},
		"🧱": {
			"name": "brick",
			"slug": "brick",
			"group": "Travel & Places",
			"emoji_version": "11.0",
			"unicode_version": "11.0",
			"skin_tone_support": false,
			"aliases": [
				"brick",
				"bricks",
				"clay",
				"construction",
				"mortar",
				"wall",
				"infrastructure"
			]
		},
		"🪨": {
			"name": "rock",
			"slug": "rock",
			"group": "Travel & Places",
			"emoji_version": "13.0",
			"unicode_version": "13.0",
			"skin_tone_support": false,
			"aliases": [
				"rock",
				"stone",
				"boulder",
				"construction",
				"heavy",
				"solid"
			]
		},
		"🪵": {
			"name": "wood",
			"slug": "wood",
			"group": "Travel & Places",
			"emoji_version": "13.0",
			"unicode_version": "13.0",
			"skin_tone_support": false,
			"aliases": [
				"wood",
				"nature",
				"timber",
				"trunk",
				"construction",
				"log",
				"lumber"
			]
		},
		"🛖": {
			"name": "hut",
			"slug": "hut",
			"group": "Travel & Places",
			"emoji_version": "13.0",
			"unicode_version": "13.0",
			"skin_tone_support": false,
			"aliases": [
				"hut",
				"house",
				"structure",
				"roundhouse",
				"yurt"
			]
		},
		"🏘️": {
			"name": "houses",
			"slug": "houses",
			"group": "Travel & Places",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"houses",
				"buildings",
				"photo",
				"building",
				"group",
				"house"
			]
		},
		"🏚️": {
			"name": "derelict house",
			"slug": "derelict_house",
			"group": "Travel & Places",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"derelict_house",
				"abandon",
				"evict",
				"broken",
				"building",
				"abandoned",
				"haunted",
				"old"
			]
		},
		"🏠": {
			"name": "house",
			"slug": "house",
			"group": "Travel & Places",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"house",
				"building",
				"home"
			]
		},
		"🏡": {
			"name": "house with garden",
			"slug": "house_with_garden",
			"group": "Travel & Places",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"house_with_garden",
				"home",
				"plant",
				"nature",
				"building",
				"tree"
			]
		},
		"🏢": {
			"name": "office building",
			"slug": "office_building",
			"group": "Travel & Places",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"office_building",
				"building",
				"bureau",
				"work",
				"city",
				"high",
				"rise"
			]
		},
		"🏣": {
			"name": "Japanese post office",
			"slug": "japanese_post_office",
			"group": "Travel & Places",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"japanese_post_office",
				"building",
				"envelope",
				"communication",
				"japan",
				"mark",
				"postal"
			]
		},
		"🏤": {
			"name": "post office",
			"slug": "post_office",
			"group": "Travel & Places",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"post_office",
				"building",
				"email",
				"european"
			]
		},
		"🏥": {
			"name": "hospital",
			"slug": "hospital",
			"group": "Travel & Places",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"hospital",
				"building",
				"health",
				"surgery",
				"doctor",
				"cross",
				"emergency",
				"medical",
				"medicine",
				"red",
				"room"
			]
		},
		"🏦": {
			"name": "bank",
			"slug": "bank",
			"group": "Travel & Places",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"bank",
				"building",
				"money",
				"sales",
				"cash",
				"business",
				"enterprise",
				"bakkureru",
				"bk",
				"branch"
			]
		},
		"🏨": {
			"name": "hotel",
			"slug": "hotel",
			"group": "Travel & Places",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"hotel",
				"building",
				"accomodation",
				"checkin",
				"accommodation",
				"h"
			]
		},
		"🏩": {
			"name": "love hotel",
			"slug": "love_hotel",
			"group": "Travel & Places",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"love_hotel",
				"like",
				"affection",
				"dating",
				"building",
				"heart",
				"hospital"
			]
		},
		"🏪": {
			"name": "convenience store",
			"slug": "convenience_store",
			"group": "Travel & Places",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"convenience_store",
				"building",
				"shopping",
				"groceries",
				"corner",
				"e",
				"eleven®",
				"hour",
				"kwik",
				"mart",
				"shop"
			]
		},
		"🏫": {
			"name": "school",
			"slug": "school",
			"group": "Travel & Places",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"school",
				"building",
				"student",
				"education",
				"learn",
				"teach",
				"clock",
				"elementary",
				"high",
				"middle",
				"tower"
			]
		},
		"🏬": {
			"name": "department store",
			"slug": "department_store",
			"group": "Travel & Places",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"department_store",
				"building",
				"shopping",
				"mall",
				"center",
				"shops"
			]
		},
		"🏭": {
			"name": "factory",
			"slug": "factory",
			"group": "Travel & Places",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"factory",
				"building",
				"industry",
				"pollution",
				"smoke",
				"industrial",
				"smog"
			]
		},
		"🏯": {
			"name": "Japanese castle",
			"slug": "japanese_castle",
			"group": "Travel & Places",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"japanese_castle",
				"photo",
				"building",
				"fortress"
			]
		},
		"🏰": {
			"name": "castle",
			"slug": "castle",
			"group": "Travel & Places",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"castle",
				"building",
				"royalty",
				"history",
				"european",
				"turrets"
			]
		},
		"💒": {
			"name": "wedding",
			"slug": "wedding",
			"group": "Travel & Places",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"wedding",
				"love",
				"like",
				"affection",
				"couple",
				"marriage",
				"bride",
				"groom",
				"activity",
				"chapel",
				"church",
				"heart",
				"romance"
			]
		},
		"🗼": {
			"name": "Tokyo tower",
			"slug": "tokyo_tower",
			"group": "Travel & Places",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"tokyo_tower",
				"photo",
				"japanese",
				"eiffel",
				"red"
			]
		},
		"🗽": {
			"name": "Statue of Liberty",
			"slug": "statue_of_liberty",
			"group": "Travel & Places",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"statue_of_liberty",
				"american",
				"newyork",
				"new",
				"york"
			]
		},
		"⛪": {
			"name": "church",
			"slug": "church",
			"group": "Travel & Places",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"church",
				"building",
				"religion",
				"christ",
				"christian",
				"cross"
			]
		},
		"🕌": {
			"name": "mosque",
			"slug": "mosque",
			"group": "Travel & Places",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"mosque",
				"islam",
				"worship",
				"minaret",
				"domed",
				"muslim",
				"religion",
				"roof"
			]
		},
		"🛕": {
			"name": "hindu temple",
			"slug": "hindu_temple",
			"group": "Travel & Places",
			"emoji_version": "12.0",
			"unicode_version": "12.0",
			"skin_tone_support": false,
			"aliases": ["hindu_temple", "religion"]
		},
		"🕍": {
			"name": "synagogue",
			"slug": "synagogue",
			"group": "Travel & Places",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"synagogue",
				"judaism",
				"worship",
				"temple",
				"jewish",
				"jew",
				"religion",
				"synagog"
			]
		},
		"⛩️": {
			"name": "shinto shrine",
			"slug": "shinto_shrine",
			"group": "Travel & Places",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"shinto_shrine",
				"temple",
				"japan",
				"kyoto",
				"kami",
				"michi",
				"no",
				"religion"
			]
		},
		"🕋": {
			"name": "kaaba",
			"slug": "kaaba",
			"group": "Travel & Places",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"kaaba",
				"mecca",
				"mosque",
				"islam",
				"muslim",
				"religion"
			]
		},
		"⛲": {
			"name": "fountain",
			"slug": "fountain",
			"group": "Travel & Places",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"fountain",
				"photo",
				"summer",
				"water",
				"fresh",
				"feature",
				"park"
			]
		},
		"⛺": {
			"name": "tent",
			"slug": "tent",
			"group": "Travel & Places",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"tent",
				"photo",
				"camping",
				"outdoors"
			]
		},
		"🌁": {
			"name": "foggy",
			"slug": "foggy",
			"group": "Travel & Places",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"foggy",
				"photo",
				"mountain",
				"bridge",
				"city",
				"fog",
				"fog\xA0bridge",
				"karl",
				"under",
				"weather"
			]
		},
		"🌃": {
			"name": "night with stars",
			"slug": "night_with_stars",
			"group": "Travel & Places",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"night_with_stars",
				"evening",
				"city",
				"downtown",
				"star",
				"starry",
				"weather"
			]
		},
		"🏙️": {
			"name": "cityscape",
			"slug": "cityscape",
			"group": "Travel & Places",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"cityscape",
				"photo",
				"night life",
				"urban",
				"building",
				"city",
				"skyline"
			]
		},
		"🌄": {
			"name": "sunrise over mountains",
			"slug": "sunrise_over_mountains",
			"group": "Travel & Places",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"sunrise_over_mountains",
				"view",
				"vacation",
				"photo",
				"morning",
				"mountain",
				"sun",
				"weather"
			]
		},
		"🌅": {
			"name": "sunrise",
			"slug": "sunrise",
			"group": "Travel & Places",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"sunrise",
				"morning",
				"view",
				"vacation",
				"photo",
				"sun",
				"sunset",
				"weather"
			]
		},
		"🌆": {
			"name": "cityscape at dusk",
			"slug": "cityscape_at_dusk",
			"group": "Travel & Places",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"cityscape_at_dusk",
				"photo",
				"evening",
				"sky",
				"buildings",
				"building",
				"city",
				"landscape",
				"orange",
				"sun",
				"sunset",
				"weather"
			]
		},
		"🌇": {
			"name": "sunset",
			"slug": "sunset",
			"group": "Travel & Places",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"sunset",
				"photo",
				"good morning",
				"dawn",
				"building",
				"buildings",
				"city",
				"dusk",
				"over",
				"sun",
				"sunrise",
				"weather"
			]
		},
		"🌉": {
			"name": "bridge at night",
			"slug": "bridge_at_night",
			"group": "Travel & Places",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"bridge_at_night",
				"photo",
				"sanfrancisco",
				"gate",
				"golden",
				"weather"
			]
		},
		"♨️": {
			"name": "hot springs",
			"slug": "hot_springs",
			"group": "Travel & Places",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"hot_springs",
				"bath",
				"warm",
				"relax",
				"hotsprings",
				"onsen",
				"steam",
				"steaming"
			]
		},
		"🎠": {
			"name": "carousel horse",
			"slug": "carousel_horse",
			"group": "Travel & Places",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"carousel_horse",
				"photo",
				"carnival",
				"activity",
				"entertainment",
				"fairground",
				"go",
				"merry",
				"round"
			]
		},
		"🛝": {
			"name": "playground slide",
			"slug": "playground_slide",
			"group": "Travel & Places",
			"emoji_version": "14.0",
			"unicode_version": "14.0",
			"skin_tone_support": false,
			"aliases": [
				"playground slide",
				"fun",
				"park",
				"amusement",
				"play"
			]
		},
		"🎡": {
			"name": "ferris wheel",
			"slug": "ferris_wheel",
			"group": "Travel & Places",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"ferris_wheel",
				"photo",
				"carnival",
				"londoneye",
				"activity",
				"amusement",
				"big",
				"entertainment",
				"fairground",
				"observation",
				"park"
			]
		},
		"🎢": {
			"name": "roller coaster",
			"slug": "roller_coaster",
			"group": "Travel & Places",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"roller_coaster",
				"carnival",
				"playground",
				"photo",
				"fun",
				"activity",
				"amusement",
				"entertainment",
				"park",
				"rollercoaster",
				"theme"
			]
		},
		"💈": {
			"name": "barber pole",
			"slug": "barber_pole",
			"group": "Travel & Places",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"barber_pole",
				"hair",
				"salon",
				"style",
				"barber's",
				"haircut",
				"hairdresser",
				"shop",
				"stripes"
			]
		},
		"🎪": {
			"name": "circus tent",
			"slug": "circus_tent",
			"group": "Travel & Places",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"circus_tent",
				"festival",
				"carnival",
				"party",
				"activity",
				"big",
				"entertainment",
				"top"
			]
		},
		"🚂": {
			"name": "locomotive",
			"slug": "locomotive",
			"group": "Travel & Places",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"locomotive",
				"transportation",
				"vehicle",
				"train",
				"engine",
				"railway",
				"steam"
			]
		},
		"🚃": {
			"name": "railway car",
			"slug": "railway_car",
			"group": "Travel & Places",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"railway_car",
				"transportation",
				"vehicle",
				"carriage",
				"electric",
				"railcar",
				"railroad",
				"train",
				"tram",
				"trolleybus",
				"wagon"
			]
		},
		"🚄": {
			"name": "high-speed train",
			"slug": "high_speed_train",
			"group": "Travel & Places",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"high_speed_train",
				"transportation",
				"vehicle",
				"bullettrain",
				"railway",
				"shinkansen",
				"side"
			]
		},
		"🚅": {
			"name": "bullet train",
			"slug": "bullet_train",
			"group": "Travel & Places",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"bullet_train",
				"transportation",
				"vehicle",
				"speed",
				"fast",
				"public",
				"travel",
				"bullettrain",
				"front",
				"high",
				"nose",
				"railway",
				"shinkansen"
			]
		},
		"🚆": {
			"name": "train",
			"slug": "train",
			"group": "Travel & Places",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"train",
				"transportation",
				"vehicle",
				"diesel",
				"electric",
				"passenger",
				"railway",
				"regular",
				"train2"
			]
		},
		"🚇": {
			"name": "metro",
			"slug": "metro",
			"group": "Travel & Places",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"metro",
				"transportation",
				"blue-square",
				"mrt",
				"underground",
				"tube",
				"subway",
				"train",
				"vehicle"
			]
		},
		"🚈": {
			"name": "light rail",
			"slug": "light_rail",
			"group": "Travel & Places",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"light_rail",
				"transportation",
				"vehicle",
				"railway"
			]
		},
		"🚉": {
			"name": "station",
			"slug": "station",
			"group": "Travel & Places",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"station",
				"transportation",
				"vehicle",
				"public",
				"platform",
				"railway",
				"train"
			]
		},
		"🚊": {
			"name": "tram",
			"slug": "tram",
			"group": "Travel & Places",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"tram",
				"transportation",
				"vehicle",
				"trolleybus"
			]
		},
		"🚝": {
			"name": "monorail",
			"slug": "monorail",
			"group": "Travel & Places",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"monorail",
				"transportation",
				"vehicle"
			]
		},
		"🚞": {
			"name": "mountain railway",
			"slug": "mountain_railway",
			"group": "Travel & Places",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"mountain_railway",
				"transportation",
				"vehicle",
				"car",
				"funicular",
				"train"
			]
		},
		"🚋": {
			"name": "tram car",
			"slug": "tram_car",
			"group": "Travel & Places",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"tram_car",
				"transportation",
				"vehicle",
				"carriage",
				"public",
				"travel",
				"train",
				"trolleybus"
			]
		},
		"🚌": {
			"name": "bus",
			"slug": "bus",
			"group": "Travel & Places",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"bus",
				"car",
				"vehicle",
				"transportation",
				"school"
			]
		},
		"🚍": {
			"name": "oncoming bus",
			"slug": "oncoming_bus",
			"group": "Travel & Places",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"oncoming_bus",
				"vehicle",
				"transportation",
				"front"
			]
		},
		"🚎": {
			"name": "trolleybus",
			"slug": "trolleybus",
			"group": "Travel & Places",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"trolleybus",
				"bart",
				"transportation",
				"vehicle",
				"bus",
				"electric\xA0bus",
				"tram",
				"trolley"
			]
		},
		"🚐": {
			"name": "minibus",
			"slug": "minibus",
			"group": "Travel & Places",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"minibus",
				"vehicle",
				"car",
				"transportation",
				"bus",
				"minivan",
				"mover",
				"people"
			]
		},
		"🚑": {
			"name": "ambulance",
			"slug": "ambulance",
			"group": "Travel & Places",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"ambulance",
				"health",
				"911",
				"hospital",
				"vehicle"
			]
		},
		"🚒": {
			"name": "fire engine",
			"slug": "fire_engine",
			"group": "Travel & Places",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"fire_engine",
				"transportation",
				"cars",
				"vehicle",
				"department",
				"truck"
			]
		},
		"🚓": {
			"name": "police car",
			"slug": "police_car",
			"group": "Travel & Places",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"police_car",
				"vehicle",
				"cars",
				"transportation",
				"law",
				"legal",
				"enforcement",
				"cop",
				"patrol",
				"side"
			]
		},
		"🚔": {
			"name": "oncoming police car",
			"slug": "oncoming_police_car",
			"group": "Travel & Places",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"oncoming_police_car",
				"vehicle",
				"law",
				"legal",
				"enforcement",
				"911",
				"front\xA0of",
				"🚓\xA0cop"
			]
		},
		"🚕": {
			"name": "taxi",
			"slug": "taxi",
			"group": "Travel & Places",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"taxi",
				"uber",
				"vehicle",
				"cars",
				"transportation",
				"new",
				"side",
				"taxicab",
				"york"
			]
		},
		"🚖": {
			"name": "oncoming taxi",
			"slug": "oncoming_taxi",
			"group": "Travel & Places",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"oncoming_taxi",
				"vehicle",
				"cars",
				"uber",
				"front",
				"taxicab"
			]
		},
		"🚗": {
			"name": "automobile",
			"slug": "automobile",
			"group": "Travel & Places",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"automobile",
				"red",
				"transportation",
				"vehicle",
				"car",
				"side"
			]
		},
		"🚘": {
			"name": "oncoming automobile",
			"slug": "oncoming_automobile",
			"group": "Travel & Places",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"oncoming_automobile",
				"car",
				"vehicle",
				"transportation",
				"front"
			]
		},
		"🚙": {
			"name": "sport utility vehicle",
			"slug": "sport_utility_vehicle",
			"group": "Travel & Places",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"sport_utility_vehicle",
				"transportation",
				"vehicle",
				"blue",
				"campervan",
				"car",
				"motorhome",
				"recreational",
				"rv"
			]
		},
		"🛻": {
			"name": "pickup truck",
			"slug": "pickup_truck",
			"group": "Travel & Places",
			"emoji_version": "13.0",
			"unicode_version": "13.0",
			"skin_tone_support": false,
			"aliases": [
				"pickup truck",
				"car",
				"transportation",
				"vehicle"
			]
		},
		"🚚": {
			"name": "delivery truck",
			"slug": "delivery_truck",
			"group": "Travel & Places",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"delivery_truck",
				"cars",
				"transportation",
				"vehicle",
				"resources"
			]
		},
		"🚛": {
			"name": "articulated lorry",
			"slug": "articulated_lorry",
			"group": "Travel & Places",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"articulated_lorry",
				"vehicle",
				"cars",
				"transportation",
				"express",
				"green",
				"semi",
				"truck"
			]
		},
		"🚜": {
			"name": "tractor",
			"slug": "tractor",
			"group": "Travel & Places",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"tractor",
				"vehicle",
				"car",
				"farming",
				"agriculture",
				"farm"
			]
		},
		"🏎️": {
			"name": "racing car",
			"slug": "racing_car",
			"group": "Travel & Places",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"racing_car",
				"sports",
				"race",
				"fast",
				"formula",
				"f1",
				"one"
			]
		},
		"🏍️": {
			"name": "motorcycle",
			"slug": "motorcycle",
			"group": "Travel & Places",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"motorcycle",
				"race",
				"sports",
				"fast",
				"motorbike",
				"racing"
			]
		},
		"🛵": {
			"name": "motor scooter",
			"slug": "motor_scooter",
			"group": "Travel & Places",
			"emoji_version": "3.0",
			"unicode_version": "3.0",
			"skin_tone_support": false,
			"aliases": [
				"motor_scooter",
				"vehicle",
				"vespa",
				"sasha",
				"bike",
				"cycle"
			]
		},
		"🦽": {
			"name": "manual wheelchair",
			"slug": "manual_wheelchair",
			"group": "Travel & Places",
			"emoji_version": "12.0",
			"unicode_version": "12.0",
			"skin_tone_support": false,
			"aliases": ["manual_wheelchair", "accessibility"]
		},
		"🦼": {
			"name": "motorized wheelchair",
			"slug": "motorized_wheelchair",
			"group": "Travel & Places",
			"emoji_version": "12.0",
			"unicode_version": "12.0",
			"skin_tone_support": false,
			"aliases": ["motorized_wheelchair", "accessibility"]
		},
		"🛺": {
			"name": "auto rickshaw",
			"slug": "auto_rickshaw",
			"group": "Travel & Places",
			"emoji_version": "12.0",
			"unicode_version": "12.0",
			"skin_tone_support": false,
			"aliases": [
				"auto_rickshaw",
				"move",
				"transportation",
				"tuk"
			]
		},
		"🚲": {
			"name": "bicycle",
			"slug": "bicycle",
			"group": "Travel & Places",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"bicycle",
				"bike",
				"sports",
				"exercise",
				"hipster",
				"push",
				"vehicle"
			]
		},
		"🛴": {
			"name": "kick scooter",
			"slug": "kick_scooter",
			"group": "Travel & Places",
			"emoji_version": "3.0",
			"unicode_version": "3.0",
			"skin_tone_support": false,
			"aliases": [
				"kick_scooter",
				"vehicle",
				"kick",
				"razor"
			]
		},
		"🛹": {
			"name": "skateboard",
			"slug": "skateboard",
			"group": "Travel & Places",
			"emoji_version": "11.0",
			"unicode_version": "11.0",
			"skin_tone_support": false,
			"aliases": [
				"skateboard",
				"board",
				"skate"
			]
		},
		"🛼": {
			"name": "roller skate",
			"slug": "roller_skate",
			"group": "Travel & Places",
			"emoji_version": "13.0",
			"unicode_version": "13.0",
			"skin_tone_support": false,
			"aliases": [
				"roller skate",
				"footwear",
				"sports",
				"derby",
				"inline"
			]
		},
		"🚏": {
			"name": "bus stop",
			"slug": "bus_stop",
			"group": "Travel & Places",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"bus_stop",
				"transportation",
				"wait",
				"busstop"
			]
		},
		"🛣️": {
			"name": "motorway",
			"slug": "motorway",
			"group": "Travel & Places",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"motorway",
				"road",
				"cupertino",
				"interstate",
				"highway"
			]
		},
		"🛤️": {
			"name": "railway track",
			"slug": "railway_track",
			"group": "Travel & Places",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"railway_track",
				"train",
				"transportation"
			]
		},
		"🛢️": {
			"name": "oil drum",
			"slug": "oil_drum",
			"group": "Travel & Places",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": ["oil_drum", "barrell"]
		},
		"⛽": {
			"name": "fuel pump",
			"slug": "fuel_pump",
			"group": "Travel & Places",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"fuel_pump",
				"gas station",
				"petroleum",
				"diesel",
				"fuelpump",
				"petrol"
			]
		},
		"🛞": {
			"name": "wheel",
			"slug": "wheel",
			"group": "Travel & Places",
			"emoji_version": "14.0",
			"unicode_version": "14.0",
			"skin_tone_support": false,
			"aliases": [
				"wheel",
				"car",
				"transport",
				"circle",
				"tire",
				"turn"
			]
		},
		"🚨": {
			"name": "police car light",
			"slug": "police_car_light",
			"group": "Travel & Places",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"police_car_light",
				"police",
				"ambulance",
				"911",
				"emergency",
				"alert",
				"error",
				"pinged",
				"law",
				"legal",
				"beacon",
				"cars",
				"car’s",
				"emergency\xA0light",
				"flashing",
				"revolving",
				"rotating",
				"siren",
				"vehicle",
				"warning"
			]
		},
		"🚥": {
			"name": "horizontal traffic light",
			"slug": "horizontal_traffic_light",
			"group": "Travel & Places",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"horizontal_traffic_light",
				"transportation",
				"signal"
			]
		},
		"🚦": {
			"name": "vertical traffic light",
			"slug": "vertical_traffic_light",
			"group": "Travel & Places",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"vertical_traffic_light",
				"transportation",
				"driving",
				"semaphore",
				"signal"
			]
		},
		"🛑": {
			"name": "stop sign",
			"slug": "stop_sign",
			"group": "Travel & Places",
			"emoji_version": "3.0",
			"unicode_version": "3.0",
			"skin_tone_support": false,
			"aliases": [
				"stop_sign",
				"stop",
				"octagonal"
			]
		},
		"🚧": {
			"name": "construction",
			"slug": "construction",
			"group": "Travel & Places",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"construction",
				"wip",
				"progress",
				"caution",
				"warning",
				"barrier",
				"black",
				"roadwork",
				"sign",
				"striped",
				"yellow",
				"work_in_progress"
			]
		},
		"⚓": {
			"name": "anchor",
			"slug": "anchor",
			"group": "Travel & Places",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"anchor",
				"ship",
				"ferry",
				"sea",
				"boat",
				"admiralty",
				"fisherman",
				"pattern",
				"tool"
			]
		},
		"🛟": {
			"name": "ring buoy",
			"slug": "ring_buoy",
			"group": "Travel & Places",
			"emoji_version": "14.0",
			"unicode_version": "14.0",
			"skin_tone_support": false,
			"aliases": [
				"ring buoy",
				"life saver",
				"life preserver",
				"float",
				"rescue",
				"safety"
			]
		},
		"⛵": {
			"name": "sailboat",
			"slug": "sailboat",
			"group": "Travel & Places",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"sailboat",
				"ship",
				"summer",
				"transportation",
				"water",
				"sailing",
				"boat",
				"dinghy",
				"resort",
				"sea",
				"vehicle",
				"yacht"
			]
		},
		"🛶": {
			"name": "canoe",
			"slug": "canoe",
			"group": "Travel & Places",
			"emoji_version": "3.0",
			"unicode_version": "3.0",
			"skin_tone_support": false,
			"aliases": [
				"canoe",
				"boat",
				"paddle",
				"water",
				"ship"
			]
		},
		"🚤": {
			"name": "speedboat",
			"slug": "speedboat",
			"group": "Travel & Places",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"speedboat",
				"ship",
				"transportation",
				"vehicle",
				"summer",
				"boat",
				"motorboat",
				"powerboat"
			]
		},
		"🛳️": {
			"name": "passenger ship",
			"slug": "passenger_ship",
			"group": "Travel & Places",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"passenger_ship",
				"yacht",
				"cruise",
				"ferry",
				"vehicle"
			]
		},
		"⛴️": {
			"name": "ferry",
			"slug": "ferry",
			"group": "Travel & Places",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"ferry",
				"boat",
				"ship",
				"yacht",
				"passenger"
			]
		},
		"🛥️": {
			"name": "motor boat",
			"slug": "motor_boat",
			"group": "Travel & Places",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"motor_boat",
				"ship",
				"motorboat",
				"vehicle"
			]
		},
		"🚢": {
			"name": "ship",
			"slug": "ship",
			"group": "Travel & Places",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"ship",
				"transportation",
				"titanic",
				"deploy",
				"boat",
				"cruise",
				"passenger",
				"vehicle"
			]
		},
		"✈️": {
			"name": "airplane",
			"slug": "airplane",
			"group": "Travel & Places",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"airplane",
				"vehicle",
				"transportation",
				"flight",
				"fly",
				"aeroplane",
				"plane"
			]
		},
		"🛩️": {
			"name": "small airplane",
			"slug": "small_airplane",
			"group": "Travel & Places",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"small_airplane",
				"flight",
				"transportation",
				"fly",
				"vehicle",
				"aeroplane",
				"plane"
			]
		},
		"🛫": {
			"name": "airplane departure",
			"slug": "airplane_departure",
			"group": "Travel & Places",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"airplane_departure",
				"airport",
				"flight",
				"landing",
				"aeroplane",
				"departures",
				"off",
				"plane",
				"taking",
				"vehicle"
			]
		},
		"🛬": {
			"name": "airplane arrival",
			"slug": "airplane_arrival",
			"group": "Travel & Places",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"airplane_arrival",
				"airport",
				"flight",
				"boarding",
				"aeroplane",
				"arrivals",
				"arriving",
				"landing",
				"plane",
				"vehicle"
			]
		},
		"🪂": {
			"name": "parachute",
			"slug": "parachute",
			"group": "Travel & Places",
			"emoji_version": "12.0",
			"unicode_version": "12.0",
			"skin_tone_support": false,
			"aliases": [
				"parachute",
				"fly",
				"glide",
				"hang",
				"parasail",
				"skydive"
			]
		},
		"💺": {
			"name": "seat",
			"slug": "seat",
			"group": "Travel & Places",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"seat",
				"sit",
				"airplane",
				"transport",
				"bus",
				"flight",
				"fly",
				"aeroplane",
				"chair",
				"train"
			]
		},
		"🚁": {
			"name": "helicopter",
			"slug": "helicopter",
			"group": "Travel & Places",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"helicopter",
				"transportation",
				"vehicle",
				"fly"
			]
		},
		"🚟": {
			"name": "suspension railway",
			"slug": "suspension_railway",
			"group": "Travel & Places",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"suspension_railway",
				"vehicle",
				"transportation"
			]
		},
		"🚠": {
			"name": "mountain cableway",
			"slug": "mountain_cableway",
			"group": "Travel & Places",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"mountain_cableway",
				"transportation",
				"vehicle",
				"ski",
				"cable",
				"gondola"
			]
		},
		"🚡": {
			"name": "aerial tramway",
			"slug": "aerial_tramway",
			"group": "Travel & Places",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"aerial_tramway",
				"transportation",
				"vehicle",
				"ski",
				"cable",
				"car",
				"gondola",
				"ropeway"
			]
		},
		"🛰️": {
			"name": "satellite",
			"slug": "satellite",
			"group": "Travel & Places",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"satellite",
				"communication",
				"gps",
				"orbit",
				"spaceflight",
				"NASA",
				"ISS",
				"artificial",
				"space",
				"vehicle"
			]
		},
		"🚀": {
			"name": "rocket",
			"slug": "rocket",
			"group": "Travel & Places",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"rocket",
				"launch",
				"ship",
				"staffmode",
				"NASA",
				"outer space",
				"outer_space",
				"fly",
				"shuttle",
				"vehicle",
				"deploy"
			]
		},
		"🛸": {
			"name": "flying saucer",
			"slug": "flying_saucer",
			"group": "Travel & Places",
			"emoji_version": "5.0",
			"unicode_version": "5.0",
			"skin_tone_support": false,
			"aliases": [
				"flying_saucer",
				"transportation",
				"vehicle",
				"ufo",
				"alien",
				"extraterrestrial",
				"fantasy",
				"space"
			]
		},
		"🛎️": {
			"name": "bellhop bell",
			"slug": "bellhop_bell",
			"group": "Travel & Places",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"bellhop_bell",
				"service",
				"hotel"
			]
		},
		"🧳": {
			"name": "luggage",
			"slug": "luggage",
			"group": "Travel & Places",
			"emoji_version": "11.0",
			"unicode_version": "11.0",
			"skin_tone_support": false,
			"aliases": [
				"luggage",
				"packing",
				"travel",
				"suitcase"
			]
		},
		"⌛": {
			"name": "hourglass done",
			"slug": "hourglass_done",
			"group": "Travel & Places",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"hourglass_done",
				"time",
				"clock",
				"oldschool",
				"limit",
				"exam",
				"quiz",
				"test",
				"sand",
				"timer"
			]
		},
		"⏳": {
			"name": "hourglass not done",
			"slug": "hourglass_not_done",
			"group": "Travel & Places",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"hourglass_not_done",
				"oldschool",
				"time",
				"countdown",
				"flowing",
				"sand",
				"timer"
			]
		},
		"⌚": {
			"name": "watch",
			"slug": "watch",
			"group": "Travel & Places",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"watch",
				"time",
				"accessories",
				"apple",
				"clock",
				"timepiece",
				"wrist",
				"wristwatch"
			]
		},
		"⏰": {
			"name": "alarm clock",
			"slug": "alarm_clock",
			"group": "Travel & Places",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"alarm_clock",
				"time",
				"wake",
				"morning"
			]
		},
		"⏱️": {
			"name": "stopwatch",
			"slug": "stopwatch",
			"group": "Travel & Places",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"stopwatch",
				"time",
				"deadline",
				"clock"
			]
		},
		"⏲️": {
			"name": "timer clock",
			"slug": "timer_clock",
			"group": "Travel & Places",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": ["timer_clock", "alarm"]
		},
		"🕰️": {
			"name": "mantelpiece clock",
			"slug": "mantelpiece_clock",
			"group": "Travel & Places",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": ["mantelpiece_clock", "time"]
		},
		"🕛": {
			"name": "twelve o’clock",
			"slug": "twelve_o_clock",
			"group": "Travel & Places",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"twelve_o_clock",
				"12",
				"00:00",
				"0000",
				"12:00",
				"1200",
				"time",
				"noon",
				"midnight",
				"midday",
				"late",
				"early",
				"schedule",
				"clock12",
				"face",
				"oclock",
				"o’clock"
			]
		},
		"🕧": {
			"name": "twelve-thirty",
			"slug": "twelve_thirty",
			"group": "Travel & Places",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"twelve_thirty",
				"00:30",
				"0030",
				"12:30",
				"1230",
				"time",
				"late",
				"early",
				"schedule",
				"clock",
				"clock1230",
				"face"
			]
		},
		"🕐": {
			"name": "one o’clock",
			"slug": "one_o_clock",
			"group": "Travel & Places",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"one_o_clock",
				"1",
				"1:00",
				"100",
				"13:00",
				"1300",
				"time",
				"late",
				"early",
				"schedule",
				"clock1",
				"face",
				"oclock",
				"o’clock"
			]
		},
		"🕜": {
			"name": "one-thirty",
			"slug": "one_thirty",
			"group": "Travel & Places",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"one_thirty",
				"1:30",
				"130",
				"13:30",
				"1330",
				"time",
				"late",
				"early",
				"schedule",
				"clock",
				"clock130",
				"face"
			]
		},
		"🕑": {
			"name": "two o’clock",
			"slug": "two_o_clock",
			"group": "Travel & Places",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"two_o_clock",
				"2",
				"2:00",
				"200",
				"14:00",
				"1400",
				"time",
				"late",
				"early",
				"schedule",
				"clock2",
				"face",
				"oclock",
				"o’clock"
			]
		},
		"🕝": {
			"name": "two-thirty",
			"slug": "two_thirty",
			"group": "Travel & Places",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"two_thirty",
				"2:30",
				"230",
				"14:30",
				"1430",
				"time",
				"late",
				"early",
				"schedule",
				"clock",
				"clock230",
				"face"
			]
		},
		"🕒": {
			"name": "three o’clock",
			"slug": "three_o_clock",
			"group": "Travel & Places",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"three_o_clock",
				"3",
				"3:00",
				"300",
				"15:00",
				"1500",
				"time",
				"late",
				"early",
				"schedule",
				"clock3",
				"face",
				"oclock",
				"o’clock"
			]
		},
		"🕞": {
			"name": "three-thirty",
			"slug": "three_thirty",
			"group": "Travel & Places",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"three_thirty",
				"3:30",
				"330",
				"15:30",
				"1530",
				"time",
				"late",
				"early",
				"schedule",
				"clock",
				"clock330",
				"face"
			]
		},
		"🕓": {
			"name": "four o’clock",
			"slug": "four_o_clock",
			"group": "Travel & Places",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"four_o_clock",
				"4",
				"4:00",
				"400",
				"16:00",
				"1600",
				"time",
				"late",
				"early",
				"schedule",
				"clock4",
				"face",
				"oclock",
				"o’clock"
			]
		},
		"🕟": {
			"name": "four-thirty",
			"slug": "four_thirty",
			"group": "Travel & Places",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"four_thirty",
				"4:30",
				"430",
				"16:30",
				"1630",
				"time",
				"late",
				"early",
				"schedule",
				"clock",
				"clock430",
				"face"
			]
		},
		"🕔": {
			"name": "five o’clock",
			"slug": "five_o_clock",
			"group": "Travel & Places",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"five_o_clock",
				"5",
				"5:00",
				"500",
				"17:00",
				"1700",
				"time",
				"late",
				"early",
				"schedule",
				"clock5",
				"face",
				"oclock",
				"o’clock"
			]
		},
		"🕠": {
			"name": "five-thirty",
			"slug": "five_thirty",
			"group": "Travel & Places",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"five_thirty",
				"5:30",
				"530",
				"17:30",
				"1730",
				"time",
				"late",
				"early",
				"schedule",
				"clock",
				"clock530",
				"face"
			]
		},
		"🕕": {
			"name": "six o’clock",
			"slug": "six_o_clock",
			"group": "Travel & Places",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"six_o_clock",
				"6",
				"6:00",
				"600",
				"18:00",
				"1800",
				"time",
				"late",
				"early",
				"schedule",
				"dawn",
				"dusk",
				"clock6",
				"face",
				"oclock",
				"o’clock"
			]
		},
		"🕡": {
			"name": "six-thirty",
			"slug": "six_thirty",
			"group": "Travel & Places",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"six_thirty",
				"6:30",
				"630",
				"18:30",
				"1830",
				"time",
				"late",
				"early",
				"schedule",
				"clock",
				"clock630",
				"face"
			]
		},
		"🕖": {
			"name": "seven o’clock",
			"slug": "seven_o_clock",
			"group": "Travel & Places",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"seven_o_clock",
				"7",
				"7:00",
				"700",
				"19:00",
				"1900",
				"time",
				"late",
				"early",
				"schedule",
				"clock7",
				"face",
				"oclock",
				"o’clock"
			]
		},
		"🕢": {
			"name": "seven-thirty",
			"slug": "seven_thirty",
			"group": "Travel & Places",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"seven_thirty",
				"7:30",
				"730",
				"19:30",
				"1930",
				"time",
				"late",
				"early",
				"schedule",
				"clock",
				"clock730",
				"face"
			]
		},
		"🕗": {
			"name": "eight o’clock",
			"slug": "eight_o_clock",
			"group": "Travel & Places",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"eight_o_clock",
				"8",
				"8:00",
				"800",
				"20:00",
				"2000",
				"time",
				"late",
				"early",
				"schedule",
				"clock8",
				"face",
				"oclock",
				"o’clock"
			]
		},
		"🕣": {
			"name": "eight-thirty",
			"slug": "eight_thirty",
			"group": "Travel & Places",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"eight_thirty",
				"8:30",
				"830",
				"20:30",
				"2030",
				"time",
				"late",
				"early",
				"schedule",
				"clock",
				"clock830",
				"face"
			]
		},
		"🕘": {
			"name": "nine o’clock",
			"slug": "nine_o_clock",
			"group": "Travel & Places",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"nine_o_clock",
				"9",
				"9:00",
				"900",
				"21:00",
				"2100",
				"time",
				"late",
				"early",
				"schedule",
				"clock9",
				"face",
				"oclock",
				"o’clock"
			]
		},
		"🕤": {
			"name": "nine-thirty",
			"slug": "nine_thirty",
			"group": "Travel & Places",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"nine_thirty",
				"9:30",
				"930",
				"21:30",
				"2130",
				"time",
				"late",
				"early",
				"schedule",
				"clock",
				"clock930",
				"face"
			]
		},
		"🕙": {
			"name": "ten o’clock",
			"slug": "ten_o_clock",
			"group": "Travel & Places",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"ten_o_clock",
				"10",
				"10:00",
				"1000",
				"22:00",
				"2200",
				"time",
				"late",
				"early",
				"schedule",
				"clock10",
				"face",
				"oclock",
				"o’clock"
			]
		},
		"🕥": {
			"name": "ten-thirty",
			"slug": "ten_thirty",
			"group": "Travel & Places",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"ten_thirty",
				"10:30",
				"1030",
				"22:30",
				"2230",
				"time",
				"late",
				"early",
				"schedule",
				"clock",
				"clock1030",
				"face"
			]
		},
		"🕚": {
			"name": "eleven o’clock",
			"slug": "eleven_o_clock",
			"group": "Travel & Places",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"eleven_o_clock",
				"11",
				"11:00",
				"1100",
				"23:00",
				"2300",
				"time",
				"late",
				"early",
				"schedule",
				"clock11",
				"face",
				"oclock",
				"o’clock"
			]
		},
		"🕦": {
			"name": "eleven-thirty",
			"slug": "eleven_thirty",
			"group": "Travel & Places",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"eleven_thirty",
				"11:30",
				"1130",
				"23:30",
				"2330",
				"time",
				"late",
				"early",
				"schedule",
				"clock",
				"clock1130",
				"face"
			]
		},
		"🌑": {
			"name": "new moon",
			"slug": "new_moon",
			"group": "Travel & Places",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"new_moon",
				"nature",
				"twilight",
				"planet",
				"space",
				"night",
				"evening",
				"sleep",
				"dark",
				"eclipse",
				"shadow\xA0moon",
				"solar",
				"symbol",
				"weather"
			]
		},
		"🌒": {
			"name": "waxing crescent moon",
			"slug": "waxing_crescent_moon",
			"group": "Travel & Places",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"waxing_crescent_moon",
				"nature",
				"twilight",
				"planet",
				"space",
				"night",
				"evening",
				"sleep",
				"symbol",
				"weather"
			]
		},
		"🌓": {
			"name": "first quarter moon",
			"slug": "first_quarter_moon",
			"group": "Travel & Places",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"first_quarter_moon",
				"nature",
				"twilight",
				"planet",
				"space",
				"night",
				"evening",
				"sleep",
				"symbol",
				"weather"
			]
		},
		"🌔": {
			"name": "waxing gibbous moon",
			"slug": "waxing_gibbous_moon",
			"group": "Travel & Places",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"waxing_gibbous_moon",
				"nature",
				"night",
				"sky",
				"gray",
				"twilight",
				"planet",
				"space",
				"evening",
				"sleep",
				"symbol",
				"weather"
			]
		},
		"🌕": {
			"name": "full moon",
			"slug": "full_moon",
			"group": "Travel & Places",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"full_moon",
				"nature",
				"yellow",
				"twilight",
				"planet",
				"space",
				"night",
				"evening",
				"sleep",
				"symbol",
				"weather"
			]
		},
		"🌖": {
			"name": "waning gibbous moon",
			"slug": "waning_gibbous_moon",
			"group": "Travel & Places",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"waning_gibbous_moon",
				"nature",
				"twilight",
				"planet",
				"space",
				"night",
				"evening",
				"sleep",
				"waxing_gibbous_moon",
				"symbol",
				"weather"
			]
		},
		"🌗": {
			"name": "last quarter moon",
			"slug": "last_quarter_moon",
			"group": "Travel & Places",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"last_quarter_moon",
				"nature",
				"twilight",
				"planet",
				"space",
				"night",
				"evening",
				"sleep",
				"symbol",
				"weather"
			]
		},
		"🌘": {
			"name": "waning crescent moon",
			"slug": "waning_crescent_moon",
			"group": "Travel & Places",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"waning_crescent_moon",
				"nature",
				"twilight",
				"planet",
				"space",
				"night",
				"evening",
				"sleep",
				"symbol",
				"weather"
			]
		},
		"🌙": {
			"name": "crescent moon",
			"slug": "crescent_moon",
			"group": "Travel & Places",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"crescent_moon",
				"night",
				"sleep",
				"sky",
				"evening",
				"magic",
				"space",
				"weather"
			]
		},
		"🌚": {
			"name": "new moon face",
			"slug": "new_moon_face",
			"group": "Travel & Places",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"new_moon_face",
				"nature",
				"twilight",
				"planet",
				"space",
				"night",
				"evening",
				"sleep",
				"creepy",
				"dark",
				"molester",
				"weather"
			]
		},
		"🌛": {
			"name": "first quarter moon face",
			"slug": "first_quarter_moon_face",
			"group": "Travel & Places",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"first_quarter_moon_face",
				"nature",
				"twilight",
				"planet",
				"space",
				"night",
				"evening",
				"sleep",
				"weather"
			]
		},
		"🌜": {
			"name": "last quarter moon face",
			"slug": "last_quarter_moon_face",
			"group": "Travel & Places",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"last_quarter_moon_face",
				"nature",
				"twilight",
				"planet",
				"space",
				"night",
				"evening",
				"sleep",
				"weather"
			]
		},
		"🌡️": {
			"name": "thermometer",
			"slug": "thermometer",
			"group": "Travel & Places",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"thermometer",
				"weather",
				"temperature",
				"hot",
				"cold"
			]
		},
		"☀️": {
			"name": "sun",
			"slug": "sun",
			"group": "Travel & Places",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"sun",
				"weather",
				"nature",
				"brightness",
				"summer",
				"beach",
				"spring",
				"black",
				"bright",
				"rays",
				"space",
				"sunny",
				"sunshine"
			]
		},
		"🌝": {
			"name": "full moon face",
			"slug": "full_moon_face",
			"group": "Travel & Places",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"full_moon_face",
				"nature",
				"twilight",
				"planet",
				"space",
				"night",
				"evening",
				"sleep",
				"bright",
				"moonface",
				"smiley",
				"smiling",
				"weather"
			]
		},
		"🌞": {
			"name": "sun with face",
			"slug": "sun_with_face",
			"group": "Travel & Places",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"sun_with_face",
				"nature",
				"morning",
				"sky",
				"bright",
				"smiley",
				"smiling",
				"space",
				"summer",
				"sunface",
				"weather"
			]
		},
		"🪐": {
			"name": "ringed planet",
			"slug": "ringed_planet",
			"group": "Travel & Places",
			"emoji_version": "12.0",
			"unicode_version": "12.0",
			"skin_tone_support": false,
			"aliases": [
				"ringed_planet",
				"outerspace",
				"planets",
				"saturn",
				"saturnine",
				"space"
			]
		},
		"⭐": {
			"name": "star",
			"slug": "star",
			"group": "Travel & Places",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"star",
				"night",
				"yellow",
				"gold",
				"medium",
				"white"
			]
		},
		"🌟": {
			"name": "glowing star",
			"slug": "glowing_star",
			"group": "Travel & Places",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"glowing_star",
				"night",
				"sparkle",
				"awesome",
				"good",
				"magic",
				"glittery",
				"glow",
				"shining",
				"star2"
			]
		},
		"🌠": {
			"name": "shooting star",
			"slug": "shooting_star",
			"group": "Travel & Places",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"shooting_star",
				"night",
				"photo",
				"activity",
				"falling",
				"meteoroid",
				"space",
				"stars",
				"upon",
				"when",
				"wish",
				"you"
			]
		},
		"🌌": {
			"name": "milky way",
			"slug": "milky_way",
			"group": "Travel & Places",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"milky_way",
				"photo",
				"space",
				"stars",
				"galaxy",
				"night",
				"sky",
				"universe",
				"weather"
			]
		},
		"☁️": {
			"name": "cloud",
			"slug": "cloud",
			"group": "Travel & Places",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"cloud",
				"weather",
				"sky",
				"cloudy",
				"overcast"
			]
		},
		"⛅": {
			"name": "sun behind cloud",
			"slug": "sun_behind_cloud",
			"group": "Travel & Places",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"sun_behind_cloud",
				"weather",
				"nature",
				"cloudy",
				"morning",
				"fall",
				"spring",
				"partly",
				"sunny"
			]
		},
		"⛈️": {
			"name": "cloud with lightning and rain",
			"slug": "cloud_with_lightning_and_rain",
			"group": "Travel & Places",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"cloud_with_lightning_and_rain",
				"weather",
				"lightning",
				"thunder"
			]
		},
		"🌤️": {
			"name": "sun behind small cloud",
			"slug": "sun_behind_small_cloud",
			"group": "Travel & Places",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"sun_behind_small_cloud",
				"weather",
				"white"
			]
		},
		"🌥️": {
			"name": "sun behind large cloud",
			"slug": "sun_behind_large_cloud",
			"group": "Travel & Places",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"sun_behind_large_cloud",
				"weather",
				"white"
			]
		},
		"🌦️": {
			"name": "sun behind rain cloud",
			"slug": "sun_behind_rain_cloud",
			"group": "Travel & Places",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"sun_behind_rain_cloud",
				"weather",
				"white"
			]
		},
		"🌧️": {
			"name": "cloud with rain",
			"slug": "cloud_with_rain",
			"group": "Travel & Places",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": ["cloud_with_rain", "weather"]
		},
		"🌨️": {
			"name": "cloud with snow",
			"slug": "cloud_with_snow",
			"group": "Travel & Places",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"cloud_with_snow",
				"weather",
				"cold"
			]
		},
		"🌩️": {
			"name": "cloud with lightning",
			"slug": "cloud_with_lightning",
			"group": "Travel & Places",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"cloud_with_lightning",
				"weather",
				"thunder"
			]
		},
		"🌪️": {
			"name": "tornado",
			"slug": "tornado",
			"group": "Travel & Places",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"tornado",
				"weather",
				"cyclone",
				"twister",
				"cloud",
				"whirlwind"
			]
		},
		"🌫️": {
			"name": "fog",
			"slug": "fog",
			"group": "Travel & Places",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"fog",
				"weather",
				"cloud"
			]
		},
		"🌬️": {
			"name": "wind face",
			"slug": "wind_face",
			"group": "Travel & Places",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"wind_face",
				"gust",
				"air",
				"blow",
				"blowing",
				"cloud",
				"mother",
				"nature",
				"weather"
			]
		},
		"🌀": {
			"name": "cyclone",
			"slug": "cyclone",
			"group": "Travel & Places",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"cyclone",
				"weather",
				"swirl",
				"blue",
				"cloud",
				"vortex",
				"spiral",
				"whirlpool",
				"spin",
				"tornado",
				"hurricane",
				"typhoon",
				"dizzy",
				"twister"
			]
		},
		"🌈": {
			"name": "rainbow",
			"slug": "rainbow",
			"group": "Travel & Places",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"rainbow",
				"nature",
				"happy",
				"unicorn_face",
				"photo",
				"sky",
				"spring",
				"gay",
				"lgbt",
				"pride",
				"primary",
				"rain",
				"weather"
			]
		},
		"🌂": {
			"name": "closed umbrella",
			"slug": "closed_umbrella",
			"group": "Travel & Places",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"closed_umbrella",
				"weather",
				"rain",
				"drizzle",
				"clothing",
				"collapsed\xA0umbrella",
				"pink"
			]
		},
		"☂️": {
			"name": "umbrella",
			"slug": "umbrella",
			"group": "Travel & Places",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"umbrella",
				"weather",
				"spring",
				"clothing",
				"open",
				"rain"
			]
		},
		"☔": {
			"name": "umbrella with rain drops",
			"slug": "umbrella_with_rain_drops",
			"group": "Travel & Places",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"umbrella_with_rain_drops",
				"rainy",
				"weather",
				"spring",
				"clothing",
				"drop",
				"raining"
			]
		},
		"⛱️": {
			"name": "umbrella on ground",
			"slug": "umbrella_on_ground",
			"group": "Travel & Places",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"umbrella_on_ground",
				"weather",
				"summer",
				"beach",
				"parasol",
				"rain",
				"sun"
			]
		},
		"⚡": {
			"name": "high voltage",
			"slug": "high_voltage",
			"group": "Travel & Places",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"high_voltage",
				"thunder",
				"weather",
				"lightning bolt",
				"fast",
				"zap",
				"danger",
				"electric",
				"electricity",
				"sign",
				"thunderbolt",
				"speed"
			]
		},
		"❄️": {
			"name": "snowflake",
			"slug": "snowflake",
			"group": "Travel & Places",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"snowflake",
				"winter",
				"season",
				"cold",
				"weather",
				"christmas",
				"xmas",
				"snow",
				"snowing"
			]
		},
		"☃️": {
			"name": "snowman",
			"slug": "snowman",
			"group": "Travel & Places",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"snowman",
				"winter",
				"season",
				"cold",
				"weather",
				"christmas",
				"xmas",
				"frozen",
				"snow",
				"snowflakes",
				"snowing"
			]
		},
		"⛄": {
			"name": "snowman without snow",
			"slug": "snowman_without_snow",
			"group": "Travel & Places",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"snowman_without_snow",
				"winter",
				"season",
				"cold",
				"weather",
				"christmas",
				"xmas",
				"frozen",
				"without_snow",
				"frosty",
				"olaf"
			]
		},
		"☄️": {
			"name": "comet",
			"slug": "comet",
			"group": "Travel & Places",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": ["comet", "space"]
		},
		"🔥": {
			"name": "fire",
			"slug": "fire",
			"group": "Travel & Places",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"fire",
				"hot",
				"cook",
				"flame",
				"burn",
				"lit",
				"snapstreak",
				"tool",
				"remove"
			]
		},
		"💧": {
			"name": "droplet",
			"slug": "droplet",
			"group": "Travel & Places",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"droplet",
				"water",
				"drip",
				"faucet",
				"spring",
				"cold",
				"comic",
				"drop",
				"sweat",
				"weather"
			]
		},
		"🌊": {
			"name": "water wave",
			"slug": "water_wave",
			"group": "Travel & Places",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"water_wave",
				"sea",
				"water",
				"wave",
				"nature",
				"tsunami",
				"disaster",
				"beach",
				"ocean",
				"waves",
				"weather"
			]
		},
		"🎃": {
			"name": "jack-o-lantern",
			"slug": "jack_o_lantern",
			"group": "Activities",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"jack_o_lantern",
				"halloween",
				"light",
				"pumpkin",
				"creepy",
				"fall",
				"activity",
				"celebration",
				"entertainment",
				"gourd"
			]
		},
		"🎄": {
			"name": "Christmas tree",
			"slug": "christmas_tree",
			"group": "Activities",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"christmas_tree",
				"festival",
				"vacation",
				"december",
				"xmas",
				"celebration",
				"activity",
				"entertainment",
				"xmas\xA0tree"
			]
		},
		"🎆": {
			"name": "fireworks",
			"slug": "fireworks",
			"group": "Activities",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"fireworks",
				"photo",
				"festival",
				"carnival",
				"congratulations",
				"activity",
				"celebration",
				"entertainment",
				"explosion"
			]
		},
		"🎇": {
			"name": "sparkler",
			"slug": "sparkler",
			"group": "Activities",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"sparkler",
				"stars",
				"night",
				"shine",
				"activity",
				"celebration",
				"entertainment",
				"firework",
				"fireworks",
				"hanabi",
				"senko",
				"sparkle"
			]
		},
		"🧨": {
			"name": "firecracker",
			"slug": "firecracker",
			"group": "Activities",
			"emoji_version": "11.0",
			"unicode_version": "11.0",
			"skin_tone_support": false,
			"aliases": [
				"firecracker",
				"dynamite",
				"boom",
				"explode",
				"explosion",
				"explosive",
				"fireworks"
			]
		},
		"✨": {
			"name": "sparkles",
			"slug": "sparkles",
			"group": "Activities",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"sparkles",
				"stars",
				"shine",
				"shiny",
				"cool",
				"awesome",
				"good",
				"magic",
				"entertainment",
				"glitter",
				"sparkle",
				"star"
			]
		},
		"🎈": {
			"name": "balloon",
			"slug": "balloon",
			"group": "Activities",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"balloon",
				"party",
				"celebration",
				"birthday",
				"circus",
				"activity",
				"entertainment",
				"red"
			]
		},
		"🎉": {
			"name": "party popper",
			"slug": "party_popper",
			"group": "Activities",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"party_popper",
				"party",
				"congratulations",
				"birthday",
				"magic",
				"circus",
				"celebration",
				"tada",
				"activity",
				"entertainment",
				"hat",
				"hooray"
			]
		},
		"🎊": {
			"name": "confetti ball",
			"slug": "confetti_ball",
			"group": "Activities",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"confetti_ball",
				"festival",
				"party",
				"birthday",
				"circus",
				"activity",
				"celebration",
				"entertainment"
			]
		},
		"🎋": {
			"name": "tanabata tree",
			"slug": "tanabata_tree",
			"group": "Activities",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"tanabata_tree",
				"plant",
				"nature",
				"branch",
				"summer",
				"bamboo",
				"wish",
				"star_festival",
				"tanzaku",
				"activity",
				"banner",
				"celebration",
				"entertainment",
				"japanese"
			]
		},
		"🎍": {
			"name": "pine decoration",
			"slug": "pine_decoration",
			"group": "Activities",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"pine_decoration",
				"japanese",
				"plant",
				"nature",
				"vegetable",
				"panda",
				"new_years",
				"bamboo",
				"activity",
				"celebration",
				"kadomatsu",
				"year"
			]
		},
		"🎎": {
			"name": "Japanese dolls",
			"slug": "japanese_dolls",
			"group": "Activities",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"japanese_dolls",
				"japanese",
				"toy",
				"kimono",
				"activity",
				"celebration",
				"doll",
				"entertainment",
				"festival",
				"hinamatsuri",
				"imperial"
			]
		},
		"🎏": {
			"name": "carp streamer",
			"slug": "carp_streamer",
			"group": "Activities",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"carp_streamer",
				"fish",
				"japanese",
				"koinobori",
				"carp",
				"banner",
				"activity",
				"celebration",
				"entertainment",
				"flag",
				"flags",
				"socks",
				"wind"
			]
		},
		"🎐": {
			"name": "wind chime",
			"slug": "wind_chime",
			"group": "Activities",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"wind_chime",
				"nature",
				"ding",
				"spring",
				"bell",
				"activity",
				"celebration",
				"entertainment",
				"furin",
				"jellyfish"
			]
		},
		"🎑": {
			"name": "moon viewing ceremony",
			"slug": "moon_viewing_ceremony",
			"group": "Activities",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"moon_viewing_ceremony",
				"photo",
				"japan",
				"asia",
				"tsukimi",
				"activity",
				"autumn",
				"celebration",
				"dumplings",
				"entertainment",
				"festival",
				"grass",
				"harvest",
				"mid",
				"rice",
				"scene"
			]
		},
		"🧧": {
			"name": "red envelope",
			"slug": "red_envelope",
			"group": "Activities",
			"emoji_version": "11.0",
			"unicode_version": "11.0",
			"skin_tone_support": false,
			"aliases": [
				"red_envelope",
				"gift",
				"ang",
				"good",
				"hóngbāo",
				"lai",
				"luck",
				"money",
				"packet",
				"pao",
				"see"
			]
		},
		"🎀": {
			"name": "ribbon",
			"slug": "ribbon",
			"group": "Activities",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"ribbon",
				"decoration",
				"pink",
				"girl",
				"bowtie",
				"bow",
				"celebration"
			]
		},
		"🎁": {
			"name": "wrapped gift",
			"slug": "wrapped_gift",
			"group": "Activities",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"wrapped_gift",
				"present",
				"birthday",
				"christmas",
				"xmas",
				"box",
				"celebration",
				"entertainment"
			]
		},
		"🎗️": {
			"name": "reminder ribbon",
			"slug": "reminder_ribbon",
			"group": "Activities",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"reminder_ribbon",
				"sports",
				"cause",
				"support",
				"awareness",
				"celebration"
			]
		},
		"🎟️": {
			"name": "admission tickets",
			"slug": "admission_tickets",
			"group": "Activities",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"admission_tickets",
				"sports",
				"concert",
				"entrance",
				"entertainment",
				"ticket"
			]
		},
		"🎫": {
			"name": "ticket",
			"slug": "ticket",
			"group": "Activities",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"ticket",
				"event",
				"concert",
				"pass",
				"activity",
				"admission",
				"entertainment",
				"stub",
				"tour",
				"world"
			]
		},
		"🎖️": {
			"name": "military medal",
			"slug": "military_medal",
			"group": "Activities",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"military_medal",
				"award",
				"winning",
				"army",
				"celebration",
				"decoration",
				"medallion"
			]
		},
		"🏆": {
			"name": "trophy",
			"slug": "trophy",
			"group": "Activities",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"trophy",
				"win",
				"award",
				"contest",
				"place",
				"ftw",
				"ceremony",
				"championship",
				"prize",
				"winner",
				"winners"
			]
		},
		"🏅": {
			"name": "sports medal",
			"slug": "sports_medal",
			"group": "Activities",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"sports_medal",
				"award",
				"winning",
				"gold",
				"winner"
			]
		},
		"🥇": {
			"name": "1st place medal",
			"slug": "1st_place_medal",
			"group": "Activities",
			"emoji_version": "3.0",
			"unicode_version": "3.0",
			"skin_tone_support": false,
			"aliases": [
				"1st_place_medal",
				"award",
				"winning",
				"first",
				"gold"
			]
		},
		"🥈": {
			"name": "2nd place medal",
			"slug": "2nd_place_medal",
			"group": "Activities",
			"emoji_version": "3.0",
			"unicode_version": "3.0",
			"skin_tone_support": false,
			"aliases": [
				"2nd_place_medal",
				"award",
				"second",
				"silver"
			]
		},
		"🥉": {
			"name": "3rd place medal",
			"slug": "3rd_place_medal",
			"group": "Activities",
			"emoji_version": "3.0",
			"unicode_version": "3.0",
			"skin_tone_support": false,
			"aliases": [
				"3rd_place_medal",
				"award",
				"third",
				"bronze"
			]
		},
		"⚽": {
			"name": "soccer ball",
			"slug": "soccer_ball",
			"group": "Activities",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"soccer_ball",
				"sports",
				"football"
			]
		},
		"⚾": {
			"name": "baseball",
			"slug": "baseball",
			"group": "Activities",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"baseball",
				"sports",
				"balls",
				"ball",
				"softball"
			]
		},
		"🥎": {
			"name": "softball",
			"slug": "softball",
			"group": "Activities",
			"emoji_version": "11.0",
			"unicode_version": "11.0",
			"skin_tone_support": false,
			"aliases": [
				"softball",
				"sports",
				"balls",
				"ball",
				"game",
				"glove",
				"sport",
				"underarm"
			]
		},
		"🏀": {
			"name": "basketball",
			"slug": "basketball",
			"group": "Activities",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"basketball",
				"sports",
				"balls",
				"NBA",
				"ball",
				"hoop",
				"orange"
			]
		},
		"🏐": {
			"name": "volleyball",
			"slug": "volleyball",
			"group": "Activities",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"volleyball",
				"sports",
				"balls",
				"ball",
				"game"
			]
		},
		"🏈": {
			"name": "american football",
			"slug": "american_football",
			"group": "Activities",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"american_football",
				"sports",
				"balls",
				"NFL",
				"ball",
				"gridiron",
				"superbowl"
			]
		},
		"🏉": {
			"name": "rugby football",
			"slug": "rugby_football",
			"group": "Activities",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"rugby_football",
				"sports",
				"team",
				"ball",
				"league",
				"union"
			]
		},
		"🎾": {
			"name": "tennis",
			"slug": "tennis",
			"group": "Activities",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"tennis",
				"sports",
				"balls",
				"green",
				"ball",
				"racket",
				"racquet"
			]
		},
		"🥏": {
			"name": "flying disc",
			"slug": "flying_disc",
			"group": "Activities",
			"emoji_version": "11.0",
			"unicode_version": "11.0",
			"skin_tone_support": false,
			"aliases": [
				"flying_disc",
				"sports",
				"frisbee",
				"ultimate",
				"game",
				"golf",
				"sport"
			]
		},
		"🎳": {
			"name": "bowling",
			"slug": "bowling",
			"group": "Activities",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"bowling",
				"sports",
				"fun",
				"play",
				"ball",
				"game",
				"pin",
				"pins",
				"skittles",
				"ten"
			]
		},
		"🏏": {
			"name": "cricket game",
			"slug": "cricket_game",
			"group": "Activities",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"cricket_game",
				"sports",
				"ball",
				"bat",
				"field"
			]
		},
		"🏑": {
			"name": "field hockey",
			"slug": "field_hockey",
			"group": "Activities",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"field_hockey",
				"sports",
				"ball",
				"game",
				"stick"
			]
		},
		"🏒": {
			"name": "ice hockey",
			"slug": "ice_hockey",
			"group": "Activities",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"ice_hockey",
				"sports",
				"game",
				"puck",
				"stick"
			]
		},
		"🥍": {
			"name": "lacrosse",
			"slug": "lacrosse",
			"group": "Activities",
			"emoji_version": "11.0",
			"unicode_version": "11.0",
			"skin_tone_support": false,
			"aliases": [
				"lacrosse",
				"sports",
				"ball",
				"stick",
				"game",
				"goal",
				"sport"
			]
		},
		"🏓": {
			"name": "ping pong",
			"slug": "ping_pong",
			"group": "Activities",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"ping_pong",
				"sports",
				"pingpong",
				"ball",
				"bat",
				"game",
				"paddle",
				"table",
				"tennis"
			]
		},
		"🏸": {
			"name": "badminton",
			"slug": "badminton",
			"group": "Activities",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"badminton",
				"sports",
				"birdie",
				"game",
				"racquet",
				"shuttlecock"
			]
		},
		"🥊": {
			"name": "boxing glove",
			"slug": "boxing_glove",
			"group": "Activities",
			"emoji_version": "3.0",
			"unicode_version": "3.0",
			"skin_tone_support": false,
			"aliases": [
				"boxing_glove",
				"sports",
				"fighting"
			]
		},
		"🥋": {
			"name": "martial arts uniform",
			"slug": "martial_arts_uniform",
			"group": "Activities",
			"emoji_version": "3.0",
			"unicode_version": "3.0",
			"skin_tone_support": false,
			"aliases": [
				"martial_arts_uniform",
				"judo",
				"karate",
				"taekwondo"
			]
		},
		"🥅": {
			"name": "goal net",
			"slug": "goal_net",
			"group": "Activities",
			"emoji_version": "3.0",
			"unicode_version": "3.0",
			"skin_tone_support": false,
			"aliases": [
				"goal_net",
				"sports",
				"catch"
			]
		},
		"⛳": {
			"name": "flag in hole",
			"slug": "flag_in_hole",
			"group": "Activities",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"flag_in_hole",
				"sports",
				"business",
				"flag",
				"hole",
				"summer",
				"golf"
			]
		},
		"⛸️": {
			"name": "ice skate",
			"slug": "ice_skate",
			"group": "Activities",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"ice_skate",
				"sports",
				"skating"
			]
		},
		"🎣": {
			"name": "fishing pole",
			"slug": "fishing_pole",
			"group": "Activities",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"fishing_pole",
				"food",
				"hobby",
				"summer",
				"entertainment",
				"fish",
				"rod"
			]
		},
		"🤿": {
			"name": "diving mask",
			"slug": "diving_mask",
			"group": "Activities",
			"emoji_version": "12.0",
			"unicode_version": "12.0",
			"skin_tone_support": false,
			"aliases": [
				"diving_mask",
				"sport",
				"ocean",
				"scuba",
				"snorkeling"
			]
		},
		"🎽": {
			"name": "running shirt",
			"slug": "running_shirt",
			"group": "Activities",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"running_shirt",
				"play",
				"pageant",
				"athletics",
				"marathon",
				"sash",
				"singlet"
			]
		},
		"🎿": {
			"name": "skis",
			"slug": "skis",
			"group": "Activities",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"skis",
				"sports",
				"winter",
				"cold",
				"snow",
				"boot",
				"ski",
				"skiing"
			]
		},
		"🛷": {
			"name": "sled",
			"slug": "sled",
			"group": "Activities",
			"emoji_version": "5.0",
			"unicode_version": "5.0",
			"skin_tone_support": false,
			"aliases": [
				"sled",
				"sleigh",
				"luge",
				"toboggan",
				"sledge"
			]
		},
		"🥌": {
			"name": "curling stone",
			"slug": "curling_stone",
			"group": "Activities",
			"emoji_version": "5.0",
			"unicode_version": "5.0",
			"skin_tone_support": false,
			"aliases": [
				"curling_stone",
				"sports",
				"game",
				"rock"
			]
		},
		"🎯": {
			"name": "bullseye",
			"slug": "bullseye",
			"group": "Activities",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"direct_hit",
				"game",
				"play",
				"bar",
				"target",
				"bullseye",
				"activity",
				"archery",
				"bull",
				"dart",
				"darts",
				"entertainment",
				"eye"
			]
		},
		"🪀": {
			"name": "yo-yo",
			"slug": "yo_yo",
			"group": "Activities",
			"emoji_version": "12.0",
			"unicode_version": "12.0",
			"skin_tone_support": false,
			"aliases": [
				"yo_yo",
				"toy",
				"fluctuate",
				"yoyo"
			]
		},
		"🪁": {
			"name": "kite",
			"slug": "kite",
			"group": "Activities",
			"emoji_version": "12.0",
			"unicode_version": "12.0",
			"skin_tone_support": false,
			"aliases": [
				"kite",
				"wind",
				"fly",
				"soar",
				"toy"
			]
		},
		"🔫": {
			"name": "water pistol",
			"slug": "water_pistol",
			"group": "Activities",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"pistol",
				"violence",
				"weapon",
				"revolver",
				"gun",
				"handgun",
				"shoot",
				"squirt",
				"tool",
				"water"
			]
		},
		"🎱": {
			"name": "pool 8 ball",
			"slug": "pool_8_ball",
			"group": "Activities",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"pool_8_ball",
				"pool",
				"hobby",
				"game",
				"luck",
				"magic",
				"8ball",
				"billiard",
				"billiards",
				"cue",
				"eight",
				"snooker"
			]
		},
		"🔮": {
			"name": "crystal ball",
			"slug": "crystal_ball",
			"group": "Activities",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"crystal_ball",
				"disco",
				"party",
				"magic",
				"circus",
				"fortune_teller",
				"clairvoyant",
				"fairy",
				"fantasy",
				"psychic",
				"purple",
				"tale",
				"tool"
			]
		},
		"🪄": {
			"name": "magic wand",
			"slug": "magic_wand",
			"group": "Activities",
			"emoji_version": "13.0",
			"unicode_version": "13.0",
			"skin_tone_support": false,
			"aliases": [
				"magic wand",
				"supernature",
				"power",
				"witch",
				"wizard"
			]
		},
		"🎮": {
			"name": "video game",
			"slug": "video_game",
			"group": "Activities",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"video_game",
				"play",
				"console",
				"PS4",
				"controller",
				"entertainment",
				"gamepad",
				"playstation",
				"u",
				"wii",
				"xbox"
			]
		},
		"🕹️": {
			"name": "joystick",
			"slug": "joystick",
			"group": "Activities",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"joystick",
				"game",
				"play",
				"entertainment",
				"video"
			]
		},
		"🎰": {
			"name": "slot machine",
			"slug": "slot_machine",
			"group": "Activities",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"slot_machine",
				"bet",
				"gamble",
				"vegas",
				"fruit machine",
				"luck",
				"casino",
				"activity",
				"gambling",
				"game",
				"poker"
			]
		},
		"🎲": {
			"name": "game die",
			"slug": "game_die",
			"group": "Activities",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"game_die",
				"dice",
				"random",
				"tabletop",
				"play",
				"luck",
				"entertainment",
				"gambling"
			]
		},
		"🧩": {
			"name": "puzzle piece",
			"slug": "puzzle_piece",
			"group": "Activities",
			"emoji_version": "11.0",
			"unicode_version": "11.0",
			"skin_tone_support": false,
			"aliases": [
				"puzzle_piece",
				"interlocking",
				"puzzle",
				"piece",
				"clue",
				"jigsaw"
			]
		},
		"🧸": {
			"name": "teddy bear",
			"slug": "teddy_bear",
			"group": "Activities",
			"emoji_version": "11.0",
			"unicode_version": "11.0",
			"skin_tone_support": false,
			"aliases": [
				"teddy_bear",
				"plush",
				"stuffed",
				"plaything",
				"toy"
			]
		},
		"🪅": {
			"name": "piñata",
			"slug": "pinata",
			"group": "Activities",
			"emoji_version": "13.0",
			"unicode_version": "13.0",
			"skin_tone_support": false,
			"aliases": [
				"pinata",
				"mexico",
				"candy",
				"celebration",
				"party",
				"piñata"
			]
		},
		"🪩": {
			"name": "mirror ball",
			"slug": "mirror_ball",
			"group": "Activities",
			"emoji_version": "14.0",
			"unicode_version": "14.0",
			"skin_tone_support": false,
			"aliases": [
				"mirror ball",
				"disco",
				"dance",
				"party",
				"glitter"
			]
		},
		"🪆": {
			"name": "nesting dolls",
			"slug": "nesting_dolls",
			"group": "Activities",
			"emoji_version": "13.0",
			"unicode_version": "13.0",
			"skin_tone_support": false,
			"aliases": [
				"nesting dolls",
				"matryoshka",
				"toy",
				"doll",
				"russia",
				"russian"
			]
		},
		"♠️": {
			"name": "spade suit",
			"slug": "spade_suit",
			"group": "Activities",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"spade_suit",
				"poker",
				"cards",
				"suits",
				"magic",
				"black",
				"card",
				"game",
				"spades"
			]
		},
		"♥️": {
			"name": "heart suit",
			"slug": "heart_suit",
			"group": "Activities",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"heart_suit",
				"poker",
				"cards",
				"magic",
				"suits",
				"black",
				"card",
				"game",
				"hearts"
			]
		},
		"♦️": {
			"name": "diamond suit",
			"slug": "diamond_suit",
			"group": "Activities",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"diamond_suit",
				"poker",
				"cards",
				"magic",
				"suits",
				"black",
				"card",
				"diamonds",
				"game"
			]
		},
		"♣️": {
			"name": "club suit",
			"slug": "club_suit",
			"group": "Activities",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"club_suit",
				"poker",
				"cards",
				"magic",
				"suits",
				"black",
				"card",
				"clubs",
				"game"
			]
		},
		"♟️": {
			"name": "chess pawn",
			"slug": "chess_pawn",
			"group": "Activities",
			"emoji_version": "11.0",
			"unicode_version": "11.0",
			"skin_tone_support": false,
			"aliases": [
				"chess_pawn",
				"expendable",
				"black",
				"dupe",
				"game",
				"piece"
			]
		},
		"🃏": {
			"name": "joker",
			"slug": "joker",
			"group": "Activities",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"joker",
				"poker",
				"cards",
				"game",
				"play",
				"magic",
				"black",
				"card",
				"entertainment",
				"playing",
				"wildcard"
			]
		},
		"🀄": {
			"name": "mahjong red dragon",
			"slug": "mahjong_red_dragon",
			"group": "Activities",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"mahjong_red_dragon",
				"game",
				"play",
				"chinese",
				"kanji",
				"tile"
			]
		},
		"🎴": {
			"name": "flower playing cards",
			"slug": "flower_playing_cards",
			"group": "Activities",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"flower_playing_cards",
				"game",
				"sunset",
				"red",
				"activity",
				"card",
				"deck",
				"entertainment",
				"hanafuda",
				"hwatu",
				"japanese",
				"of\xA0cards"
			]
		},
		"🎭": {
			"name": "performing arts",
			"slug": "performing_arts",
			"group": "Activities",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"performing_arts",
				"acting",
				"theater",
				"drama",
				"activity",
				"art",
				"comedy",
				"entertainment",
				"greek",
				"logo",
				"mask",
				"masks",
				"theatre",
				"theatre\xA0masks",
				"tragedy"
			]
		},
		"🖼️": {
			"name": "framed picture",
			"slug": "framed_picture",
			"group": "Activities",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"framed_picture",
				"photography",
				"art",
				"frame",
				"museum",
				"painting"
			]
		},
		"🎨": {
			"name": "artist palette",
			"slug": "artist_palette",
			"group": "Activities",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"artist_palette",
				"design",
				"paint",
				"draw",
				"colors",
				"activity",
				"art",
				"entertainment",
				"museum",
				"painting",
				"improve"
			]
		},
		"🧵": {
			"name": "thread",
			"slug": "thread",
			"group": "Activities",
			"emoji_version": "11.0",
			"unicode_version": "11.0",
			"skin_tone_support": false,
			"aliases": [
				"thread",
				"needle",
				"sewing",
				"spool",
				"string",
				"crafts"
			]
		},
		"🪡": {
			"name": "sewing needle",
			"slug": "sewing_needle",
			"group": "Activities",
			"emoji_version": "13.0",
			"unicode_version": "13.0",
			"skin_tone_support": false,
			"aliases": [
				"sewing needle",
				"stitches",
				"embroidery",
				"sutures",
				"tailoring"
			]
		},
		"🧶": {
			"name": "yarn",
			"slug": "yarn",
			"group": "Activities",
			"emoji_version": "11.0",
			"unicode_version": "11.0",
			"skin_tone_support": false,
			"aliases": [
				"yarn",
				"ball",
				"crochet",
				"knit",
				"crafts"
			]
		},
		"🪢": {
			"name": "knot",
			"slug": "knot",
			"group": "Activities",
			"emoji_version": "13.0",
			"unicode_version": "13.0",
			"skin_tone_support": false,
			"aliases": [
				"knot",
				"rope",
				"scout",
				"tangled",
				"tie",
				"twine",
				"twist"
			]
		},
		"👓": {
			"name": "glasses",
			"slug": "glasses",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"glasses",
				"fashion",
				"accessories",
				"eyesight",
				"nerdy",
				"dork",
				"geek",
				"clothing",
				"eye",
				"eyeglasses",
				"eyewear"
			]
		},
		"🕶️": {
			"name": "sunglasses",
			"slug": "sunglasses",
			"group": "Objects",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"sunglasses",
				"face",
				"cool",
				"accessories",
				"dark",
				"eye",
				"eyewear",
				"glasses"
			]
		},
		"🥽": {
			"name": "goggles",
			"slug": "goggles",
			"group": "Objects",
			"emoji_version": "11.0",
			"unicode_version": "11.0",
			"skin_tone_support": false,
			"aliases": [
				"goggles",
				"eyes",
				"protection",
				"safety",
				"clothing",
				"eye",
				"swimming",
				"welding"
			]
		},
		"🥼": {
			"name": "lab coat",
			"slug": "lab_coat",
			"group": "Objects",
			"emoji_version": "11.0",
			"unicode_version": "11.0",
			"skin_tone_support": false,
			"aliases": [
				"lab_coat",
				"doctor",
				"experiment",
				"scientist",
				"chemist",
				"clothing"
			]
		},
		"🦺": {
			"name": "safety vest",
			"slug": "safety_vest",
			"group": "Objects",
			"emoji_version": "12.0",
			"unicode_version": "12.0",
			"skin_tone_support": false,
			"aliases": [
				"safety_vest",
				"protection",
				"emergency"
			]
		},
		"👔": {
			"name": "necktie",
			"slug": "necktie",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"necktie",
				"shirt",
				"suitup",
				"formal",
				"fashion",
				"cloth",
				"business",
				"clothing",
				"tie"
			]
		},
		"👕": {
			"name": "t-shirt",
			"slug": "t_shirt",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"t_shirt",
				"fashion",
				"cloth",
				"casual",
				"shirt",
				"tee",
				"clothing",
				"polo",
				"tshirt"
			]
		},
		"👖": {
			"name": "jeans",
			"slug": "jeans",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"jeans",
				"fashion",
				"shopping",
				"clothing",
				"denim",
				"pants",
				"trousers"
			]
		},
		"🧣": {
			"name": "scarf",
			"slug": "scarf",
			"group": "Objects",
			"emoji_version": "5.0",
			"unicode_version": "5.0",
			"skin_tone_support": false,
			"aliases": [
				"scarf",
				"neck",
				"winter",
				"clothes",
				"clothing"
			]
		},
		"🧤": {
			"name": "gloves",
			"slug": "gloves",
			"group": "Objects",
			"emoji_version": "5.0",
			"unicode_version": "5.0",
			"skin_tone_support": false,
			"aliases": [
				"gloves",
				"hands",
				"winter",
				"clothes",
				"clothing",
				"hand"
			]
		},
		"🧥": {
			"name": "coat",
			"slug": "coat",
			"group": "Objects",
			"emoji_version": "5.0",
			"unicode_version": "5.0",
			"skin_tone_support": false,
			"aliases": [
				"coat",
				"jacket",
				"clothing"
			]
		},
		"🧦": {
			"name": "socks",
			"slug": "socks",
			"group": "Objects",
			"emoji_version": "5.0",
			"unicode_version": "5.0",
			"skin_tone_support": false,
			"aliases": [
				"socks",
				"stockings",
				"clothes",
				"clothing",
				"pair",
				"stocking"
			]
		},
		"👗": {
			"name": "dress",
			"slug": "dress",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"dress",
				"clothes",
				"fashion",
				"shopping",
				"clothing",
				"gown",
				"skirt"
			]
		},
		"👘": {
			"name": "kimono",
			"slug": "kimono",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"kimono",
				"dress",
				"fashion",
				"women",
				"female",
				"japanese",
				"clothing",
				"dressing",
				"gown"
			]
		},
		"🥻": {
			"name": "sari",
			"slug": "sari",
			"group": "Objects",
			"emoji_version": "12.0",
			"unicode_version": "12.0",
			"skin_tone_support": false,
			"aliases": [
				"sari",
				"dress",
				"clothing",
				"saree",
				"shari"
			]
		},
		"🩱": {
			"name": "one-piece swimsuit",
			"slug": "one_piece_swimsuit",
			"group": "Objects",
			"emoji_version": "12.0",
			"unicode_version": "12.0",
			"skin_tone_support": false,
			"aliases": [
				"one_piece_swimsuit",
				"fashion",
				"bathing",
				"clothing",
				"suit",
				"swim"
			]
		},
		"🩲": {
			"name": "briefs",
			"slug": "briefs",
			"group": "Objects",
			"emoji_version": "12.0",
			"unicode_version": "12.0",
			"skin_tone_support": false,
			"aliases": [
				"briefs",
				"clothing",
				"bathing",
				"brief",
				"suit",
				"swim",
				"swimsuit",
				"underwear"
			]
		},
		"🩳": {
			"name": "shorts",
			"slug": "shorts",
			"group": "Objects",
			"emoji_version": "12.0",
			"unicode_version": "12.0",
			"skin_tone_support": false,
			"aliases": [
				"shorts",
				"clothing",
				"bathing",
				"pants",
				"suit",
				"swim",
				"swimsuit",
				"underwear"
			]
		},
		"👙": {
			"name": "bikini",
			"slug": "bikini",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"bikini",
				"swimming",
				"female",
				"woman",
				"girl",
				"fashion",
				"beach",
				"summer",
				"bathers",
				"clothing",
				"swim",
				"swimsuit"
			]
		},
		"👚": {
			"name": "woman’s clothes",
			"slug": "woman_s_clothes",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"woman_s_clothes",
				"fashion",
				"shopping_bags",
				"female",
				"blouse",
				"clothing",
				"pink",
				"shirt",
				"womans",
				"woman’s"
			]
		},
		"🪭": {
			"name": "folding hand fan",
			"slug": "folding_hand_fan",
			"group": "Objects",
			"emoji_version": "15.0",
			"unicode_version": "15.0",
			"skin_tone_support": false,
			"aliases": [
				"folding hand fan",
				"flamenco",
				"hot",
				"sensu"
			]
		},
		"👛": {
			"name": "purse",
			"slug": "purse",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"purse",
				"fashion",
				"accessories",
				"money",
				"sales",
				"shopping",
				"clothing",
				"coin",
				"wallet"
			]
		},
		"👜": {
			"name": "handbag",
			"slug": "handbag",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"handbag",
				"fashion",
				"accessory",
				"accessories",
				"shopping",
				"bag",
				"clothing",
				"purse",
				"women’s"
			]
		},
		"👝": {
			"name": "clutch bag",
			"slug": "clutch_bag",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"clutch_bag",
				"bag",
				"accessories",
				"shopping",
				"clothing",
				"pouch",
				"small"
			]
		},
		"🛍️": {
			"name": "shopping bags",
			"slug": "shopping_bags",
			"group": "Objects",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"shopping_bags",
				"mall",
				"buy",
				"purchase",
				"bag",
				"hotel"
			]
		},
		"🎒": {
			"name": "backpack",
			"slug": "backpack",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"backpack",
				"student",
				"education",
				"bag",
				"activity",
				"rucksack",
				"satchel",
				"school"
			]
		},
		"🩴": {
			"name": "thong sandal",
			"slug": "thong_sandal",
			"group": "Objects",
			"emoji_version": "13.0",
			"unicode_version": "13.0",
			"skin_tone_support": false,
			"aliases": [
				"thong sandal",
				"footwear",
				"summer",
				"beach",
				"flip",
				"flops",
				"jandals",
				"sandals",
				"thongs",
				"zōri"
			]
		},
		"👞": {
			"name": "man’s shoe",
			"slug": "man_s_shoe",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"man_s_shoe",
				"fashion",
				"male",
				"brown",
				"clothing",
				"dress",
				"mans",
				"man’s"
			]
		},
		"👟": {
			"name": "running shoe",
			"slug": "running_shoe",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"running_shoe",
				"shoes",
				"sports",
				"sneakers",
				"athletic",
				"clothing",
				"runner",
				"sneaker",
				"sport",
				"tennis",
				"trainer"
			]
		},
		"🥾": {
			"name": "hiking boot",
			"slug": "hiking_boot",
			"group": "Objects",
			"emoji_version": "11.0",
			"unicode_version": "11.0",
			"skin_tone_support": false,
			"aliases": [
				"hiking_boot",
				"backpacking",
				"camping",
				"hiking",
				"clothing"
			]
		},
		"🥿": {
			"name": "flat shoe",
			"slug": "flat_shoe",
			"group": "Objects",
			"emoji_version": "11.0",
			"unicode_version": "11.0",
			"skin_tone_support": false,
			"aliases": [
				"flat_shoe",
				"ballet",
				"slip-on",
				"slipper",
				"clothing",
				"woman’s"
			]
		},
		"👠": {
			"name": "high-heeled shoe",
			"slug": "high_heeled_shoe",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"high_heeled_shoe",
				"fashion",
				"shoes",
				"female",
				"pumps",
				"stiletto",
				"clothing",
				"heel",
				"heels",
				"woman"
			]
		},
		"👡": {
			"name": "woman’s sandal",
			"slug": "woman_s_sandal",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"woman_s_sandal",
				"shoes",
				"fashion",
				"flip flops",
				"clothing",
				"heeled",
				"sandals",
				"shoe",
				"womans",
				"woman’s"
			]
		},
		"🩰": {
			"name": "ballet shoes",
			"slug": "ballet_shoes",
			"group": "Objects",
			"emoji_version": "12.0",
			"unicode_version": "12.0",
			"skin_tone_support": false,
			"aliases": [
				"ballet_shoes",
				"dance",
				"clothing",
				"pointe",
				"shoe"
			]
		},
		"👢": {
			"name": "woman’s boot",
			"slug": "woman_s_boot",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"woman_s_boot",
				"shoes",
				"fashion",
				"boots",
				"clothing",
				"cowgirl",
				"heeled",
				"high",
				"knee",
				"shoe",
				"womans",
				"woman’s"
			]
		},
		"🪮": {
			"name": "hair pick",
			"slug": "hair_pick",
			"group": "Objects",
			"emoji_version": "15.0",
			"unicode_version": "15.0",
			"skin_tone_support": false,
			"aliases": [
				"hair pick",
				"afro",
				"comb"
			]
		},
		"👑": {
			"name": "crown",
			"slug": "crown",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"crown",
				"king",
				"kod",
				"leader",
				"royalty",
				"lord",
				"clothing",
				"queen",
				"royal"
			]
		},
		"👒": {
			"name": "woman’s hat",
			"slug": "woman_s_hat",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"woman_s_hat",
				"fashion",
				"accessories",
				"female",
				"lady",
				"spring",
				"bow",
				"clothing",
				"ladies",
				"womans",
				"woman’s"
			]
		},
		"🎩": {
			"name": "top hat",
			"slug": "top_hat",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"top_hat",
				"magic",
				"gentleman",
				"classy",
				"circus",
				"activity",
				"clothing",
				"entertainment",
				"formal",
				"groom",
				"tophat",
				"wear"
			]
		},
		"🎓": {
			"name": "graduation cap",
			"slug": "graduation_cap",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"graduation_cap",
				"school",
				"college",
				"degree",
				"university",
				"graduation",
				"cap",
				"hat",
				"legal",
				"learn",
				"education",
				"academic",
				"activity",
				"board",
				"celebration",
				"clothing",
				"graduate",
				"mortar",
				"square"
			]
		},
		"🧢": {
			"name": "billed cap",
			"slug": "billed_cap",
			"group": "Objects",
			"emoji_version": "5.0",
			"unicode_version": "5.0",
			"skin_tone_support": false,
			"aliases": [
				"billed_cap",
				"cap",
				"baseball",
				"clothing",
				"hat"
			]
		},
		"🪖": {
			"name": "military helmet",
			"slug": "military_helmet",
			"group": "Objects",
			"emoji_version": "13.0",
			"unicode_version": "13.0",
			"skin_tone_support": false,
			"aliases": [
				"military helmet",
				"army",
				"protection",
				"soldier",
				"warrior"
			]
		},
		"⛑️": {
			"name": "rescue worker’s helmet",
			"slug": "rescue_worker_s_helmet",
			"group": "Objects",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"rescue_worker_s_helmet",
				"construction",
				"build",
				"aid",
				"cross",
				"face",
				"hat",
				"white",
				"worker’s"
			]
		},
		"📿": {
			"name": "prayer beads",
			"slug": "prayer_beads",
			"group": "Objects",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"prayer_beads",
				"dhikr",
				"religious",
				"clothing",
				"necklace",
				"religion",
				"rosary"
			]
		},
		"💄": {
			"name": "lipstick",
			"slug": "lipstick",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"lipstick",
				"female",
				"girl",
				"fashion",
				"woman",
				"cosmetics",
				"gloss",
				"lip",
				"makeup",
				"style"
			]
		},
		"💍": {
			"name": "ring",
			"slug": "ring",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"ring",
				"wedding",
				"propose",
				"marriage",
				"valentines",
				"diamond",
				"fashion",
				"jewelry",
				"gem",
				"engagement",
				"engaged",
				"romance"
			]
		},
		"💎": {
			"name": "gem stone",
			"slug": "gem_stone",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"gem_stone",
				"blue",
				"ruby",
				"diamond",
				"jewelry",
				"gemstone",
				"jewel",
				"romance"
			]
		},
		"🔇": {
			"name": "muted speaker",
			"slug": "muted_speaker",
			"group": "Objects",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"muted_speaker",
				"sound",
				"volume",
				"silence",
				"quiet",
				"cancellation",
				"mute",
				"off",
				"silent",
				"stroke"
			]
		},
		"🔈": {
			"name": "speaker low volume",
			"slug": "speaker_low_volume",
			"group": "Objects",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"speaker_low_volume",
				"sound",
				"volume",
				"silence",
				"broadcast",
				"soft"
			]
		},
		"🔉": {
			"name": "speaker medium volume",
			"slug": "speaker_medium_volume",
			"group": "Objects",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"speaker_medium_volume",
				"volume",
				"speaker",
				"broadcast",
				"low",
				"one",
				"reduce",
				"sound",
				"wave"
			]
		},
		"🔊": {
			"name": "speaker high volume",
			"slug": "speaker_high_volume",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"speaker_high_volume",
				"volume",
				"noise",
				"noisy",
				"speaker",
				"broadcast",
				"entertainment",
				"increase",
				"loud",
				"sound",
				"three",
				"waves"
			]
		},
		"📢": {
			"name": "loudspeaker",
			"slug": "loudspeaker",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"loudspeaker",
				"volume",
				"sound",
				"address",
				"announcement",
				"bullhorn",
				"communication",
				"loud",
				"megaphone",
				"pa",
				"public",
				"system"
			]
		},
		"📣": {
			"name": "megaphone",
			"slug": "megaphone",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"megaphone",
				"sound",
				"speaker",
				"volume",
				"bullhorn",
				"cheering",
				"communication",
				"mega"
			]
		},
		"📯": {
			"name": "postal horn",
			"slug": "postal_horn",
			"group": "Objects",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"postal_horn",
				"instrument",
				"music",
				"bugle",
				"communication",
				"entertainment",
				"french",
				"post"
			]
		},
		"🔔": {
			"name": "bell",
			"slug": "bell",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"bell",
				"sound",
				"notification",
				"christmas",
				"xmas",
				"chime",
				"liberty",
				"ringer",
				"wedding"
			]
		},
		"🔕": {
			"name": "bell with slash",
			"slug": "bell_with_slash",
			"group": "Objects",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"bell_with_slash",
				"sound",
				"volume",
				"mute",
				"quiet",
				"silent",
				"cancellation",
				"disabled",
				"forbidden",
				"muted",
				"no",
				"not",
				"notifications",
				"off",
				"prohibited",
				"ringer",
				"stroke"
			]
		},
		"🎼": {
			"name": "musical score",
			"slug": "musical_score",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"musical_score",
				"treble",
				"clef",
				"compose",
				"activity",
				"entertainment",
				"music",
				"sheet"
			]
		},
		"🎵": {
			"name": "musical note",
			"slug": "musical_note",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"musical_note",
				"score",
				"tone",
				"sound",
				"activity",
				"beamed",
				"eighth",
				"entertainment",
				"music",
				"notes",
				"pair",
				"quavers"
			]
		},
		"🎶": {
			"name": "musical notes",
			"slug": "musical_notes",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"musical_notes",
				"music",
				"score",
				"activity",
				"entertainment",
				"multiple",
				"note",
				"singing"
			]
		},
		"🎙️": {
			"name": "studio microphone",
			"slug": "studio_microphone",
			"group": "Objects",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"studio_microphone",
				"sing",
				"recording",
				"artist",
				"talkshow",
				"mic",
				"music",
				"podcast"
			]
		},
		"🎚️": {
			"name": "level slider",
			"slug": "level_slider",
			"group": "Objects",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"level_slider",
				"scale",
				"music"
			]
		},
		"🎛️": {
			"name": "control knobs",
			"slug": "control_knobs",
			"group": "Objects",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"control_knobs",
				"dial",
				"music"
			]
		},
		"🎤": {
			"name": "microphone",
			"slug": "microphone",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"microphone",
				"sound",
				"music",
				"PA",
				"sing",
				"talkshow",
				"activity",
				"entertainment",
				"karaoke",
				"mic",
				"singing"
			]
		},
		"🎧": {
			"name": "headphone",
			"slug": "headphone",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"headphone",
				"music",
				"score",
				"gadgets",
				"activity",
				"earbud",
				"earphone",
				"earphones",
				"entertainment",
				"headphones",
				"ipod"
			]
		},
		"📻": {
			"name": "radio",
			"slug": "radio",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"radio",
				"communication",
				"music",
				"podcast",
				"program",
				"digital",
				"entertainment",
				"video",
				"wireless"
			]
		},
		"🎷": {
			"name": "saxophone",
			"slug": "saxophone",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"saxophone",
				"music",
				"instrument",
				"jazz",
				"blues",
				"activity",
				"entertainment",
				"sax"
			]
		},
		"🎺": {
			"name": "trumpet",
			"slug": "trumpet",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"trumpet",
				"music",
				"brass",
				"activity",
				"entertainment",
				"horn",
				"instrument",
				"jazz"
			]
		},
		"🪊": {
			"name": "trombone",
			"slug": "trombone",
			"group": "Objects",
			"emoji_version": "17.0",
			"unicode_version": "17.0",
			"skin_tone_support": false,
			"aliases": [
				"trombone",
				"music",
				"instrument"
			]
		},
		"🪗": {
			"name": "accordion",
			"slug": "accordion",
			"group": "Objects",
			"emoji_version": "13.0",
			"unicode_version": "13.0",
			"skin_tone_support": false,
			"aliases": [
				"accordion",
				"music",
				"accordian",
				"box",
				"concertina",
				"squeeze"
			]
		},
		"🎸": {
			"name": "guitar",
			"slug": "guitar",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"guitar",
				"music",
				"instrument",
				"acoustic\xA0guitar",
				"activity",
				"bass",
				"electric",
				"entertainment",
				"rock"
			]
		},
		"🎹": {
			"name": "musical keyboard",
			"slug": "musical_keyboard",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"musical_keyboard",
				"piano",
				"instrument",
				"compose",
				"activity",
				"entertainment",
				"music"
			]
		},
		"🎻": {
			"name": "violin",
			"slug": "violin",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"violin",
				"music",
				"instrument",
				"orchestra",
				"symphony",
				"activity",
				"entertainment",
				"quartet",
				"smallest",
				"string",
				"world’s"
			]
		},
		"🪕": {
			"name": "banjo",
			"slug": "banjo",
			"group": "Objects",
			"emoji_version": "12.0",
			"unicode_version": "12.0",
			"skin_tone_support": false,
			"aliases": [
				"banjo",
				"music",
				"instructment",
				"activity",
				"entertainment",
				"instrument",
				"stringed"
			]
		},
		"🥁": {
			"name": "drum",
			"slug": "drum",
			"group": "Objects",
			"emoji_version": "3.0",
			"unicode_version": "3.0",
			"skin_tone_support": false,
			"aliases": [
				"drum",
				"music",
				"instrument",
				"drumsticks",
				"snare"
			]
		},
		"🪘": {
			"name": "long drum",
			"slug": "long_drum",
			"group": "Objects",
			"emoji_version": "13.0",
			"unicode_version": "13.0",
			"skin_tone_support": false,
			"aliases": [
				"long drum",
				"music",
				"beat",
				"conga",
				"djembe",
				"rhythm"
			]
		},
		"🪇": {
			"name": "maracas",
			"slug": "maracas",
			"group": "Objects",
			"emoji_version": "15.0",
			"unicode_version": "15.0",
			"skin_tone_support": false,
			"aliases": [
				"maracas",
				"music",
				"instrument",
				"percussion",
				"shaker"
			]
		},
		"🪈": {
			"name": "flute",
			"slug": "flute",
			"group": "Objects",
			"emoji_version": "15.0",
			"unicode_version": "15.0",
			"skin_tone_support": false,
			"aliases": [
				"flute",
				"bamboo",
				"music",
				"instrument",
				"pied piper",
				"recorder"
			]
		},
		"🪉": {
			"name": "harp",
			"slug": "harp",
			"group": "Objects",
			"emoji_version": "16.0",
			"unicode_version": "16.0",
			"skin_tone_support": false,
			"aliases": [
				"harp",
				"music",
				"instrument"
			]
		},
		"📱": {
			"name": "mobile phone",
			"slug": "mobile_phone",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"mobile_phone",
				"technology",
				"apple",
				"gadgets",
				"dial",
				"cell",
				"communication",
				"iphone",
				"smartphone",
				"telephone",
				"responsive_design"
			]
		},
		"📲": {
			"name": "mobile phone with arrow",
			"slug": "mobile_phone_with_arrow",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"mobile_phone_with_arrow",
				"iphone",
				"incoming",
				"call",
				"calling",
				"cell",
				"communication",
				"left",
				"pointing",
				"receive",
				"rightwards",
				"telephone"
			]
		},
		"☎️": {
			"name": "telephone",
			"slug": "telephone",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"telephone",
				"technology",
				"communication",
				"dial",
				"black",
				"phone",
				"rotary"
			]
		},
		"📞": {
			"name": "telephone receiver",
			"slug": "telephone_receiver",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"telephone_receiver",
				"technology",
				"communication",
				"dial",
				"call",
				"handset",
				"phone"
			]
		},
		"📟": {
			"name": "pager",
			"slug": "pager",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"pager",
				"bbcall",
				"oldschool",
				"90s",
				"beeper",
				"bleeper",
				"communication"
			]
		},
		"📠": {
			"name": "fax machine",
			"slug": "fax_machine",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"fax_machine",
				"communication",
				"technology",
				"facsimile"
			]
		},
		"🔋": {
			"name": "battery",
			"slug": "battery",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"battery",
				"power",
				"energy",
				"sustain",
				"aa",
				"phone"
			]
		},
		"🪫": {
			"name": "low battery",
			"slug": "low_battery",
			"group": "Objects",
			"emoji_version": "14.0",
			"unicode_version": "14.0",
			"skin_tone_support": false,
			"aliases": [
				"low battery",
				"drained",
				"dead",
				"electronic",
				"energy",
				"no",
				"red"
			]
		},
		"🔌": {
			"name": "electric plug",
			"slug": "electric_plug",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"electric_plug",
				"charger",
				"power",
				"ac",
				"adaptor",
				"cable",
				"electricity"
			]
		},
		"💻": {
			"name": "laptop",
			"slug": "laptop",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"laptop",
				"technology",
				"screen",
				"display",
				"monitor",
				"computer",
				"desktop",
				"notebook",
				"pc",
				"personal"
			]
		},
		"🖥️": {
			"name": "desktop computer",
			"slug": "desktop_computer",
			"group": "Objects",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"desktop_computer",
				"technology",
				"computing",
				"screen",
				"imac"
			]
		},
		"🖨️": {
			"name": "printer",
			"slug": "printer",
			"group": "Objects",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"printer",
				"paper",
				"ink",
				"computer"
			]
		},
		"⌨️": {
			"name": "keyboard",
			"slug": "keyboard",
			"group": "Objects",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"keyboard",
				"technology",
				"computer",
				"type",
				"input",
				"text"
			]
		},
		"🖱️": {
			"name": "computer mouse",
			"slug": "computer_mouse",
			"group": "Objects",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"computer_mouse",
				"click",
				"button",
				"three"
			]
		},
		"🖲️": {
			"name": "trackball",
			"slug": "trackball",
			"group": "Objects",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"trackball",
				"technology",
				"trackpad",
				"computer"
			]
		},
		"💽": {
			"name": "computer disk",
			"slug": "computer_disk",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"computer_disk",
				"technology",
				"record",
				"data",
				"disk",
				"90s",
				"entertainment",
				"minidisc",
				"minidisk",
				"optical"
			]
		},
		"💾": {
			"name": "floppy disk",
			"slug": "floppy_disk",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"floppy_disk",
				"oldschool",
				"technology",
				"save",
				"90s",
				"80s",
				"computer"
			]
		},
		"💿": {
			"name": "optical disk",
			"slug": "optical_disk",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"optical_disk",
				"technology",
				"dvd",
				"disk",
				"disc",
				"90s",
				"cd",
				"compact",
				"computer",
				"rom"
			]
		},
		"📀": {
			"name": "dvd",
			"slug": "dvd",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"dvd",
				"cd",
				"disk",
				"disc",
				"computer",
				"entertainment",
				"optical",
				"rom",
				"video"
			]
		},
		"🧮": {
			"name": "abacus",
			"slug": "abacus",
			"group": "Objects",
			"emoji_version": "11.0",
			"unicode_version": "11.0",
			"skin_tone_support": false,
			"aliases": [
				"abacus",
				"calculation",
				"count",
				"counting",
				"frame",
				"math"
			]
		},
		"🎥": {
			"name": "movie camera",
			"slug": "movie_camera",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"movie_camera",
				"film",
				"record",
				"activity",
				"cinema",
				"entertainment",
				"hollywood",
				"video"
			]
		},
		"🎞️": {
			"name": "film frames",
			"slug": "film_frames",
			"group": "Objects",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"film_frames",
				"movie",
				"cinema",
				"entertainment",
				"strip"
			]
		},
		"📽️": {
			"name": "film projector",
			"slug": "film_projector",
			"group": "Objects",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"film_projector",
				"video",
				"tape",
				"record",
				"movie",
				"cinema",
				"entertainment"
			]
		},
		"🎬": {
			"name": "clapper board",
			"slug": "clapper_board",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"clapper_board",
				"movie",
				"film",
				"record",
				"activity",
				"clapboard",
				"director",
				"entertainment",
				"slate"
			]
		},
		"📺": {
			"name": "television",
			"slug": "television",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"television",
				"technology",
				"program",
				"oldschool",
				"show",
				"entertainment",
				"tv",
				"video"
			]
		},
		"📷": {
			"name": "camera",
			"slug": "camera",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"camera",
				"gadgets",
				"photography",
				"digital",
				"entertainment",
				"photo",
				"video"
			]
		},
		"📸": {
			"name": "camera with flash",
			"slug": "camera_with_flash",
			"group": "Objects",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"camera_with_flash",
				"photography",
				"gadgets",
				"photo",
				"video",
				"snapshots"
			]
		},
		"📹": {
			"name": "video camera",
			"slug": "video_camera",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"video_camera",
				"film",
				"record",
				"camcorder",
				"entertainment"
			]
		},
		"📼": {
			"name": "videocassette",
			"slug": "videocassette",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"videocassette",
				"record",
				"video",
				"oldschool",
				"90s",
				"80s",
				"entertainment",
				"tape",
				"vcr",
				"vhs"
			]
		},
		"🔍": {
			"name": "magnifying glass tilted left",
			"slug": "magnifying_glass_tilted_left",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"magnifying_glass_tilted_left",
				"search",
				"zoom",
				"find",
				"detective",
				"icon",
				"mag",
				"magnifier",
				"pointing",
				"tool"
			]
		},
		"🔎": {
			"name": "magnifying glass tilted right",
			"slug": "magnifying_glass_tilted_right",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"magnifying_glass_tilted_right",
				"search",
				"zoom",
				"find",
				"detective",
				"icon",
				"mag",
				"magnifier",
				"pointing",
				"tool",
				"seo"
			]
		},
		"🕯️": {
			"name": "candle",
			"slug": "candle",
			"group": "Objects",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"candle",
				"fire",
				"wax",
				"light"
			]
		},
		"💡": {
			"name": "light bulb",
			"slug": "light_bulb",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"light_bulb",
				"light",
				"electricity",
				"idea",
				"comic",
				"electric"
			]
		},
		"🔦": {
			"name": "flashlight",
			"slug": "flashlight",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"flashlight",
				"dark",
				"camping",
				"sight",
				"night",
				"electric",
				"light",
				"tool",
				"torch"
			]
		},
		"🏮": {
			"name": "red paper lantern",
			"slug": "red_paper_lantern",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"red_paper_lantern",
				"light",
				"paper",
				"halloween",
				"spooky",
				"asian",
				"bar",
				"izakaya",
				"japanese"
			]
		},
		"🪔": {
			"name": "diya lamp",
			"slug": "diya_lamp",
			"group": "Objects",
			"emoji_version": "12.0",
			"unicode_version": "12.0",
			"skin_tone_support": false,
			"aliases": [
				"diya_lamp",
				"lighting",
				"oil"
			]
		},
		"📔": {
			"name": "notebook with decorative cover",
			"slug": "notebook_with_decorative_cover",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"notebook_with_decorative_cover",
				"classroom",
				"notes",
				"record",
				"paper",
				"study",
				"book",
				"decorated"
			]
		},
		"📕": {
			"name": "closed book",
			"slug": "closed_book",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"closed_book",
				"read",
				"library",
				"knowledge",
				"textbook",
				"learn",
				"red"
			]
		},
		"📖": {
			"name": "open book",
			"slug": "open_book",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"open_book",
				"book",
				"read",
				"library",
				"knowledge",
				"literature",
				"learn",
				"study",
				"novel"
			]
		},
		"📗": {
			"name": "green book",
			"slug": "green_book",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"green_book",
				"read",
				"library",
				"knowledge",
				"study",
				"textbook"
			]
		},
		"📘": {
			"name": "blue book",
			"slug": "blue_book",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"blue_book",
				"read",
				"library",
				"knowledge",
				"learn",
				"study",
				"textbook"
			]
		},
		"📙": {
			"name": "orange book",
			"slug": "orange_book",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"orange_book",
				"read",
				"library",
				"knowledge",
				"textbook",
				"study"
			]
		},
		"📚": {
			"name": "books",
			"slug": "books",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"books",
				"literature",
				"library",
				"study",
				"book",
				"pile",
				"stack"
			]
		},
		"📓": {
			"name": "notebook",
			"slug": "notebook",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"notebook",
				"stationery",
				"record",
				"notes",
				"paper",
				"study",
				"black",
				"book",
				"composition",
				"white"
			]
		},
		"📒": {
			"name": "ledger",
			"slug": "ledger",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"ledger",
				"notes",
				"paper",
				"binder",
				"book",
				"bound",
				"notebook",
				"spiral",
				"yellow"
			]
		},
		"📃": {
			"name": "page with curl",
			"slug": "page_with_curl",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"page_with_curl",
				"documents",
				"office",
				"paper",
				"curled",
				"curly\xA0page",
				"document",
				"license"
			]
		},
		"📜": {
			"name": "scroll",
			"slug": "scroll",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"scroll",
				"documents",
				"ancient",
				"history",
				"paper",
				"degree",
				"document",
				"parchment"
			]
		},
		"📄": {
			"name": "page facing up",
			"slug": "page_facing_up",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"page_facing_up",
				"documents",
				"office",
				"paper",
				"information",
				"document",
				"printed"
			]
		},
		"📰": {
			"name": "newspaper",
			"slug": "newspaper",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"newspaper",
				"press",
				"headline",
				"communication",
				"news",
				"paper"
			]
		},
		"🗞️": {
			"name": "rolled-up newspaper",
			"slug": "rolled_up_newspaper",
			"group": "Objects",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"rolled_up_newspaper",
				"press",
				"headline",
				"delivery",
				"news",
				"paper",
				"roll"
			]
		},
		"📑": {
			"name": "bookmark tabs",
			"slug": "bookmark_tabs",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"bookmark_tabs",
				"favorite",
				"save",
				"order",
				"tidy",
				"mark",
				"marker"
			]
		},
		"🔖": {
			"name": "bookmark",
			"slug": "bookmark",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"bookmark",
				"favorite",
				"label",
				"save",
				"mark",
				"price",
				"tag"
			]
		},
		"🏷️": {
			"name": "label",
			"slug": "label",
			"group": "Objects",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"label",
				"sale",
				"tag"
			]
		},
		"🪙": {
			"name": "coin",
			"slug": "coin",
			"group": "Objects",
			"emoji_version": "13.0",
			"unicode_version": "13.0",
			"skin_tone_support": false,
			"aliases": [
				"coin",
				"money",
				"currency",
				"gold",
				"metal",
				"silver",
				"treasure"
			]
		},
		"💰": {
			"name": "money bag",
			"slug": "money_bag",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"money_bag",
				"dollar",
				"payment",
				"coins",
				"sale",
				"cream",
				"moneybag",
				"moneybags",
				"rich"
			]
		},
		"🪎": {
			"name": "treasure chest",
			"slug": "treasure_chest",
			"group": "Objects",
			"emoji_version": "17.0",
			"unicode_version": "17.0",
			"skin_tone_support": false,
			"aliases": [
				"treasure chest",
				"gold",
				"haul",
				"mimic",
				"crate",
				"jewelry",
				"riches"
			]
		},
		"💴": {
			"name": "yen banknote",
			"slug": "yen_banknote",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"yen_banknote",
				"money",
				"sales",
				"japanese",
				"dollar",
				"currency",
				"bank",
				"banknotes",
				"bill",
				"note",
				"sign"
			]
		},
		"💵": {
			"name": "dollar banknote",
			"slug": "dollar_banknote",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"dollar_banknote",
				"money",
				"sales",
				"bill",
				"currency",
				"american",
				"bank",
				"banknotes",
				"note",
				"sign"
			]
		},
		"💶": {
			"name": "euro banknote",
			"slug": "euro_banknote",
			"group": "Objects",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"euro_banknote",
				"money",
				"sales",
				"dollar",
				"currency",
				"bank",
				"banknotes",
				"bill",
				"note",
				"sign"
			]
		},
		"💷": {
			"name": "pound banknote",
			"slug": "pound_banknote",
			"group": "Objects",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"pound_banknote",
				"british",
				"sterling",
				"money",
				"sales",
				"bills",
				"uk",
				"england",
				"currency",
				"bank",
				"banknotes",
				"bill",
				"note",
				"quid",
				"sign",
				"twenty"
			]
		},
		"💸": {
			"name": "money with wings",
			"slug": "money_with_wings",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"money_with_wings",
				"dollar",
				"bills",
				"payment",
				"sale",
				"bank",
				"banknote",
				"bill",
				"fly",
				"flying",
				"losing",
				"note"
			]
		},
		"💳": {
			"name": "credit card",
			"slug": "credit_card",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"credit_card",
				"money",
				"sales",
				"dollar",
				"bill",
				"payment",
				"shopping",
				"amex",
				"bank",
				"club",
				"diners",
				"mastercard",
				"subscription",
				"visa"
			]
		},
		"🧾": {
			"name": "receipt",
			"slug": "receipt",
			"group": "Objects",
			"emoji_version": "11.0",
			"unicode_version": "11.0",
			"skin_tone_support": false,
			"aliases": [
				"receipt",
				"accounting",
				"expenses",
				"bookkeeping",
				"evidence",
				"proof"
			]
		},
		"💹": {
			"name": "chart increasing with yen",
			"slug": "chart_increasing_with_yen",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"chart_increasing_with_yen",
				"green-square",
				"graph",
				"presentation",
				"stats",
				"bank",
				"currency",
				"exchange",
				"growth",
				"market",
				"money",
				"rate",
				"rise",
				"sign",
				"trend",
				"upward",
				"upwards"
			]
		},
		"✉️": {
			"name": "envelope",
			"slug": "envelope",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"envelope",
				"letter",
				"postal",
				"inbox",
				"communication",
				"email",
				"✉\xA0letter"
			]
		},
		"📧": {
			"name": "e-mail",
			"slug": "e_mail",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"e_mail",
				"communication",
				"inbox",
				"email",
				"letter",
				"symbol"
			]
		},
		"📨": {
			"name": "incoming envelope",
			"slug": "incoming_envelope",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"incoming_envelope",
				"email",
				"inbox",
				"communication",
				"fast",
				"letter",
				"lines",
				"mail",
				"receive"
			]
		},
		"📩": {
			"name": "envelope with arrow",
			"slug": "envelope_with_arrow",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"envelope_with_arrow",
				"email",
				"communication",
				"above",
				"down",
				"downwards",
				"insert",
				"letter",
				"mail",
				"outgoing",
				"sent"
			]
		},
		"📤": {
			"name": "outbox tray",
			"slug": "outbox_tray",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"outbox_tray",
				"inbox",
				"email",
				"box",
				"communication",
				"letter",
				"mail",
				"sent"
			]
		},
		"📥": {
			"name": "inbox tray",
			"slug": "inbox_tray",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"inbox_tray",
				"email",
				"documents",
				"box",
				"communication",
				"letter",
				"mail",
				"receive"
			]
		},
		"📦": {
			"name": "package",
			"slug": "package",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"package",
				"mail",
				"gift",
				"cardboard",
				"box",
				"moving",
				"communication",
				"parcel",
				"shipping",
				"container"
			]
		},
		"📫": {
			"name": "closed mailbox with raised flag",
			"slug": "closed_mailbox_with_raised_flag",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"closed_mailbox_with_raised_flag",
				"email",
				"inbox",
				"communication",
				"mail",
				"postbox"
			]
		},
		"📪": {
			"name": "closed mailbox with lowered flag",
			"slug": "closed_mailbox_with_lowered_flag",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"closed_mailbox_with_lowered_flag",
				"email",
				"communication",
				"inbox",
				"mail",
				"postbox"
			]
		},
		"📬": {
			"name": "open mailbox with raised flag",
			"slug": "open_mailbox_with_raised_flag",
			"group": "Objects",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"open_mailbox_with_raised_flag",
				"email",
				"inbox",
				"communication",
				"mail",
				"postbox"
			]
		},
		"📭": {
			"name": "open mailbox with lowered flag",
			"slug": "open_mailbox_with_lowered_flag",
			"group": "Objects",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"open_mailbox_with_lowered_flag",
				"email",
				"inbox",
				"communication",
				"mail",
				"no",
				"postbox"
			]
		},
		"📮": {
			"name": "postbox",
			"slug": "postbox",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"postbox",
				"email",
				"letter",
				"envelope",
				"communication",
				"mail",
				"mailbox"
			]
		},
		"🗳️": {
			"name": "ballot box with ballot",
			"slug": "ballot_box_with_ballot",
			"group": "Objects",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"ballot_box_with_ballot",
				"election",
				"vote",
				"voting"
			]
		},
		"✏️": {
			"name": "pencil",
			"slug": "pencil",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"pencil",
				"stationery",
				"write",
				"paper",
				"writing",
				"school",
				"study",
				"lead",
				"pencil2",
				"typos"
			]
		},
		"✒️": {
			"name": "black nib",
			"slug": "black_nib",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"black_nib",
				"pen",
				"stationery",
				"writing",
				"write",
				"fountain",
				"✒\xA0fountain"
			]
		},
		"🖋️": {
			"name": "fountain pen",
			"slug": "fountain_pen",
			"group": "Objects",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"fountain_pen",
				"stationery",
				"writing",
				"write",
				"communication",
				"left",
				"lower"
			]
		},
		"🖊️": {
			"name": "pen",
			"slug": "pen",
			"group": "Objects",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"pen",
				"stationery",
				"writing",
				"write",
				"ballpoint",
				"communication",
				"left",
				"lower"
			]
		},
		"🖌️": {
			"name": "paintbrush",
			"slug": "paintbrush",
			"group": "Objects",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"paintbrush",
				"drawing",
				"creativity",
				"art",
				"brush",
				"communication",
				"left",
				"lower",
				"painting"
			]
		},
		"🖍️": {
			"name": "crayon",
			"slug": "crayon",
			"group": "Objects",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"crayon",
				"drawing",
				"creativity",
				"communication",
				"left",
				"lower"
			]
		},
		"📝": {
			"name": "memo",
			"slug": "memo",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"memo",
				"write",
				"documents",
				"stationery",
				"pencil",
				"paper",
				"writing",
				"legal",
				"exam",
				"quiz",
				"test",
				"study",
				"compose",
				"communication",
				"document",
				"memorandum",
				"note",
				"documentation"
			]
		},
		"💼": {
			"name": "briefcase",
			"slug": "briefcase",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"briefcase",
				"business",
				"documents",
				"work",
				"law",
				"legal",
				"job",
				"career",
				"suitcase"
			]
		},
		"📁": {
			"name": "file folder",
			"slug": "file_folder",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"file_folder",
				"documents",
				"business",
				"office",
				"closed",
				"directory",
				"manilla"
			]
		},
		"📂": {
			"name": "open file folder",
			"slug": "open_file_folder",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"open_file_folder",
				"documents",
				"load"
			]
		},
		"🗂️": {
			"name": "card index dividers",
			"slug": "card_index_dividers",
			"group": "Objects",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"card_index_dividers",
				"organizing",
				"business",
				"stationery"
			]
		},
		"📅": {
			"name": "calendar",
			"slug": "calendar",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"calendar",
				"schedule",
				"date",
				"day",
				"emoji",
				"july",
				"world"
			]
		},
		"📆": {
			"name": "tear-off calendar",
			"slug": "tear_off_calendar",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"tear_off_calendar",
				"schedule",
				"date",
				"planning",
				"day",
				"desk"
			]
		},
		"🗒️": {
			"name": "spiral notepad",
			"slug": "spiral_notepad",
			"group": "Objects",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"spiral_notepad",
				"memo",
				"stationery",
				"note",
				"pad"
			]
		},
		"🗓️": {
			"name": "spiral calendar",
			"slug": "spiral_calendar",
			"group": "Objects",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"spiral_calendar",
				"date",
				"schedule",
				"planning",
				"pad"
			]
		},
		"📇": {
			"name": "card index",
			"slug": "card_index",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"card_index",
				"business",
				"stationery",
				"rolodex",
				"system"
			]
		},
		"📈": {
			"name": "chart increasing",
			"slug": "chart_increasing",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"chart_increasing",
				"graph",
				"presentation",
				"stats",
				"recovery",
				"business",
				"economics",
				"money",
				"sales",
				"good",
				"success",
				"growth",
				"metrics",
				"pointing",
				"positive\xA0chart",
				"trend",
				"up",
				"upward",
				"upwards",
				"analytics"
			]
		},
		"📉": {
			"name": "chart decreasing",
			"slug": "chart_decreasing",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"chart_decreasing",
				"graph",
				"presentation",
				"stats",
				"recession",
				"business",
				"economics",
				"money",
				"sales",
				"bad",
				"failure",
				"down",
				"downwards",
				"down\xA0pointing",
				"metrics",
				"negative\xA0chart",
				"trend"
			]
		},
		"📊": {
			"name": "bar chart",
			"slug": "bar_chart",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"bar_chart",
				"graph",
				"presentation",
				"stats",
				"metrics"
			]
		},
		"📋": {
			"name": "clipboard",
			"slug": "clipboard",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"clipboard",
				"stationery",
				"documents"
			]
		},
		"📌": {
			"name": "pushpin",
			"slug": "pushpin",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"pushpin",
				"stationery",
				"mark",
				"here",
				"location",
				"pin",
				"tack",
				"thumb"
			]
		},
		"📍": {
			"name": "round pushpin",
			"slug": "round_pushpin",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"round_pushpin",
				"stationery",
				"location",
				"map",
				"here",
				"dropped",
				"pin",
				"red"
			]
		},
		"📎": {
			"name": "paperclip",
			"slug": "paperclip",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"paperclip",
				"documents",
				"stationery",
				"clippy"
			]
		},
		"🖇️": {
			"name": "linked paperclips",
			"slug": "linked_paperclips",
			"group": "Objects",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"linked_paperclips",
				"documents",
				"stationery",
				"communication",
				"link",
				"paperclip"
			]
		},
		"📏": {
			"name": "straight ruler",
			"slug": "straight_ruler",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"straight_ruler",
				"stationery",
				"calculate",
				"length",
				"math",
				"school",
				"drawing",
				"architect",
				"sketch",
				"edge"
			]
		},
		"📐": {
			"name": "triangular ruler",
			"slug": "triangular_ruler",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"triangular_ruler",
				"stationery",
				"math",
				"architect",
				"sketch",
				"set",
				"triangle"
			]
		},
		"✂️": {
			"name": "scissors",
			"slug": "scissors",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"scissors",
				"stationery",
				"cut",
				"black",
				"cutting",
				"tool"
			]
		},
		"🗃️": {
			"name": "card file box",
			"slug": "card_file_box",
			"group": "Objects",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"card_file_box",
				"business",
				"stationery",
				"database"
			]
		},
		"🗄️": {
			"name": "file cabinet",
			"slug": "file_cabinet",
			"group": "Objects",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"file_cabinet",
				"filing",
				"organizing"
			]
		},
		"🗑️": {
			"name": "wastebasket",
			"slug": "wastebasket",
			"group": "Objects",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"wastebasket",
				"bin",
				"trash",
				"rubbish",
				"garbage",
				"toss",
				"basket",
				"can",
				"litter",
				"wastepaper"
			]
		},
		"🔒": {
			"name": "locked",
			"slug": "locked",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"locked",
				"security",
				"password",
				"padlock",
				"closed",
				"lock",
				"private",
				"privacy"
			]
		},
		"🔓": {
			"name": "unlocked",
			"slug": "unlocked",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"unlocked",
				"privacy",
				"security",
				"lock",
				"open",
				"padlock",
				"unlock"
			]
		},
		"🔏": {
			"name": "locked with pen",
			"slug": "locked_with_pen",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"locked_with_pen",
				"security",
				"secret",
				"fountain",
				"ink",
				"lock",
				"lock\xA0with",
				"nib",
				"privacy"
			]
		},
		"🔐": {
			"name": "locked with key",
			"slug": "locked_with_key",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"locked_with_key",
				"security",
				"privacy",
				"closed",
				"lock",
				"secure",
				"secret"
			]
		},
		"🔑": {
			"name": "key",
			"slug": "key",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"key",
				"lock",
				"door",
				"password",
				"gold"
			]
		},
		"🗝️": {
			"name": "old key",
			"slug": "old_key",
			"group": "Objects",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"old_key",
				"lock",
				"door",
				"password",
				"clue"
			]
		},
		"🔨": {
			"name": "hammer",
			"slug": "hammer",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"hammer",
				"tools",
				"build",
				"create",
				"claw",
				"handyman",
				"tool"
			]
		},
		"🪓": {
			"name": "axe",
			"slug": "axe",
			"group": "Objects",
			"emoji_version": "12.0",
			"unicode_version": "12.0",
			"skin_tone_support": false,
			"aliases": [
				"axe",
				"tool",
				"chop",
				"cut",
				"hatchet",
				"split",
				"wood"
			]
		},
		"⛏️": {
			"name": "pick",
			"slug": "pick",
			"group": "Objects",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"pick",
				"tools",
				"dig",
				"mining",
				"pickaxe",
				"tool"
			]
		},
		"⚒️": {
			"name": "hammer and pick",
			"slug": "hammer_and_pick",
			"group": "Objects",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"hammer_and_pick",
				"tools",
				"build",
				"create",
				"tool"
			]
		},
		"🛠️": {
			"name": "hammer and wrench",
			"slug": "hammer_and_wrench",
			"group": "Objects",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"hammer_and_wrench",
				"tools",
				"build",
				"create",
				"spanner",
				"tool"
			]
		},
		"🗡️": {
			"name": "dagger",
			"slug": "dagger",
			"group": "Objects",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"dagger",
				"weapon",
				"knife"
			]
		},
		"⚔️": {
			"name": "crossed swords",
			"slug": "crossed_swords",
			"group": "Objects",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": ["crossed_swords", "weapon"]
		},
		"💣": {
			"name": "bomb",
			"slug": "bomb",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"bomb",
				"boom",
				"explode",
				"explosion",
				"terrorism",
				"comic"
			]
		},
		"🪃": {
			"name": "boomerang",
			"slug": "boomerang",
			"group": "Objects",
			"emoji_version": "13.0",
			"unicode_version": "13.0",
			"skin_tone_support": false,
			"aliases": [
				"boomerang",
				"weapon",
				"australia",
				"rebound",
				"repercussion"
			]
		},
		"🏹": {
			"name": "bow and arrow",
			"slug": "bow_and_arrow",
			"group": "Objects",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"bow_and_arrow",
				"sports",
				"archer",
				"archery",
				"sagittarius",
				"tool",
				"zodiac"
			]
		},
		"🛡️": {
			"name": "shield",
			"slug": "shield",
			"group": "Objects",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"shield",
				"protection",
				"security",
				"weapon"
			]
		},
		"🪚": {
			"name": "carpentry saw",
			"slug": "carpentry_saw",
			"group": "Objects",
			"emoji_version": "13.0",
			"unicode_version": "13.0",
			"skin_tone_support": false,
			"aliases": [
				"carpentry saw",
				"cut",
				"chop",
				"carpenter",
				"hand",
				"lumber",
				"tool"
			]
		},
		"🔧": {
			"name": "wrench",
			"slug": "wrench",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"wrench",
				"tools",
				"diy",
				"ikea",
				"fix",
				"maintainer",
				"spanner",
				"tool"
			]
		},
		"🪛": {
			"name": "screwdriver",
			"slug": "screwdriver",
			"group": "Objects",
			"emoji_version": "13.0",
			"unicode_version": "13.0",
			"skin_tone_support": false,
			"aliases": [
				"screwdriver",
				"tools",
				"screw",
				"tool"
			]
		},
		"🔩": {
			"name": "nut and bolt",
			"slug": "nut_and_bolt",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"nut_and_bolt",
				"handy",
				"tools",
				"fix",
				"screw",
				"tool"
			]
		},
		"⚙️": {
			"name": "gear",
			"slug": "gear",
			"group": "Objects",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"gear",
				"cog",
				"cogwheel",
				"tool"
			]
		},
		"🗜️": {
			"name": "clamp",
			"slug": "clamp",
			"group": "Objects",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"clamp",
				"tool",
				"compress",
				"compression",
				"table",
				"vice",
				"winzip"
			]
		},
		"⚖️": {
			"name": "balance scale",
			"slug": "balance_scale",
			"group": "Objects",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"balance_scale",
				"law",
				"fairness",
				"weight",
				"justice",
				"libra",
				"scales",
				"tool",
				"zodiac"
			]
		},
		"🦯": {
			"name": "white cane",
			"slug": "white_cane",
			"group": "Objects",
			"emoji_version": "12.0",
			"unicode_version": "12.0",
			"skin_tone_support": false,
			"aliases": [
				"probing_cane",
				"accessibility",
				"blind",
				"white"
			]
		},
		"🔗": {
			"name": "link",
			"slug": "link",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"link",
				"rings",
				"url",
				"chain",
				"hyperlink",
				"linked",
				"symbol"
			]
		},
		"⛓️‍💥": {
			"name": "broken chain",
			"slug": "broken_chain",
			"group": "Objects",
			"emoji_version": "15.1",
			"unicode_version": "15.1",
			"skin_tone_support": false,
			"aliases": [
				"broken chain",
				"constraint",
				"break"
			]
		},
		"⛓️": {
			"name": "chains",
			"slug": "chains",
			"group": "Objects",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"chains",
				"lock",
				"arrest",
				"chain"
			]
		},
		"🪝": {
			"name": "hook",
			"slug": "hook",
			"group": "Objects",
			"emoji_version": "13.0",
			"unicode_version": "13.0",
			"skin_tone_support": false,
			"aliases": [
				"hook",
				"tools",
				"catch",
				"crook",
				"curve",
				"ensnare",
				"fishing",
				"point",
				"selling",
				"tool"
			]
		},
		"🧰": {
			"name": "toolbox",
			"slug": "toolbox",
			"group": "Objects",
			"emoji_version": "11.0",
			"unicode_version": "11.0",
			"skin_tone_support": false,
			"aliases": [
				"toolbox",
				"tools",
				"diy",
				"fix",
				"maintainer",
				"mechanic",
				"chest",
				"tool"
			]
		},
		"🧲": {
			"name": "magnet",
			"slug": "magnet",
			"group": "Objects",
			"emoji_version": "11.0",
			"unicode_version": "11.0",
			"skin_tone_support": false,
			"aliases": [
				"magnet",
				"attraction",
				"magnetic",
				"horseshoe"
			]
		},
		"🪜": {
			"name": "ladder",
			"slug": "ladder",
			"group": "Objects",
			"emoji_version": "13.0",
			"unicode_version": "13.0",
			"skin_tone_support": false,
			"aliases": [
				"ladder",
				"tools",
				"climb",
				"rung",
				"step",
				"tool"
			]
		},
		"🪏": {
			"name": "shovel",
			"slug": "shovel",
			"group": "Objects",
			"emoji_version": "16.0",
			"unicode_version": "16.0",
			"skin_tone_support": false,
			"aliases": [
				"shovel",
				"tool",
				"dig"
			]
		},
		"⚗️": {
			"name": "alembic",
			"slug": "alembic",
			"group": "Objects",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"alembic",
				"distilling",
				"science",
				"experiment",
				"chemistry",
				"tool"
			]
		},
		"🧪": {
			"name": "test tube",
			"slug": "test_tube",
			"group": "Objects",
			"emoji_version": "11.0",
			"unicode_version": "11.0",
			"skin_tone_support": false,
			"aliases": [
				"test_tube",
				"chemistry",
				"experiment",
				"lab",
				"science",
				"chemist",
				"test"
			]
		},
		"🧫": {
			"name": "petri dish",
			"slug": "petri_dish",
			"group": "Objects",
			"emoji_version": "11.0",
			"unicode_version": "11.0",
			"skin_tone_support": false,
			"aliases": [
				"petri_dish",
				"bacteria",
				"biology",
				"culture",
				"lab",
				"biologist"
			]
		},
		"🧬": {
			"name": "dna",
			"slug": "dna",
			"group": "Objects",
			"emoji_version": "11.0",
			"unicode_version": "11.0",
			"skin_tone_support": false,
			"aliases": [
				"dna",
				"biologist",
				"genetics",
				"life",
				"double",
				"evolution",
				"gene",
				"helix"
			]
		},
		"🔬": {
			"name": "microscope",
			"slug": "microscope",
			"group": "Objects",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"microscope",
				"laboratory",
				"experiment",
				"zoomin",
				"science",
				"study",
				"investigate",
				"magnify",
				"tool"
			]
		},
		"🔭": {
			"name": "telescope",
			"slug": "telescope",
			"group": "Objects",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"telescope",
				"stars",
				"space",
				"zoom",
				"science",
				"astronomy",
				"stargazing",
				"tool"
			]
		},
		"📡": {
			"name": "satellite antenna",
			"slug": "satellite_antenna",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"satellite_antenna",
				"communication",
				"future",
				"radio",
				"space",
				"dish",
				"signal"
			]
		},
		"💉": {
			"name": "syringe",
			"slug": "syringe",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"syringe",
				"health",
				"hospital",
				"drugs",
				"blood",
				"medicine",
				"needle",
				"doctor",
				"nurse",
				"shot",
				"sick",
				"tool",
				"vaccination",
				"vaccine"
			]
		},
		"🩸": {
			"name": "drop of blood",
			"slug": "drop_of_blood",
			"group": "Objects",
			"emoji_version": "12.0",
			"unicode_version": "12.0",
			"skin_tone_support": false,
			"aliases": [
				"drop_of_blood",
				"period",
				"hurt",
				"harm",
				"wound",
				"bleed",
				"doctor",
				"donation",
				"injury",
				"medicine",
				"menstruation"
			]
		},
		"💊": {
			"name": "pill",
			"slug": "pill",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"pill",
				"health",
				"medicine",
				"doctor",
				"pharmacy",
				"drug",
				"capsule",
				"drugs",
				"sick",
				"tablet"
			]
		},
		"🩹": {
			"name": "adhesive bandage",
			"slug": "adhesive_bandage",
			"group": "Objects",
			"emoji_version": "12.0",
			"unicode_version": "12.0",
			"skin_tone_support": false,
			"aliases": [
				"adhesive_bandage",
				"heal",
				"aid",
				"band",
				"doctor",
				"medicine",
				"plaster"
			]
		},
		"🩼": {
			"name": "crutch",
			"slug": "crutch",
			"group": "Objects",
			"emoji_version": "14.0",
			"unicode_version": "14.0",
			"skin_tone_support": false,
			"aliases": [
				"crutch",
				"accessibility",
				"assist",
				"aid",
				"cane",
				"disability",
				"hurt",
				"mobility",
				"stick"
			]
		},
		"🩺": {
			"name": "stethoscope",
			"slug": "stethoscope",
			"group": "Objects",
			"emoji_version": "12.0",
			"unicode_version": "12.0",
			"skin_tone_support": false,
			"aliases": [
				"stethoscope",
				"health",
				"doctor",
				"heart",
				"medicine",
				"healthcheck"
			]
		},
		"🩻": {
			"name": "x-ray",
			"slug": "x_ray",
			"group": "Objects",
			"emoji_version": "14.0",
			"unicode_version": "14.0",
			"skin_tone_support": false,
			"aliases": [
				"x-ray",
				"skeleton",
				"medicine",
				"bones",
				"doctor",
				"medical",
				"ray",
				"x"
			]
		},
		"🚪": {
			"name": "door",
			"slug": "door",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"door",
				"house",
				"entry",
				"exit",
				"doorway",
				"front"
			]
		},
		"🛗": {
			"name": "elevator",
			"slug": "elevator",
			"group": "Objects",
			"emoji_version": "13.0",
			"unicode_version": "13.0",
			"skin_tone_support": false,
			"aliases": [
				"elevator",
				"lift",
				"accessibility",
				"hoist"
			]
		},
		"🪞": {
			"name": "mirror",
			"slug": "mirror",
			"group": "Objects",
			"emoji_version": "13.0",
			"unicode_version": "13.0",
			"skin_tone_support": false,
			"aliases": [
				"mirror",
				"reflection",
				"reflector",
				"speculum"
			]
		},
		"🪟": {
			"name": "window",
			"slug": "window",
			"group": "Objects",
			"emoji_version": "13.0",
			"unicode_version": "13.0",
			"skin_tone_support": false,
			"aliases": [
				"window",
				"scenery",
				"air",
				"frame",
				"fresh",
				"glass",
				"opening",
				"transparent",
				"view"
			]
		},
		"🛏️": {
			"name": "bed",
			"slug": "bed",
			"group": "Objects",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"bed",
				"sleep",
				"rest",
				"bedroom",
				"hotel"
			]
		},
		"🛋️": {
			"name": "couch and lamp",
			"slug": "couch_and_lamp",
			"group": "Objects",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"couch_and_lamp",
				"read",
				"chill",
				"hotel",
				"lounge",
				"settee",
				"sofa"
			]
		},
		"🪑": {
			"name": "chair",
			"slug": "chair",
			"group": "Objects",
			"emoji_version": "12.0",
			"unicode_version": "12.0",
			"skin_tone_support": false,
			"aliases": [
				"chair",
				"sit",
				"furniture",
				"seat"
			]
		},
		"🚽": {
			"name": "toilet",
			"slug": "toilet",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"toilet",
				"restroom",
				"wc",
				"washroom",
				"bathroom",
				"potty",
				"loo"
			]
		},
		"🪠": {
			"name": "plunger",
			"slug": "plunger",
			"group": "Objects",
			"emoji_version": "13.0",
			"unicode_version": "13.0",
			"skin_tone_support": false,
			"aliases": [
				"plunger",
				"toilet",
				"cup",
				"force",
				"plumber",
				"suction"
			]
		},
		"🚿": {
			"name": "shower",
			"slug": "shower",
			"group": "Objects",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"shower",
				"clean",
				"water",
				"bathroom",
				"bath",
				"head"
			]
		},
		"🛁": {
			"name": "bathtub",
			"slug": "bathtub",
			"group": "Objects",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"bathtub",
				"clean",
				"shower",
				"bathroom",
				"bath",
				"bubble"
			]
		},
		"🪤": {
			"name": "mouse trap",
			"slug": "mouse_trap",
			"group": "Objects",
			"emoji_version": "13.0",
			"unicode_version": "13.0",
			"skin_tone_support": false,
			"aliases": [
				"mouse trap",
				"cheese",
				"bait",
				"mousetrap",
				"rodent",
				"snare"
			]
		},
		"🪒": {
			"name": "razor",
			"slug": "razor",
			"group": "Objects",
			"emoji_version": "12.0",
			"unicode_version": "12.0",
			"skin_tone_support": false,
			"aliases": [
				"razor",
				"cut",
				"sharp",
				"shave"
			]
		},
		"🧴": {
			"name": "lotion bottle",
			"slug": "lotion_bottle",
			"group": "Objects",
			"emoji_version": "11.0",
			"unicode_version": "11.0",
			"skin_tone_support": false,
			"aliases": [
				"lotion_bottle",
				"moisturizer",
				"sunscreen",
				"shampoo"
			]
		},
		"🧷": {
			"name": "safety pin",
			"slug": "safety_pin",
			"group": "Objects",
			"emoji_version": "11.0",
			"unicode_version": "11.0",
			"skin_tone_support": false,
			"aliases": [
				"safety_pin",
				"diaper",
				"punk",
				"rock"
			]
		},
		"🧹": {
			"name": "broom",
			"slug": "broom",
			"group": "Objects",
			"emoji_version": "11.0",
			"unicode_version": "11.0",
			"skin_tone_support": false,
			"aliases": [
				"broom",
				"cleaning",
				"sweeping",
				"witch",
				"brush",
				"sweep"
			]
		},
		"🧺": {
			"name": "basket",
			"slug": "basket",
			"group": "Objects",
			"emoji_version": "11.0",
			"unicode_version": "11.0",
			"skin_tone_support": false,
			"aliases": [
				"basket",
				"laundry",
				"farming",
				"picnic"
			]
		},
		"🧻": {
			"name": "roll of paper",
			"slug": "roll_of_paper",
			"group": "Objects",
			"emoji_version": "11.0",
			"unicode_version": "11.0",
			"skin_tone_support": false,
			"aliases": [
				"roll_of_paper",
				"roll",
				"toilet",
				"towels"
			]
		},
		"🪣": {
			"name": "bucket",
			"slug": "bucket",
			"group": "Objects",
			"emoji_version": "13.0",
			"unicode_version": "13.0",
			"skin_tone_support": false,
			"aliases": [
				"bucket",
				"water",
				"container",
				"cask",
				"pail",
				"vat"
			]
		},
		"🧼": {
			"name": "soap",
			"slug": "soap",
			"group": "Objects",
			"emoji_version": "11.0",
			"unicode_version": "11.0",
			"skin_tone_support": false,
			"aliases": [
				"soap",
				"bar",
				"bathing",
				"cleaning",
				"lather",
				"soapdish"
			]
		},
		"🫧": {
			"name": "bubbles",
			"slug": "bubbles",
			"group": "Objects",
			"emoji_version": "14.0",
			"unicode_version": "14.0",
			"skin_tone_support": false,
			"aliases": [
				"bubbles",
				"soap",
				"fun",
				"carbonation",
				"sparkling",
				"burp",
				"clean",
				"underwater"
			]
		},
		"🪥": {
			"name": "toothbrush",
			"slug": "toothbrush",
			"group": "Objects",
			"emoji_version": "13.0",
			"unicode_version": "13.0",
			"skin_tone_support": false,
			"aliases": [
				"toothbrush",
				"hygiene",
				"dental",
				"bathroom",
				"brush",
				"clean",
				"teeth"
			]
		},
		"🧽": {
			"name": "sponge",
			"slug": "sponge",
			"group": "Objects",
			"emoji_version": "11.0",
			"unicode_version": "11.0",
			"skin_tone_support": false,
			"aliases": [
				"sponge",
				"absorbing",
				"cleaning",
				"porous"
			]
		},
		"🧯": {
			"name": "fire extinguisher",
			"slug": "fire_extinguisher",
			"group": "Objects",
			"emoji_version": "11.0",
			"unicode_version": "11.0",
			"skin_tone_support": false,
			"aliases": [
				"fire_extinguisher",
				"quench",
				"extinguish"
			]
		},
		"🛒": {
			"name": "shopping cart",
			"slug": "shopping_cart",
			"group": "Objects",
			"emoji_version": "3.0",
			"unicode_version": "3.0",
			"skin_tone_support": false,
			"aliases": ["shopping_cart", "trolley"]
		},
		"🚬": {
			"name": "cigarette",
			"slug": "cigarette",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"cigarette",
				"kills",
				"tobacco",
				"joint",
				"smoke",
				"activity",
				"smoking",
				"symbol"
			]
		},
		"⚰️": {
			"name": "coffin",
			"slug": "coffin",
			"group": "Objects",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"coffin",
				"vampire",
				"dead",
				"die",
				"death",
				"rip",
				"graveyard",
				"cemetery",
				"casket",
				"funeral",
				"box",
				"remove"
			]
		},
		"🪦": {
			"name": "headstone",
			"slug": "headstone",
			"group": "Objects",
			"emoji_version": "13.0",
			"unicode_version": "13.0",
			"skin_tone_support": false,
			"aliases": [
				"headstone",
				"death",
				"rip",
				"grave",
				"cemetery",
				"graveyard",
				"halloween",
				"tombstone"
			]
		},
		"⚱️": {
			"name": "funeral urn",
			"slug": "funeral_urn",
			"group": "Objects",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"funeral_urn",
				"dead",
				"die",
				"death",
				"rip",
				"ashes",
				"vase"
			]
		},
		"🧿": {
			"name": "nazar amulet",
			"slug": "nazar_amulet",
			"group": "Objects",
			"emoji_version": "11.0",
			"unicode_version": "11.0",
			"skin_tone_support": false,
			"aliases": [
				"nazar_amulet",
				"bead",
				"charm",
				"boncuğu",
				"evil",
				"eye",
				"talisman"
			]
		},
		"🪬": {
			"name": "hamsa",
			"slug": "hamsa",
			"group": "Objects",
			"emoji_version": "14.0",
			"unicode_version": "14.0",
			"skin_tone_support": false,
			"aliases": [
				"hamsa",
				"religion",
				"protection",
				"amulet",
				"fatima",
				"hand",
				"mary",
				"miriam"
			]
		},
		"🗿": {
			"name": "moai",
			"slug": "moai",
			"group": "Objects",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"moai",
				"rock",
				"easter island",
				"carving",
				"face",
				"human",
				"moyai",
				"statue",
				"stone"
			]
		},
		"🪧": {
			"name": "placard",
			"slug": "placard",
			"group": "Objects",
			"emoji_version": "13.0",
			"unicode_version": "13.0",
			"skin_tone_support": false,
			"aliases": [
				"placard",
				"announcement",
				"demonstration",
				"lawn",
				"picket",
				"post",
				"protest",
				"sign"
			]
		},
		"🪪": {
			"name": "identification card",
			"slug": "identification_card",
			"group": "Objects",
			"emoji_version": "14.0",
			"unicode_version": "14.0",
			"skin_tone_support": false,
			"aliases": [
				"identification card",
				"document",
				"credentials",
				"id",
				"license",
				"security"
			]
		},
		"🏧": {
			"name": "ATM sign",
			"slug": "atm_sign",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"atm_sign",
				"money",
				"sales",
				"cash",
				"blue-square",
				"payment",
				"bank",
				"automated",
				"machine",
				"teller"
			]
		},
		"🚮": {
			"name": "litter in bin sign",
			"slug": "litter_in_bin_sign",
			"group": "Symbols",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"litter_in_bin_sign",
				"blue-square",
				"sign",
				"human",
				"info",
				"its",
				"litterbox",
				"person",
				"place",
				"put",
				"symbol",
				"trash"
			]
		},
		"🚰": {
			"name": "potable water",
			"slug": "potable_water",
			"group": "Symbols",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"potable_water",
				"blue-square",
				"liquid",
				"restroom",
				"cleaning",
				"faucet",
				"drink",
				"drinking",
				"symbol",
				"tap",
				"thirst",
				"thirsty"
			]
		},
		"♿": {
			"name": "wheelchair symbol",
			"slug": "wheelchair_symbol",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"wheelchair_symbol",
				"blue-square",
				"disabled",
				"accessibility",
				"access",
				"accessible",
				"bathroom"
			]
		},
		"🚹": {
			"name": "men’s room",
			"slug": "men_s_room",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"men_s_room",
				"toilet",
				"restroom",
				"wc",
				"blue-square",
				"gender",
				"male",
				"lavatory",
				"man",
				"mens",
				"men’s",
				"symbol"
			]
		},
		"🚺": {
			"name": "women’s room",
			"slug": "women_s_room",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"women_s_room",
				"purple-square",
				"woman",
				"female",
				"toilet",
				"loo",
				"restroom",
				"gender",
				"lavatory",
				"symbol",
				"wc",
				"womens",
				"womens\xA0toilet",
				"women’s"
			]
		},
		"🚻": {
			"name": "restroom",
			"slug": "restroom",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"restroom",
				"blue-square",
				"toilet",
				"refresh",
				"wc",
				"gender",
				"bathroom",
				"lavatory",
				"sign"
			]
		},
		"🚼": {
			"name": "baby symbol",
			"slug": "baby_symbol",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"baby_symbol",
				"orange-square",
				"child",
				"change",
				"changing",
				"nursery",
				"station"
			]
		},
		"🚾": {
			"name": "water closet",
			"slug": "water_closet",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"water_closet",
				"toilet",
				"restroom",
				"blue-square",
				"lavatory",
				"wc"
			]
		},
		"🛂": {
			"name": "passport control",
			"slug": "passport_control",
			"group": "Symbols",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"passport_control",
				"custom",
				"blue-square",
				"border",
				"permissions",
				"authorization",
				"roles"
			]
		},
		"🛃": {
			"name": "customs",
			"slug": "customs",
			"group": "Symbols",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"customs",
				"passport",
				"border",
				"blue-square"
			]
		},
		"🛄": {
			"name": "baggage claim",
			"slug": "baggage_claim",
			"group": "Symbols",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"baggage_claim",
				"blue-square",
				"airport",
				"transport"
			]
		},
		"🛅": {
			"name": "left luggage",
			"slug": "left_luggage",
			"group": "Symbols",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"left_luggage",
				"blue-square",
				"travel",
				"baggage",
				"bag\xA0with",
				"key",
				"locked",
				"locker",
				"suitcase"
			]
		},
		"⚠️": {
			"name": "warning",
			"slug": "warning",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"warning",
				"exclamation",
				"wip",
				"alert",
				"error",
				"problem",
				"issue",
				"sign",
				"symbol"
			]
		},
		"🚸": {
			"name": "children crossing",
			"slug": "children_crossing",
			"group": "Symbols",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"children_crossing",
				"school",
				"warning",
				"danger",
				"sign",
				"driving",
				"yellow-diamond",
				"child",
				"kids",
				"pedestrian",
				"traffic",
				"experience",
				"usability"
			]
		},
		"⛔": {
			"name": "no entry",
			"slug": "no_entry",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"no_entry",
				"limit",
				"security",
				"privacy",
				"bad",
				"denied",
				"stop",
				"circle",
				"forbidden",
				"not",
				"prohibited",
				"traffic"
			]
		},
		"🚫": {
			"name": "prohibited",
			"slug": "prohibited",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"prohibited",
				"forbid",
				"stop",
				"limit",
				"denied",
				"disallow",
				"circle",
				"backslash",
				"banned",
				"block",
				"crossed",
				"entry",
				"forbidden",
				"no",
				"not",
				"red",
				"restricted",
				"sign"
			]
		},
		"🚳": {
			"name": "no bicycles",
			"slug": "no_bicycles",
			"group": "Symbols",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"no_bicycles",
				"no_bikes",
				"bicycle",
				"bike",
				"cyclist",
				"prohibited",
				"circle",
				"forbidden",
				"not",
				"sign",
				"vehicle"
			]
		},
		"🚭": {
			"name": "no smoking",
			"slug": "no_smoking",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"no_smoking",
				"cigarette",
				"blue-square",
				"smell",
				"smoke",
				"forbidden",
				"not",
				"prohibited",
				"sign",
				"symbol"
			]
		},
		"🚯": {
			"name": "no littering",
			"slug": "no_littering",
			"group": "Symbols",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"no_littering",
				"trash",
				"bin",
				"garbage",
				"circle",
				"do",
				"forbidden",
				"litter",
				"not",
				"prohibited",
				"symbol"
			]
		},
		"🚱": {
			"name": "non-potable water",
			"slug": "non_potable_water",
			"group": "Symbols",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"non_potable_water",
				"drink",
				"faucet",
				"tap",
				"circle",
				"drinking",
				"forbidden",
				"no",
				"not",
				"prohibited",
				"symbol"
			]
		},
		"🚷": {
			"name": "no pedestrians",
			"slug": "no_pedestrians",
			"group": "Symbols",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"no_pedestrians",
				"rules",
				"crossing",
				"walking",
				"circle",
				"forbidden",
				"not",
				"pedestrian",
				"people",
				"prohibited"
			]
		},
		"📵": {
			"name": "no mobile phones",
			"slug": "no_mobile_phones",
			"group": "Symbols",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"no_mobile_phones",
				"iphone",
				"mute",
				"circle",
				"cell",
				"communication",
				"forbidden",
				"not",
				"phone",
				"prohibited",
				"smartphones",
				"telephone"
			]
		},
		"🔞": {
			"name": "no one under eighteen",
			"slug": "no_one_under_eighteen",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"no_one_under_eighteen",
				"18",
				"drink",
				"pub",
				"night",
				"minor",
				"circle",
				"age",
				"forbidden",
				"not",
				"nsfw",
				"prohibited",
				"restriction",
				"symbol",
				"underage"
			]
		},
		"☢️": {
			"name": "radioactive",
			"slug": "radioactive",
			"group": "Symbols",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"radioactive",
				"nuclear",
				"danger",
				"international",
				"radiation",
				"sign",
				"symbol"
			]
		},
		"☣️": {
			"name": "biohazard",
			"slug": "biohazard",
			"group": "Symbols",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"biohazard",
				"danger",
				"sign"
			]
		},
		"⬆️": {
			"name": "up arrow",
			"slug": "up_arrow",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"up_arrow",
				"blue-square",
				"continue",
				"top",
				"direction",
				"black",
				"cardinal",
				"north",
				"pointing",
				"upwards",
				"upgrade"
			]
		},
		"↗️": {
			"name": "up-right arrow",
			"slug": "up_right_arrow",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"up_right_arrow",
				"blue-square",
				"point",
				"direction",
				"diagonal",
				"northeast",
				"east",
				"intercardinal",
				"north",
				"upper"
			]
		},
		"➡️": {
			"name": "right arrow",
			"slug": "right_arrow",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"right_arrow",
				"blue-square",
				"next",
				"black",
				"cardinal",
				"direction",
				"east",
				"pointing",
				"rightwards",
				"right\xA0arrow"
			]
		},
		"↘️": {
			"name": "down-right arrow",
			"slug": "down_right_arrow",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"down_right_arrow",
				"blue-square",
				"direction",
				"diagonal",
				"southeast",
				"east",
				"intercardinal",
				"lower",
				"right\xA0arrow",
				"south"
			]
		},
		"⬇️": {
			"name": "down arrow",
			"slug": "down_arrow",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"down_arrow",
				"blue-square",
				"direction",
				"bottom",
				"black",
				"cardinal",
				"downwards",
				"down\xA0arrow",
				"pointing",
				"south",
				"downgrade"
			]
		},
		"↙️": {
			"name": "down-left arrow",
			"slug": "down_left_arrow",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"down_left_arrow",
				"blue-square",
				"direction",
				"diagonal",
				"southwest",
				"intercardinal",
				"left\xA0arrow",
				"lower",
				"south",
				"west"
			]
		},
		"⬅️": {
			"name": "left arrow",
			"slug": "left_arrow",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"left_arrow",
				"blue-square",
				"previous",
				"back",
				"black",
				"cardinal",
				"direction",
				"leftwards",
				"left\xA0arrow",
				"pointing",
				"west"
			]
		},
		"↖️": {
			"name": "up-left arrow",
			"slug": "up_left_arrow",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"up_left_arrow",
				"blue-square",
				"point",
				"direction",
				"diagonal",
				"northwest",
				"intercardinal",
				"left\xA0arrow",
				"north",
				"upper",
				"west"
			]
		},
		"↕️": {
			"name": "up-down arrow",
			"slug": "up_down_arrow",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"up_down_arrow",
				"blue-square",
				"direction",
				"way",
				"vertical",
				"arrows",
				"intercardinal",
				"northwest"
			]
		},
		"↔️": {
			"name": "left-right arrow",
			"slug": "left_right_arrow",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"left_right_arrow",
				"shape",
				"direction",
				"horizontal",
				"sideways",
				"arrows",
				"horizontal\xA0arrows"
			]
		},
		"↩️": {
			"name": "right arrow curving left",
			"slug": "right_arrow_curving_left",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"right_arrow_curving_left",
				"back",
				"return",
				"blue-square",
				"undo",
				"enter",
				"curved",
				"email",
				"hook",
				"leftwards",
				"reply"
			]
		},
		"↪️": {
			"name": "left arrow curving right",
			"slug": "left_arrow_curving_right",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"left_arrow_curving_right",
				"blue-square",
				"return",
				"rotate",
				"direction",
				"email",
				"forward",
				"hook",
				"rightwards",
				"right\xA0curved"
			]
		},
		"⤴️": {
			"name": "right arrow curving up",
			"slug": "right_arrow_curving_up",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"right_arrow_curving_up",
				"blue-square",
				"direction",
				"top",
				"heading",
				"pointing",
				"rightwards",
				"then",
				"upwards"
			]
		},
		"⤵️": {
			"name": "right arrow curving down",
			"slug": "right_arrow_curving_down",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"right_arrow_curving_down",
				"blue-square",
				"direction",
				"bottom",
				"curved",
				"downwards",
				"heading",
				"pointing",
				"rightwards",
				"then"
			]
		},
		"🔃": {
			"name": "clockwise vertical arrows",
			"slug": "clockwise_vertical_arrows",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"clockwise_vertical_arrows",
				"sync",
				"cycle",
				"round",
				"repeat",
				"arrow",
				"circle",
				"downwards",
				"open",
				"reload",
				"upwards"
			]
		},
		"🔄": {
			"name": "counterclockwise arrows button",
			"slug": "counterclockwise_arrows_button",
			"group": "Symbols",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"counterclockwise_arrows_button",
				"blue-square",
				"sync",
				"cycle",
				"anticlockwise",
				"arrow",
				"circle",
				"downwards",
				"open",
				"refresh",
				"rotate",
				"switch",
				"upwards",
				"withershins"
			]
		},
		"🔙": {
			"name": "BACK arrow",
			"slug": "back_arrow",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"back_arrow",
				"arrow",
				"words",
				"return",
				"above",
				"leftwards"
			]
		},
		"🔚": {
			"name": "END arrow",
			"slug": "end_arrow",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"end_arrow",
				"words",
				"arrow",
				"above",
				"leftwards"
			]
		},
		"🔛": {
			"name": "ON! arrow",
			"slug": "on_arrow",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"on_arrow",
				"arrow",
				"words",
				"above",
				"exclamation",
				"left",
				"mark",
				"on!",
				"right"
			]
		},
		"🔜": {
			"name": "SOON arrow",
			"slug": "soon_arrow",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"soon_arrow",
				"arrow",
				"words",
				"above",
				"rightwards"
			]
		},
		"🔝": {
			"name": "TOP arrow",
			"slug": "top_arrow",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"top_arrow",
				"words",
				"blue-square",
				"above",
				"up",
				"upwards"
			]
		},
		"🛐": {
			"name": "place of worship",
			"slug": "place_of_worship",
			"group": "Symbols",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"place_of_worship",
				"religion",
				"church",
				"temple",
				"prayer",
				"building",
				"religious"
			]
		},
		"⚛️": {
			"name": "atom symbol",
			"slug": "atom_symbol",
			"group": "Symbols",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"atom_symbol",
				"science",
				"physics",
				"chemistry",
				"atheist"
			]
		},
		"🕉️": {
			"name": "om",
			"slug": "om",
			"group": "Symbols",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"om",
				"hinduism",
				"buddhism",
				"sikhism",
				"jainism",
				"aumkara",
				"hindu",
				"omkara",
				"pranava",
				"religion",
				"symbol"
			]
		},
		"✡️": {
			"name": "star of David",
			"slug": "star_of_david",
			"group": "Symbols",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"star_of_david",
				"judaism",
				"jew",
				"jewish",
				"magen",
				"religion"
			]
		},
		"☸️": {
			"name": "wheel of dharma",
			"slug": "wheel_of_dharma",
			"group": "Symbols",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"wheel_of_dharma",
				"hinduism",
				"buddhism",
				"sikhism",
				"jainism",
				"buddhist",
				"helm",
				"religion"
			]
		},
		"☯️": {
			"name": "yin yang",
			"slug": "yin_yang",
			"group": "Symbols",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"yin_yang",
				"balance",
				"religion",
				"tao",
				"taoist"
			]
		},
		"✝️": {
			"name": "latin cross",
			"slug": "latin_cross",
			"group": "Symbols",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"latin_cross",
				"christianity",
				"christian",
				"religion"
			]
		},
		"☦️": {
			"name": "orthodox cross",
			"slug": "orthodox_cross",
			"group": "Symbols",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"orthodox_cross",
				"suppedaneum",
				"religion",
				"christian"
			]
		},
		"☪️": {
			"name": "star and crescent",
			"slug": "star_and_crescent",
			"group": "Symbols",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"star_and_crescent",
				"islam",
				"muslim",
				"religion"
			]
		},
		"☮️": {
			"name": "peace symbol",
			"slug": "peace_symbol",
			"group": "Symbols",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"peace_symbol",
				"hippie",
				"sign"
			]
		},
		"🕎": {
			"name": "menorah",
			"slug": "menorah",
			"group": "Symbols",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"menorah",
				"hanukkah",
				"candles",
				"jewish",
				"branches",
				"candelabrum",
				"candlestick",
				"chanukiah",
				"nine",
				"religion"
			]
		},
		"🔯": {
			"name": "dotted six-pointed star",
			"slug": "dotted_six_pointed_star",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"dotted_six_pointed_star",
				"purple-square",
				"religion",
				"jewish",
				"hexagram",
				"dot",
				"fortune",
				"middle"
			]
		},
		"🪯": {
			"name": "khanda",
			"slug": "khanda",
			"group": "Symbols",
			"emoji_version": "15.0",
			"unicode_version": "15.0",
			"skin_tone_support": false,
			"aliases": [
				"khanda",
				"Sikhism",
				"religion"
			]
		},
		"♈": {
			"name": "Aries",
			"slug": "aries",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"aries",
				"sign",
				"purple-square",
				"zodiac",
				"astrology",
				"ram"
			]
		},
		"♉": {
			"name": "Taurus",
			"slug": "taurus",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"taurus",
				"purple-square",
				"sign",
				"zodiac",
				"astrology",
				"bull",
				"ox"
			]
		},
		"♊": {
			"name": "Gemini",
			"slug": "gemini",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"gemini",
				"sign",
				"zodiac",
				"purple-square",
				"astrology",
				"twins"
			]
		},
		"♋": {
			"name": "Cancer",
			"slug": "cancer",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"cancer",
				"sign",
				"zodiac",
				"purple-square",
				"astrology",
				"crab"
			]
		},
		"♌": {
			"name": "Leo",
			"slug": "leo",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"leo",
				"sign",
				"purple-square",
				"zodiac",
				"astrology",
				"lion"
			]
		},
		"♍": {
			"name": "Virgo",
			"slug": "virgo",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"virgo",
				"sign",
				"zodiac",
				"purple-square",
				"astrology",
				"maiden",
				"virgin"
			]
		},
		"♎": {
			"name": "Libra",
			"slug": "libra",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"libra",
				"sign",
				"purple-square",
				"zodiac",
				"astrology",
				"balance",
				"justice",
				"scales"
			]
		},
		"♏": {
			"name": "Scorpio",
			"slug": "scorpio",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"scorpio",
				"sign",
				"zodiac",
				"purple-square",
				"astrology",
				"scorpion",
				"scorpius"
			]
		},
		"♐": {
			"name": "Sagittarius",
			"slug": "sagittarius",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"sagittarius",
				"sign",
				"zodiac",
				"purple-square",
				"astrology",
				"archer"
			]
		},
		"♑": {
			"name": "Capricorn",
			"slug": "capricorn",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"capricorn",
				"sign",
				"zodiac",
				"purple-square",
				"astrology",
				"goat"
			]
		},
		"♒": {
			"name": "Aquarius",
			"slug": "aquarius",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"aquarius",
				"sign",
				"purple-square",
				"zodiac",
				"astrology",
				"bearer",
				"water"
			]
		},
		"♓": {
			"name": "Pisces",
			"slug": "pisces",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"pisces",
				"purple-square",
				"sign",
				"zodiac",
				"astrology",
				"fish"
			]
		},
		"⛎": {
			"name": "Ophiuchus",
			"slug": "ophiuchus",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"ophiuchus",
				"sign",
				"purple-square",
				"constellation",
				"astrology",
				"bearer",
				"serpent",
				"snake",
				"zodiac"
			]
		},
		"🔀": {
			"name": "shuffle tracks button",
			"slug": "shuffle_tracks_button",
			"group": "Symbols",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"shuffle_tracks_button",
				"blue-square",
				"shuffle",
				"music",
				"random",
				"arrow",
				"arrows",
				"crossed",
				"rightwards",
				"symbol",
				"twisted",
				"merge"
			]
		},
		"🔁": {
			"name": "repeat button",
			"slug": "repeat_button",
			"group": "Symbols",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"repeat_button",
				"loop",
				"record",
				"arrow",
				"arrows",
				"circle",
				"clockwise",
				"leftwards",
				"open",
				"retweet",
				"rightwards",
				"symbol"
			]
		},
		"🔂": {
			"name": "repeat single button",
			"slug": "repeat_single_button",
			"group": "Symbols",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"repeat_single_button",
				"blue-square",
				"loop",
				"arrow",
				"arrows",
				"circle",
				"circled",
				"clockwise",
				"leftwards",
				"number",
				"once",
				"one",
				"open",
				"overlay",
				"rightwards",
				"symbol",
				"track"
			]
		},
		"▶️": {
			"name": "play button",
			"slug": "play_button",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"play_button",
				"blue-square",
				"right",
				"direction",
				"play",
				"arrow",
				"black",
				"forward",
				"pointing",
				"right\xA0triangle",
				"triangle"
			]
		},
		"⏩": {
			"name": "fast-forward button",
			"slug": "fast_forward_button",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"fast_forward_button",
				"blue-square",
				"play",
				"speed",
				"continue",
				"arrow",
				"black",
				"double",
				"pointing",
				"right",
				"symbol",
				"triangle"
			]
		},
		"⏭️": {
			"name": "next track button",
			"slug": "next_track_button",
			"group": "Symbols",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"next_track_button",
				"forward",
				"next",
				"blue-square",
				"arrow",
				"bar",
				"black",
				"double",
				"pointing",
				"right",
				"scene",
				"skip",
				"symbol",
				"triangle",
				"vertical"
			]
		},
		"⏯️": {
			"name": "play or pause button",
			"slug": "play_or_pause_button",
			"group": "Symbols",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"play_or_pause_button",
				"blue-square",
				"play",
				"pause",
				"arrow",
				"bar",
				"black",
				"double",
				"play/pause",
				"pointing",
				"right",
				"symbol",
				"triangle",
				"vertical"
			]
		},
		"◀️": {
			"name": "reverse button",
			"slug": "reverse_button",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"reverse_button",
				"blue-square",
				"left",
				"direction",
				"arrow",
				"backward",
				"black",
				"pointing",
				"triangle"
			]
		},
		"⏪": {
			"name": "fast reverse button",
			"slug": "fast_reverse_button",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"fast_reverse_button",
				"play",
				"blue-square",
				"arrow",
				"black",
				"double",
				"left",
				"pointing",
				"rewind",
				"symbol",
				"triangle",
				"revert"
			]
		},
		"⏮️": {
			"name": "last track button",
			"slug": "last_track_button",
			"group": "Symbols",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"last_track_button",
				"backward",
				"arrow",
				"bar",
				"black",
				"double",
				"left",
				"pointing",
				"previous",
				"scene",
				"skip",
				"symbol",
				"triangle",
				"vertical"
			]
		},
		"🔼": {
			"name": "upwards button",
			"slug": "upwards_button",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"upwards_button",
				"blue-square",
				"triangle",
				"direction",
				"point",
				"forward",
				"top",
				"arrow",
				"pointing",
				"red",
				"small",
				"up"
			]
		},
		"⏫": {
			"name": "fast up button",
			"slug": "fast_up_button",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"fast_up_button",
				"blue-square",
				"direction",
				"top",
				"arrow",
				"black",
				"double",
				"pointing",
				"triangle"
			]
		},
		"🔽": {
			"name": "downwards button",
			"slug": "downwards_button",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"downwards_button",
				"blue-square",
				"direction",
				"bottom",
				"arrow",
				"down",
				"pointing",
				"red",
				"small",
				"triangle"
			]
		},
		"⏬": {
			"name": "fast down button",
			"slug": "fast_down_button",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"fast_down_button",
				"blue-square",
				"direction",
				"bottom",
				"arrow",
				"black",
				"double",
				"pointing",
				"triangle"
			]
		},
		"⏸️": {
			"name": "pause button",
			"slug": "pause_button",
			"group": "Symbols",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"pause_button",
				"pause",
				"blue-square",
				"bar",
				"double",
				"symbol",
				"vertical"
			]
		},
		"⏹️": {
			"name": "stop button",
			"slug": "stop_button",
			"group": "Symbols",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"stop_button",
				"blue-square",
				"black",
				"for",
				"square",
				"symbol"
			]
		},
		"⏺️": {
			"name": "record button",
			"slug": "record_button",
			"group": "Symbols",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"record_button",
				"blue-square",
				"black",
				"circle",
				"for",
				"symbol"
			]
		},
		"⏏️": {
			"name": "eject button",
			"slug": "eject_button",
			"group": "Symbols",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"eject_button",
				"blue-square",
				"symbol"
			]
		},
		"🎦": {
			"name": "cinema",
			"slug": "cinema",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"cinema",
				"blue-square",
				"record",
				"film",
				"movie",
				"curtain",
				"stage",
				"theater",
				"activity",
				"camera",
				"entertainment",
				"movies",
				"screen",
				"symbol"
			]
		},
		"🔅": {
			"name": "dim button",
			"slug": "dim_button",
			"group": "Symbols",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"dim_button",
				"sun",
				"afternoon",
				"warm",
				"summer",
				"brightness",
				"decrease",
				"low",
				"symbol"
			]
		},
		"🔆": {
			"name": "bright button",
			"slug": "bright_button",
			"group": "Symbols",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"bright_button",
				"sun",
				"light",
				"brightness",
				"high",
				"increase",
				"symbol"
			]
		},
		"📶": {
			"name": "antenna bars",
			"slug": "antenna_bars",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"antenna_bars",
				"blue-square",
				"reception",
				"phone",
				"internet",
				"connection",
				"wifi",
				"bluetooth",
				"bars",
				"bar",
				"cell",
				"cellular",
				"communication",
				"mobile",
				"signal",
				"stairs",
				"strength",
				"telephone"
			]
		},
		"🛜": {
			"name": "wireless",
			"slug": "wireless",
			"group": "Symbols",
			"emoji_version": "15.0",
			"unicode_version": "15.0",
			"skin_tone_support": false,
			"aliases": [
				"wireless",
				"wifi",
				"internet",
				"contactless",
				"signal"
			]
		},
		"📳": {
			"name": "vibration mode",
			"slug": "vibration_mode",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"vibration_mode",
				"orange-square",
				"phone",
				"cell",
				"communication",
				"heart",
				"mobile",
				"silent",
				"telephone"
			]
		},
		"📴": {
			"name": "mobile phone off",
			"slug": "mobile_phone_off",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"mobile_phone_off",
				"mute",
				"orange-square",
				"silence",
				"quiet",
				"cell",
				"communication",
				"telephone"
			]
		},
		"♀️": {
			"name": "female sign",
			"slug": "female_sign",
			"group": "Symbols",
			"emoji_version": "4.0",
			"unicode_version": "4.0",
			"skin_tone_support": false,
			"aliases": [
				"female_sign",
				"woman",
				"women",
				"lady",
				"girl",
				"symbol",
				"venus"
			]
		},
		"♂️": {
			"name": "male sign",
			"slug": "male_sign",
			"group": "Symbols",
			"emoji_version": "4.0",
			"unicode_version": "4.0",
			"skin_tone_support": false,
			"aliases": [
				"male_sign",
				"man",
				"boy",
				"men",
				"mars",
				"symbol"
			]
		},
		"⚧️": {
			"name": "transgender symbol",
			"slug": "transgender_symbol",
			"group": "Symbols",
			"emoji_version": "13.0",
			"unicode_version": "13.0",
			"skin_tone_support": false,
			"aliases": [
				"transgender symbol",
				"transgender",
				"lgbtq",
				"female",
				"lgbt",
				"male",
				"pride",
				"sign",
				"stroke"
			]
		},
		"✖️": {
			"name": "multiply",
			"slug": "multiply",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"multiplication_sign",
				"math",
				"calculation",
				"cancel",
				"heavy",
				"multiply",
				"symbol",
				"x"
			]
		},
		"➕": {
			"name": "plus",
			"slug": "plus",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"plus_sign",
				"math",
				"calculation",
				"addition",
				"more",
				"increase",
				"heavy",
				"symbol",
				"add"
			]
		},
		"➖": {
			"name": "minus",
			"slug": "minus",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"minus_sign",
				"math",
				"calculation",
				"subtract",
				"less",
				"heavy",
				"symbol",
				"remove"
			]
		},
		"➗": {
			"name": "divide",
			"slug": "divide",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"division_sign",
				"divide",
				"math",
				"calculation",
				"heavy",
				"symbol"
			]
		},
		"🟰": {
			"name": "heavy equals sign",
			"slug": "heavy_equals_sign",
			"group": "Symbols",
			"emoji_version": "14.0",
			"unicode_version": "14.0",
			"skin_tone_support": false,
			"aliases": [
				"heavy equals sign",
				"math",
				"equality"
			]
		},
		"♾️": {
			"name": "infinity",
			"slug": "infinity",
			"group": "Symbols",
			"emoji_version": "11.0",
			"unicode_version": "11.0",
			"skin_tone_support": false,
			"aliases": [
				"infinity",
				"forever",
				"paper",
				"permanent",
				"sign",
				"unbounded",
				"universal"
			]
		},
		"‼️": {
			"name": "double exclamation mark",
			"slug": "double_exclamation_mark",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"double_exclamation_mark",
				"exclamation",
				"surprise",
				"bangbang",
				"punctuation",
				"red"
			]
		},
		"⁉️": {
			"name": "exclamation question mark",
			"slug": "exclamation_question_mark",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"exclamation_question_mark",
				"wat",
				"punctuation",
				"surprise",
				"interrobang",
				"red"
			]
		},
		"❓": {
			"name": "red question mark",
			"slug": "red_question_mark",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"question_mark",
				"doubt",
				"confused",
				"black",
				"ornament",
				"punctuation",
				"red"
			]
		},
		"❔": {
			"name": "white question mark",
			"slug": "white_question_mark",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"white_question_mark",
				"doubts",
				"gray",
				"huh",
				"confused",
				"grey",
				"ornament",
				"outlined",
				"punctuation"
			]
		},
		"❕": {
			"name": "white exclamation mark",
			"slug": "white_exclamation_mark",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"white_exclamation_mark",
				"surprise",
				"punctuation",
				"gray",
				"wow",
				"warning",
				"grey",
				"ornament",
				"outlined"
			]
		},
		"❗": {
			"name": "red exclamation mark",
			"slug": "red_exclamation_mark",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"exclamation_mark",
				"heavy_exclamation_mark",
				"danger",
				"surprise",
				"punctuation",
				"wow",
				"warning",
				"bang",
				"red",
				"symbol"
			]
		},
		"〰️": {
			"name": "wavy dash",
			"slug": "wavy_dash",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"wavy_dash",
				"draw",
				"line",
				"moustache",
				"mustache",
				"squiggle",
				"scribble",
				"punctuation",
				"wave"
			]
		},
		"💱": {
			"name": "currency exchange",
			"slug": "currency_exchange",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"currency_exchange",
				"money",
				"sales",
				"dollar",
				"travel",
				"bank"
			]
		},
		"💲": {
			"name": "heavy dollar sign",
			"slug": "heavy_dollar_sign",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"heavy_dollar_sign",
				"money",
				"sales",
				"payment",
				"currency",
				"buck"
			]
		},
		"⚕️": {
			"name": "medical symbol",
			"slug": "medical_symbol",
			"group": "Symbols",
			"emoji_version": "4.0",
			"unicode_version": "4.0",
			"skin_tone_support": false,
			"aliases": [
				"medical_symbol",
				"health",
				"hospital",
				"aesculapius",
				"asclepius",
				"asklepios",
				"care",
				"doctor",
				"medicine",
				"rod",
				"snake",
				"staff"
			]
		},
		"♻️": {
			"name": "recycling symbol",
			"slug": "recycling_symbol",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"recycling_symbol",
				"arrow",
				"environment",
				"garbage",
				"trash",
				"black",
				"green",
				"logo",
				"recycle",
				"universal",
				"reuse"
			]
		},
		"⚜️": {
			"name": "fleur-de-lis",
			"slug": "fleur_de_lis",
			"group": "Symbols",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"fleur_de_lis",
				"decorative",
				"scout",
				"new",
				"orleans",
				"saints",
				"scouts"
			]
		},
		"🔱": {
			"name": "trident emblem",
			"slug": "trident_emblem",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"trident_emblem",
				"weapon",
				"spear",
				"anchor",
				"pitchfork",
				"ship",
				"tool"
			]
		},
		"📛": {
			"name": "name badge",
			"slug": "name_badge",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"name_badge",
				"fire",
				"forbid",
				"tag",
				"tofu"
			]
		},
		"🔰": {
			"name": "Japanese symbol for beginner",
			"slug": "japanese_symbol_for_beginner",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"japanese_symbol_for_beginner",
				"badge",
				"shield",
				"chevron",
				"green",
				"leaf",
				"mark",
				"shoshinsha",
				"tool",
				"yellow"
			]
		},
		"⭕": {
			"name": "hollow red circle",
			"slug": "hollow_red_circle",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"hollow_red_circle",
				"circle",
				"round",
				"correct",
				"heavy",
				"large",
				"mark",
				"o"
			]
		},
		"✅": {
			"name": "check mark button",
			"slug": "check_mark_button",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"check_mark_button",
				"green-square",
				"ok",
				"agree",
				"vote",
				"election",
				"answer",
				"tick",
				"green",
				"heavy",
				"symbol",
				"white",
				"pass_tests"
			]
		},
		"☑️": {
			"name": "check box with check",
			"slug": "check_box_with_check",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"check_box_with_check",
				"ok",
				"agree",
				"confirm",
				"black-square",
				"vote",
				"election",
				"yes",
				"tick",
				"ballot",
				"checkbox",
				"mark"
			]
		},
		"✔️": {
			"name": "check mark",
			"slug": "check_mark",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"check_mark",
				"ok",
				"nike",
				"answer",
				"yes",
				"tick",
				"heavy"
			]
		},
		"❌": {
			"name": "cross mark",
			"slug": "cross_mark",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"cross_mark",
				"no",
				"delete",
				"remove",
				"cancel",
				"red",
				"multiplication",
				"multiply",
				"x"
			]
		},
		"❎": {
			"name": "cross mark button",
			"slug": "cross_mark_button",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"cross_mark_button",
				"x",
				"green-square",
				"no",
				"deny",
				"negative",
				"square",
				"squared"
			]
		},
		"➰": {
			"name": "curly loop",
			"slug": "curly_loop",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"curly_loop",
				"scribble",
				"draw",
				"shape",
				"squiggle",
				"curl",
				"curling"
			]
		},
		"➿": {
			"name": "double curly loop",
			"slug": "double_curly_loop",
			"group": "Symbols",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"double_curly_loop",
				"tape",
				"cassette",
				"curl",
				"curling",
				"voicemail"
			]
		},
		"〽️": {
			"name": "part alternation mark",
			"slug": "part_alternation_mark",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"part_alternation_mark",
				"graph",
				"presentation",
				"stats",
				"business",
				"economics",
				"bad",
				"m",
				"mcdonald’s"
			]
		},
		"✳️": {
			"name": "eight-spoked asterisk",
			"slug": "eight_spoked_asterisk",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"eight_spoked_asterisk",
				"star",
				"sparkle",
				"green-square"
			]
		},
		"✴️": {
			"name": "eight-pointed star",
			"slug": "eight_pointed_star",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"eight_pointed_star",
				"orange-square",
				"shape",
				"polygon",
				"black",
				"orange"
			]
		},
		"❇️": {
			"name": "sparkle",
			"slug": "sparkle",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"sparkle",
				"stars",
				"green-square",
				"awesome",
				"good",
				"fireworks"
			]
		},
		"©️": {
			"name": "copyright",
			"slug": "copyright",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"copyright",
				"ip",
				"license",
				"circle",
				"law",
				"legal",
				"c",
				"sign"
			]
		},
		"®️": {
			"name": "registered",
			"slug": "registered",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"registered",
				"alphabet",
				"circle",
				"r",
				"sign"
			]
		},
		"™️": {
			"name": "trade mark",
			"slug": "trade_mark",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"trade_mark",
				"trademark",
				"brand",
				"law",
				"legal",
				"sign",
				"tm"
			]
		},
		"🫟": {
			"name": "splatter",
			"slug": "splatter",
			"group": "Symbols",
			"emoji_version": "16.0",
			"unicode_version": "16.0",
			"skin_tone_support": false,
			"aliases": ["splatter"]
		},
		"#️⃣": {
			"name": "keycap #",
			"slug": "keycap_number_sign",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"keycap_",
				"symbol",
				"blue-square",
				"twitter",
				"hash",
				"hashtag",
				"key",
				"number",
				"octothorpe",
				"pound",
				"sign"
			]
		},
		"*️⃣": {
			"name": "keycap *",
			"slug": "keycap_asterisk",
			"group": "Symbols",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"keycap_",
				"star",
				"keycap",
				"asterisk"
			]
		},
		"0️⃣": {
			"name": "keycap 0",
			"slug": "keycap_0",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"keycap_0",
				"0",
				"numbers",
				"blue-square",
				"null",
				"zero",
				"digit"
			]
		},
		"1️⃣": {
			"name": "keycap 1",
			"slug": "keycap_1",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"keycap_1",
				"blue-square",
				"numbers",
				"1",
				"one",
				"digit"
			]
		},
		"2️⃣": {
			"name": "keycap 2",
			"slug": "keycap_2",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"keycap_2",
				"numbers",
				"2",
				"prime",
				"blue-square",
				"two",
				"digit"
			]
		},
		"3️⃣": {
			"name": "keycap 3",
			"slug": "keycap_3",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"keycap_3",
				"3",
				"numbers",
				"prime",
				"blue-square",
				"three",
				"digit"
			]
		},
		"4️⃣": {
			"name": "keycap 4",
			"slug": "keycap_4",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"keycap_4",
				"4",
				"numbers",
				"blue-square",
				"four",
				"digit"
			]
		},
		"5️⃣": {
			"name": "keycap 5",
			"slug": "keycap_5",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"keycap_5",
				"5",
				"numbers",
				"blue-square",
				"prime",
				"five",
				"digit"
			]
		},
		"6️⃣": {
			"name": "keycap 6",
			"slug": "keycap_6",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"keycap_6",
				"6",
				"numbers",
				"blue-square",
				"six",
				"digit"
			]
		},
		"7️⃣": {
			"name": "keycap 7",
			"slug": "keycap_7",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"keycap_7",
				"7",
				"numbers",
				"blue-square",
				"prime",
				"seven",
				"digit"
			]
		},
		"8️⃣": {
			"name": "keycap 8",
			"slug": "keycap_8",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"keycap_8",
				"8",
				"blue-square",
				"numbers",
				"eight",
				"digit"
			]
		},
		"9️⃣": {
			"name": "keycap 9",
			"slug": "keycap_9",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"keycap_9",
				"blue-square",
				"numbers",
				"9",
				"nine",
				"digit"
			]
		},
		"🔟": {
			"name": "keycap 10",
			"slug": "keycap_10",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"keycap_10",
				"numbers",
				"10",
				"blue-square",
				"ten",
				"number"
			]
		},
		"🔠": {
			"name": "input latin uppercase",
			"slug": "input_latin_uppercase",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"input_latin_uppercase",
				"alphabet",
				"words",
				"letters",
				"uppercase",
				"blue-square",
				"abcd",
				"capital",
				"for",
				"symbol"
			]
		},
		"🔡": {
			"name": "input latin lowercase",
			"slug": "input_latin_lowercase",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"input_latin_lowercase",
				"blue-square",
				"letters",
				"lowercase",
				"alphabet",
				"abcd",
				"for",
				"small",
				"symbol"
			]
		},
		"🔢": {
			"name": "input numbers",
			"slug": "input_numbers",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"input_numbers",
				"numbers",
				"blue-square",
				"1234",
				"1",
				"2",
				"3",
				"4",
				"for",
				"numeric",
				"symbol"
			]
		},
		"🔣": {
			"name": "input symbols",
			"slug": "input_symbols",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"input_symbols",
				"blue-square",
				"music",
				"note",
				"ampersand",
				"percent",
				"glyphs",
				"characters",
				"for",
				"symbol",
				"symbol\xA0input"
			]
		},
		"🔤": {
			"name": "input latin letters",
			"slug": "input_latin_letters",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"input_latin_letters",
				"blue-square",
				"alphabet",
				"abc",
				"for",
				"symbol"
			]
		},
		"🅰️": {
			"name": "A button (blood type)",
			"slug": "a_button",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"a_button",
				"red-square",
				"alphabet",
				"letter",
				"blood",
				"capital",
				"latin",
				"negative",
				"squared",
				"type"
			]
		},
		"🆎": {
			"name": "AB button (blood type)",
			"slug": "ab_button",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"ab_button",
				"red-square",
				"alphabet",
				"blood",
				"negative",
				"squared",
				"type"
			]
		},
		"🅱️": {
			"name": "B button (blood type)",
			"slug": "b_button",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"b_button",
				"red-square",
				"alphabet",
				"letter",
				"blood",
				"capital",
				"latin",
				"negative",
				"squared",
				"type"
			]
		},
		"🆑": {
			"name": "CL button",
			"slug": "cl_button",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"cl_button",
				"alphabet",
				"words",
				"red-square",
				"clear",
				"sign",
				"squared"
			]
		},
		"🆒": {
			"name": "COOL button",
			"slug": "cool_button",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"cool_button",
				"words",
				"blue-square",
				"sign",
				"square",
				"squared"
			]
		},
		"🆓": {
			"name": "FREE button",
			"slug": "free_button",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"free_button",
				"blue-square",
				"words",
				"sign",
				"squared"
			]
		},
		ℹ️: {
			"name": "information",
			"slug": "information",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"information",
				"blue-square",
				"alphabet",
				"letter",
				"i",
				"info",
				"lowercase",
				"source",
				"tourist"
			]
		},
		"🆔": {
			"name": "ID button",
			"slug": "id_button",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"id_button",
				"purple-square",
				"words",
				"identification",
				"identity",
				"sign",
				"squared"
			]
		},
		"Ⓜ️": {
			"name": "circled M",
			"slug": "circled_m",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"circled_m",
				"alphabet",
				"blue-circle",
				"letter",
				"capital",
				"circle",
				"latin",
				"metro"
			]
		},
		"🆕": {
			"name": "NEW button",
			"slug": "new_button",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"new_button",
				"blue-square",
				"words",
				"start",
				"fresh",
				"sign",
				"squared"
			]
		},
		"🆖": {
			"name": "NG button",
			"slug": "ng_button",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"ng_button",
				"blue-square",
				"words",
				"shape",
				"icon",
				"blooper",
				"good",
				"no",
				"sign",
				"squared"
			]
		},
		"🅾️": {
			"name": "O button (blood type)",
			"slug": "o_button",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"o_button",
				"alphabet",
				"red-square",
				"letter",
				"blood",
				"capital",
				"latin",
				"negative",
				"o2",
				"squared",
				"type"
			]
		},
		"🆗": {
			"name": "OK button",
			"slug": "ok_button",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"ok_button",
				"good",
				"agree",
				"yes",
				"blue-square",
				"okay",
				"sign",
				"square",
				"squared"
			]
		},
		"🅿️": {
			"name": "P button",
			"slug": "p_button",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"p_button",
				"cars",
				"blue-square",
				"alphabet",
				"letter",
				"capital",
				"latin",
				"negative",
				"parking",
				"sign",
				"squared"
			]
		},
		"🆘": {
			"name": "SOS button",
			"slug": "sos_button",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"sos_button",
				"help",
				"red-square",
				"words",
				"emergency",
				"911",
				"distress",
				"sign",
				"signal",
				"squared"
			]
		},
		"🆙": {
			"name": "UP! button",
			"slug": "up_button",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"up_button",
				"blue-square",
				"above",
				"high",
				"exclamation",
				"level",
				"mark",
				"sign",
				"squared",
				"up!"
			]
		},
		"🆚": {
			"name": "VS button",
			"slug": "vs_button",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"vs_button",
				"words",
				"orange-square",
				"squared",
				"versus"
			]
		},
		"🈁": {
			"name": "Japanese “here” button",
			"slug": "japanese_here_button",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"japanese_here_button",
				"blue-square",
				"here",
				"katakana",
				"japanese",
				"destination",
				"koko",
				"meaning",
				"sign",
				"squared",
				"word",
				"“here”"
			]
		},
		"🈂️": {
			"name": "Japanese “service charge” button",
			"slug": "japanese_service_charge_button",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"japanese_service_charge_button",
				"japanese",
				"blue-square",
				"katakana",
				"charge”",
				"meaning",
				"or",
				"sa",
				"sign",
				"squared",
				"“service",
				"“service”"
			]
		},
		"🈷️": {
			"name": "Japanese “monthly amount” button",
			"slug": "japanese_monthly_amount_button",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"japanese_monthly_amount_button",
				"chinese",
				"month",
				"moon",
				"japanese",
				"orange-square",
				"kanji",
				"amount”",
				"cjk",
				"ideograph",
				"meaning",
				"radical",
				"sign",
				"squared",
				"u6708",
				"unified",
				"“monthly"
			]
		},
		"🈶": {
			"name": "Japanese “not free of charge” button",
			"slug": "japanese_not_free_of_charge_button",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"japanese_not_free_of_charge_button",
				"orange-square",
				"chinese",
				"have",
				"kanji",
				"charge”",
				"cjk",
				"exist",
				"ideograph",
				"meaning",
				"own",
				"sign",
				"squared",
				"u6709",
				"unified",
				"“not"
			]
		},
		"🈯": {
			"name": "Japanese “reserved” button",
			"slug": "japanese_reserved_button",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"japanese_reserved_button",
				"chinese",
				"point",
				"green-square",
				"kanji",
				"cjk",
				"finger",
				"ideograph",
				"meaning",
				"sign",
				"squared",
				"u6307",
				"unified",
				"“reserved”"
			]
		},
		"🉐": {
			"name": "Japanese “bargain” button",
			"slug": "japanese_bargain_button",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"japanese_bargain_button",
				"chinese",
				"kanji",
				"obtain",
				"get",
				"circle",
				"acquire",
				"advantage",
				"circled",
				"ideograph",
				"meaning",
				"sign",
				"“bargain”"
			]
		},
		"🈹": {
			"name": "Japanese “discount” button",
			"slug": "japanese_discount_button",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"japanese_discount_button",
				"cut",
				"divide",
				"chinese",
				"kanji",
				"pink-square",
				"bargain",
				"cjk",
				"ideograph",
				"meaning",
				"sale",
				"sign",
				"squared",
				"u5272",
				"unified",
				"“discount”"
			]
		},
		"🈚": {
			"name": "Japanese “free of charge” button",
			"slug": "japanese_free_of_charge_button",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"japanese_free_of_charge_button",
				"nothing",
				"chinese",
				"kanji",
				"japanese",
				"orange-square",
				"charge”",
				"cjk",
				"ideograph",
				"lacking",
				"meaning",
				"negation",
				"sign",
				"squared",
				"u7121",
				"unified",
				"“free"
			]
		},
		"🈲": {
			"name": "Japanese “prohibited” button",
			"slug": "japanese_prohibited_button",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"japanese_prohibited_button",
				"kanji",
				"japanese",
				"chinese",
				"forbidden",
				"limit",
				"restricted",
				"red-square",
				"cjk",
				"forbid",
				"ideograph",
				"meaning",
				"prohibit",
				"sign",
				"squared",
				"u7981",
				"unified",
				"“prohibited”"
			]
		},
		"🉑": {
			"name": "Japanese “acceptable” button",
			"slug": "japanese_acceptable_button",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"japanese_acceptable_button",
				"ok",
				"good",
				"chinese",
				"kanji",
				"agree",
				"yes",
				"orange-circle",
				"accept",
				"circled",
				"ideograph",
				"meaning",
				"sign",
				"“acceptable”"
			]
		},
		"🈸": {
			"name": "Japanese “application” button",
			"slug": "japanese_application_button",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"japanese_application_button",
				"chinese",
				"japanese",
				"kanji",
				"orange-square",
				"apply",
				"cjk",
				"form",
				"ideograph",
				"meaning",
				"monkey",
				"request",
				"sign",
				"squared",
				"u7533",
				"unified",
				"“application”"
			]
		},
		"🈴": {
			"name": "Japanese “passing grade” button",
			"slug": "japanese_passing_grade_button",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"japanese_passing_grade_button",
				"japanese",
				"chinese",
				"join",
				"kanji",
				"red-square",
				"agreement",
				"cjk",
				"grade”",
				"ideograph",
				"meaning",
				"sign",
				"squared",
				"together",
				"u5408",
				"unified",
				"“passing"
			]
		},
		"🈳": {
			"name": "Japanese “vacancy” button",
			"slug": "japanese_vacancy_button",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"japanese_vacancy_button",
				"kanji",
				"japanese",
				"chinese",
				"empty",
				"sky",
				"blue-square",
				"7a7a",
				"available",
				"cjk",
				"ideograph",
				"meaning",
				"sign",
				"squared",
				"u7a7a",
				"unified",
				"“vacancy”"
			]
		},
		"㊗️": {
			"name": "Japanese “congratulations” button",
			"slug": "japanese_congratulations_button",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"japanese_congratulations_button",
				"chinese",
				"kanji",
				"japanese",
				"red-circle",
				"circled",
				"congratulate",
				"congratulation",
				"ideograph",
				"meaning",
				"sign",
				"“congratulations”"
			]
		},
		"㊙️": {
			"name": "Japanese “secret” button",
			"slug": "japanese_secret_button",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"japanese_secret_button",
				"privacy",
				"chinese",
				"sshh",
				"kanji",
				"red-circle",
				"circled",
				"ideograph",
				"meaning",
				"sign",
				"“secret”"
			]
		},
		"🈺": {
			"name": "Japanese “open for business” button",
			"slug": "japanese_open_for_business_button",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"japanese_open_for_business_button",
				"japanese",
				"opening hours",
				"orange-square",
				"55b6",
				"business”",
				"chinese",
				"cjk",
				"ideograph",
				"meaning",
				"operating",
				"sign",
				"squared",
				"u55b6",
				"unified",
				"work",
				"“open"
			]
		},
		"🈵": {
			"name": "Japanese “no vacancy” button",
			"slug": "japanese_no_vacancy_button",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"japanese_no_vacancy_button",
				"full",
				"chinese",
				"japanese",
				"red-square",
				"kanji",
				"6e80",
				"cjk",
				"fullness",
				"ideograph",
				"meaning",
				"sign",
				"squared",
				"u6e80",
				"unified",
				"vacancy”",
				"“full;",
				"“no"
			]
		},
		"🔴": {
			"name": "red circle",
			"slug": "red_circle",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"red_circle",
				"shape",
				"error",
				"danger",
				"geometric",
				"large"
			]
		},
		"🟠": {
			"name": "orange circle",
			"slug": "orange_circle",
			"group": "Symbols",
			"emoji_version": "12.0",
			"unicode_version": "12.0",
			"skin_tone_support": false,
			"aliases": [
				"orange_circle",
				"round",
				"geometric",
				"large"
			]
		},
		"🟡": {
			"name": "yellow circle",
			"slug": "yellow_circle",
			"group": "Symbols",
			"emoji_version": "12.0",
			"unicode_version": "12.0",
			"skin_tone_support": false,
			"aliases": [
				"yellow_circle",
				"round",
				"geometric",
				"large"
			]
		},
		"🟢": {
			"name": "green circle",
			"slug": "green_circle",
			"group": "Symbols",
			"emoji_version": "12.0",
			"unicode_version": "12.0",
			"skin_tone_support": false,
			"aliases": [
				"green_circle",
				"round",
				"geometric",
				"large"
			]
		},
		"🔵": {
			"name": "blue circle",
			"slug": "blue_circle",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"blue_circle",
				"shape",
				"icon",
				"button",
				"geometric",
				"large"
			]
		},
		"🟣": {
			"name": "purple circle",
			"slug": "purple_circle",
			"group": "Symbols",
			"emoji_version": "12.0",
			"unicode_version": "12.0",
			"skin_tone_support": false,
			"aliases": [
				"purple_circle",
				"round",
				"geometric",
				"large"
			]
		},
		"🟤": {
			"name": "brown circle",
			"slug": "brown_circle",
			"group": "Symbols",
			"emoji_version": "12.0",
			"unicode_version": "12.0",
			"skin_tone_support": false,
			"aliases": [
				"brown_circle",
				"round",
				"geometric",
				"large"
			]
		},
		"⚫": {
			"name": "black circle",
			"slug": "black_circle",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"black_circle",
				"shape",
				"button",
				"round",
				"geometric",
				"medium"
			]
		},
		"⚪": {
			"name": "white circle",
			"slug": "white_circle",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"white_circle",
				"shape",
				"round",
				"geometric",
				"medium"
			]
		},
		"🟥": {
			"name": "red square",
			"slug": "red_square",
			"group": "Symbols",
			"emoji_version": "12.0",
			"unicode_version": "12.0",
			"skin_tone_support": false,
			"aliases": [
				"red_square",
				"card",
				"geometric",
				"large"
			]
		},
		"🟧": {
			"name": "orange square",
			"slug": "orange_square",
			"group": "Symbols",
			"emoji_version": "12.0",
			"unicode_version": "12.0",
			"skin_tone_support": false,
			"aliases": [
				"orange_square",
				"geometric",
				"large"
			]
		},
		"🟨": {
			"name": "yellow square",
			"slug": "yellow_square",
			"group": "Symbols",
			"emoji_version": "12.0",
			"unicode_version": "12.0",
			"skin_tone_support": false,
			"aliases": [
				"yellow_square",
				"card",
				"geometric",
				"large"
			]
		},
		"🟩": {
			"name": "green square",
			"slug": "green_square",
			"group": "Symbols",
			"emoji_version": "12.0",
			"unicode_version": "12.0",
			"skin_tone_support": false,
			"aliases": [
				"green_square",
				"geometric",
				"large"
			]
		},
		"🟦": {
			"name": "blue square",
			"slug": "blue_square",
			"group": "Symbols",
			"emoji_version": "12.0",
			"unicode_version": "12.0",
			"skin_tone_support": false,
			"aliases": [
				"blue_square",
				"geometric",
				"large"
			]
		},
		"🟪": {
			"name": "purple square",
			"slug": "purple_square",
			"group": "Symbols",
			"emoji_version": "12.0",
			"unicode_version": "12.0",
			"skin_tone_support": false,
			"aliases": [
				"purple_square",
				"geometric",
				"large"
			]
		},
		"🟫": {
			"name": "brown square",
			"slug": "brown_square",
			"group": "Symbols",
			"emoji_version": "12.0",
			"unicode_version": "12.0",
			"skin_tone_support": false,
			"aliases": [
				"brown_square",
				"geometric",
				"large"
			]
		},
		"⬛": {
			"name": "black large square",
			"slug": "black_large_square",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"black_large_square",
				"shape",
				"icon",
				"button",
				"geometric"
			]
		},
		"⬜": {
			"name": "white large square",
			"slug": "white_large_square",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"white_large_square",
				"shape",
				"icon",
				"stone",
				"button",
				"geometric"
			]
		},
		"◼️": {
			"name": "black medium square",
			"slug": "black_medium_square",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"black_medium_square",
				"shape",
				"button",
				"icon",
				"geometric"
			]
		},
		"◻️": {
			"name": "white medium square",
			"slug": "white_medium_square",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"white_medium_square",
				"shape",
				"stone",
				"icon",
				"geometric"
			]
		},
		"◾": {
			"name": "black medium-small square",
			"slug": "black_medium_small_square",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"black_medium_small_square",
				"icon",
				"shape",
				"button",
				"geometric"
			]
		},
		"◽": {
			"name": "white medium-small square",
			"slug": "white_medium_small_square",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"white_medium_small_square",
				"shape",
				"stone",
				"icon",
				"button",
				"geometric"
			]
		},
		"▪️": {
			"name": "black small square",
			"slug": "black_small_square",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"black_small_square",
				"shape",
				"icon",
				"geometric"
			]
		},
		"▫️": {
			"name": "white small square",
			"slug": "white_small_square",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"white_small_square",
				"shape",
				"icon",
				"geometric"
			]
		},
		"🔶": {
			"name": "large orange diamond",
			"slug": "large_orange_diamond",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"large_orange_diamond",
				"shape",
				"jewel",
				"gem",
				"geometric"
			]
		},
		"🔷": {
			"name": "large blue diamond",
			"slug": "large_blue_diamond",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"large_blue_diamond",
				"shape",
				"jewel",
				"gem",
				"geometric"
			]
		},
		"🔸": {
			"name": "small orange diamond",
			"slug": "small_orange_diamond",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"small_orange_diamond",
				"shape",
				"jewel",
				"gem",
				"geometric"
			]
		},
		"🔹": {
			"name": "small blue diamond",
			"slug": "small_blue_diamond",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"small_blue_diamond",
				"shape",
				"jewel",
				"gem",
				"geometric"
			]
		},
		"🔺": {
			"name": "red triangle pointed up",
			"slug": "red_triangle_pointed_up",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"red_triangle_pointed_up",
				"shape",
				"direction",
				"up",
				"top",
				"geometric",
				"pointing",
				"small"
			]
		},
		"🔻": {
			"name": "red triangle pointed down",
			"slug": "red_triangle_pointed_down",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"red_triangle_pointed_down",
				"shape",
				"direction",
				"bottom",
				"geometric",
				"pointing",
				"small"
			]
		},
		"💠": {
			"name": "diamond with a dot",
			"slug": "diamond_with_a_dot",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"diamond_with_a_dot",
				"jewel",
				"blue",
				"gem",
				"crystal",
				"fancy",
				"comic",
				"cuteness",
				"flower",
				"geometric",
				"inside",
				"kawaii",
				"shape"
			]
		},
		"🔘": {
			"name": "radio button",
			"slug": "radio_button",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"radio_button",
				"input",
				"old",
				"music",
				"circle",
				"geometric"
			]
		},
		"🔳": {
			"name": "white square button",
			"slug": "white_square_button",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"white_square_button",
				"shape",
				"input",
				"geometric",
				"outlined"
			]
		},
		"🔲": {
			"name": "black square button",
			"slug": "black_square_button",
			"group": "Symbols",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"black_square_button",
				"shape",
				"input",
				"frame",
				"geometric"
			]
		},
		"🏁": {
			"name": "chequered flag",
			"slug": "chequered_flag",
			"group": "Flags",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"chequered_flag",
				"contest",
				"finishline",
				"race",
				"gokart",
				"checkered",
				"finish",
				"girl",
				"grid",
				"milestone",
				"racing"
			]
		},
		"🚩": {
			"name": "triangular flag",
			"slug": "triangular_flag",
			"group": "Flags",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"triangular_flag",
				"mark",
				"milestone",
				"place",
				"pole",
				"post",
				"red",
				"flag"
			]
		},
		"🎌": {
			"name": "crossed flags",
			"slug": "crossed_flags",
			"group": "Flags",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"crossed_flags",
				"japanese",
				"nation",
				"country",
				"border",
				"activity",
				"celebration",
				"cross",
				"flag",
				"two"
			]
		},
		"🏴": {
			"name": "black flag",
			"slug": "black_flag",
			"group": "Flags",
			"emoji_version": "1.0",
			"unicode_version": "1.0",
			"skin_tone_support": false,
			"aliases": [
				"black_flag",
				"pirate",
				"waving"
			]
		},
		"🏳️": {
			"name": "white flag",
			"slug": "white_flag",
			"group": "Flags",
			"emoji_version": "0.7",
			"unicode_version": "0.7",
			"skin_tone_support": false,
			"aliases": [
				"white_flag",
				"losing",
				"loser",
				"lost",
				"surrender",
				"give up",
				"fail",
				"waving"
			]
		},
		"🏳️‍🌈": {
			"name": "rainbow flag",
			"slug": "rainbow_flag",
			"group": "Flags",
			"emoji_version": "4.0",
			"unicode_version": "4.0",
			"skin_tone_support": false,
			"aliases": [
				"rainbow_flag",
				"flag",
				"rainbow",
				"pride",
				"gay",
				"lgbt",
				"queer",
				"homosexual",
				"lesbian",
				"bisexual"
			]
		},
		"🏳️‍⚧️": {
			"name": "transgender flag",
			"slug": "transgender_flag",
			"group": "Flags",
			"emoji_version": "13.0",
			"unicode_version": "13.0",
			"skin_tone_support": false,
			"aliases": [
				"transgender flag",
				"transgender",
				"flag",
				"pride",
				"lgbtq",
				"blue",
				"lgbt",
				"light",
				"pink",
				"trans",
				"white"
			]
		},
		"🏴‍☠️": {
			"name": "pirate flag",
			"slug": "pirate_flag",
			"group": "Flags",
			"emoji_version": "11.0",
			"unicode_version": "11.0",
			"skin_tone_support": false,
			"aliases": [
				"pirate_flag",
				"skull",
				"crossbones",
				"flag",
				"banner",
				"jolly",
				"plunder",
				"roger",
				"treasure"
			]
		},
		"🇦🇨": {
			"name": "flag Ascension Island",
			"slug": "flag_ascension_island",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": ["flag_ascension_island"]
		},
		"🇦🇩": {
			"name": "flag Andorra",
			"slug": "flag_andorra",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_andorra",
				"ad",
				"flag",
				"nation",
				"country",
				"banner",
				"andorra",
				"andorran"
			]
		},
		"🇦🇪": {
			"name": "flag United Arab Emirates",
			"slug": "flag_united_arab_emirates",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_united_arab_emirates",
				"united",
				"arab",
				"emirates",
				"flag",
				"nation",
				"country",
				"banner",
				"united_arab_emirates",
				"emirati",
				"uae"
			]
		},
		"🇦🇫": {
			"name": "flag Afghanistan",
			"slug": "flag_afghanistan",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_afghanistan",
				"af",
				"flag",
				"nation",
				"country",
				"banner",
				"afghanistan",
				"afghan"
			]
		},
		"🇦🇬": {
			"name": "flag Antigua & Barbuda",
			"slug": "flag_antigua_barbuda",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_antigua_barbuda",
				"antigua",
				"barbuda",
				"flag",
				"nation",
				"country",
				"banner",
				"antigua_barbuda"
			]
		},
		"🇦🇮": {
			"name": "flag Anguilla",
			"slug": "flag_anguilla",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_anguilla",
				"ai",
				"flag",
				"nation",
				"country",
				"banner",
				"anguilla",
				"anguillan"
			]
		},
		"🇦🇱": {
			"name": "flag Albania",
			"slug": "flag_albania",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_albania",
				"al",
				"flag",
				"nation",
				"country",
				"banner",
				"albania",
				"albanian"
			]
		},
		"🇦🇲": {
			"name": "flag Armenia",
			"slug": "flag_armenia",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_armenia",
				"am",
				"flag",
				"nation",
				"country",
				"banner",
				"armenia",
				"armenian"
			]
		},
		"🇦🇴": {
			"name": "flag Angola",
			"slug": "flag_angola",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_angola",
				"ao",
				"flag",
				"nation",
				"country",
				"banner",
				"angola",
				"angolan"
			]
		},
		"🇦🇶": {
			"name": "flag Antarctica",
			"slug": "flag_antarctica",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_antarctica",
				"aq",
				"flag",
				"nation",
				"country",
				"banner",
				"antarctica",
				"antarctic"
			]
		},
		"🇦🇷": {
			"name": "flag Argentina",
			"slug": "flag_argentina",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_argentina",
				"ar",
				"flag",
				"nation",
				"country",
				"banner",
				"argentina",
				"argentinian"
			]
		},
		"🇦🇸": {
			"name": "flag American Samoa",
			"slug": "flag_american_samoa",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_american_samoa",
				"american",
				"ws",
				"flag",
				"nation",
				"country",
				"banner",
				"american_samoa",
				"samoan"
			]
		},
		"🇦🇹": {
			"name": "flag Austria",
			"slug": "flag_austria",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_austria",
				"at",
				"flag",
				"nation",
				"country",
				"banner",
				"austria",
				"austrian"
			]
		},
		"🇦🇺": {
			"name": "flag Australia",
			"slug": "flag_australia",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_australia",
				"au",
				"flag",
				"nation",
				"country",
				"banner",
				"australia",
				"aussie",
				"australian",
				"heard",
				"mcdonald"
			]
		},
		"🇦🇼": {
			"name": "flag Aruba",
			"slug": "flag_aruba",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_aruba",
				"aw",
				"flag",
				"nation",
				"country",
				"banner",
				"aruba",
				"aruban"
			]
		},
		"🇦🇽": {
			"name": "flag Åland Islands",
			"slug": "flag_aland_islands",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_aland_islands",
				"Åland",
				"islands",
				"flag",
				"nation",
				"country",
				"banner",
				"aland_islands"
			]
		},
		"🇦🇿": {
			"name": "flag Azerbaijan",
			"slug": "flag_azerbaijan",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_azerbaijan",
				"az",
				"flag",
				"nation",
				"country",
				"banner",
				"azerbaijan",
				"azerbaijani"
			]
		},
		"🇧🇦": {
			"name": "flag Bosnia & Herzegovina",
			"slug": "flag_bosnia_herzegovina",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_bosnia_herzegovina",
				"bosnia",
				"herzegovina",
				"flag",
				"nation",
				"country",
				"banner",
				"bosnia_herzegovina"
			]
		},
		"🇧🇧": {
			"name": "flag Barbados",
			"slug": "flag_barbados",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_barbados",
				"bb",
				"flag",
				"nation",
				"country",
				"banner",
				"barbados",
				"bajan",
				"barbadian"
			]
		},
		"🇧🇩": {
			"name": "flag Bangladesh",
			"slug": "flag_bangladesh",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_bangladesh",
				"bd",
				"flag",
				"nation",
				"country",
				"banner",
				"bangladesh",
				"bangladeshi"
			]
		},
		"🇧🇪": {
			"name": "flag Belgium",
			"slug": "flag_belgium",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_belgium",
				"be",
				"flag",
				"nation",
				"country",
				"banner",
				"belgium",
				"belgian"
			]
		},
		"🇧🇫": {
			"name": "flag Burkina Faso",
			"slug": "flag_burkina_faso",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_burkina_faso",
				"burkina",
				"faso",
				"flag",
				"nation",
				"country",
				"banner",
				"burkina_faso",
				"burkinabe"
			]
		},
		"🇧🇬": {
			"name": "flag Bulgaria",
			"slug": "flag_bulgaria",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_bulgaria",
				"bg",
				"flag",
				"nation",
				"country",
				"banner",
				"bulgaria",
				"bulgarian"
			]
		},
		"🇧🇭": {
			"name": "flag Bahrain",
			"slug": "flag_bahrain",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_bahrain",
				"bh",
				"flag",
				"nation",
				"country",
				"banner",
				"bahrain",
				"bahrainian",
				"bahrani"
			]
		},
		"🇧🇮": {
			"name": "flag Burundi",
			"slug": "flag_burundi",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_burundi",
				"bi",
				"flag",
				"nation",
				"country",
				"banner",
				"burundi",
				"burundian"
			]
		},
		"🇧🇯": {
			"name": "flag Benin",
			"slug": "flag_benin",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_benin",
				"bj",
				"flag",
				"nation",
				"country",
				"banner",
				"benin",
				"beninese"
			]
		},
		"🇧🇱": {
			"name": "flag St. Barthélemy",
			"slug": "flag_st_barthelemy",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_st_barthelemy",
				"saint",
				"barthélemy",
				"flag",
				"nation",
				"country",
				"banner",
				"st_barthelemy",
				"st."
			]
		},
		"🇧🇲": {
			"name": "flag Bermuda",
			"slug": "flag_bermuda",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_bermuda",
				"bm",
				"flag",
				"nation",
				"country",
				"banner",
				"bermuda",
				"bermudan\xA0flag"
			]
		},
		"🇧🇳": {
			"name": "flag Brunei",
			"slug": "flag_brunei",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_brunei",
				"bn",
				"darussalam",
				"flag",
				"nation",
				"country",
				"banner",
				"brunei",
				"bruneian"
			]
		},
		"🇧🇴": {
			"name": "flag Bolivia",
			"slug": "flag_bolivia",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_bolivia",
				"bo",
				"flag",
				"nation",
				"country",
				"banner",
				"bolivia",
				"bolivian"
			]
		},
		"🇧🇶": {
			"name": "flag Caribbean Netherlands",
			"slug": "flag_caribbean_netherlands",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_caribbean_netherlands",
				"bonaire",
				"flag",
				"nation",
				"country",
				"banner",
				"caribbean_netherlands",
				"eustatius",
				"saba",
				"sint"
			]
		},
		"🇧🇷": {
			"name": "flag Brazil",
			"slug": "flag_brazil",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_brazil",
				"br",
				"flag",
				"nation",
				"country",
				"banner",
				"brazil",
				"brasil",
				"brazilian",
				"for"
			]
		},
		"🇧🇸": {
			"name": "flag Bahamas",
			"slug": "flag_bahamas",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_bahamas",
				"bs",
				"flag",
				"nation",
				"country",
				"banner",
				"bahamas",
				"bahamian"
			]
		},
		"🇧🇹": {
			"name": "flag Bhutan",
			"slug": "flag_bhutan",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_bhutan",
				"bt",
				"flag",
				"nation",
				"country",
				"banner",
				"bhutan",
				"bhutanese"
			]
		},
		"🇧🇻": {
			"name": "flag Bouvet Island",
			"slug": "flag_bouvet_island",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": ["flag_bouvet_island", "norway"]
		},
		"🇧🇼": {
			"name": "flag Botswana",
			"slug": "flag_botswana",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_botswana",
				"bw",
				"flag",
				"nation",
				"country",
				"banner",
				"botswana",
				"batswana"
			]
		},
		"🇧🇾": {
			"name": "flag Belarus",
			"slug": "flag_belarus",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_belarus",
				"by",
				"flag",
				"nation",
				"country",
				"banner",
				"belarus",
				"belarusian"
			]
		},
		"🇧🇿": {
			"name": "flag Belize",
			"slug": "flag_belize",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_belize",
				"bz",
				"flag",
				"nation",
				"country",
				"banner",
				"belize",
				"belizean"
			]
		},
		"🇨🇦": {
			"name": "flag Canada",
			"slug": "flag_canada",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_canada",
				"ca",
				"flag",
				"nation",
				"country",
				"banner",
				"canada",
				"canadian"
			]
		},
		"🇨🇨": {
			"name": "flag Cocos (Keeling) Islands",
			"slug": "flag_cocos_islands",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_cocos_islands",
				"cocos",
				"keeling",
				"islands",
				"flag",
				"nation",
				"country",
				"banner",
				"cocos_islands",
				"island"
			]
		},
		"🇨🇩": {
			"name": "flag Congo - Kinshasa",
			"slug": "flag_congo_kinshasa",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_congo_kinshasa",
				"congo",
				"democratic",
				"republic",
				"flag",
				"nation",
				"country",
				"banner",
				"congo_kinshasa",
				"drc"
			]
		},
		"🇨🇫": {
			"name": "flag Central African Republic",
			"slug": "flag_central_african_republic",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_central_african_republic",
				"central",
				"african",
				"republic",
				"flag",
				"nation",
				"country",
				"banner",
				"central_african_republic"
			]
		},
		"🇨🇬": {
			"name": "flag Congo - Brazzaville",
			"slug": "flag_congo_brazzaville",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_congo_brazzaville",
				"congo",
				"flag",
				"nation",
				"country",
				"banner",
				"congo_brazzaville",
				"republic"
			]
		},
		"🇨🇭": {
			"name": "flag Switzerland",
			"slug": "flag_switzerland",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_switzerland",
				"ch",
				"flag",
				"nation",
				"country",
				"banner",
				"switzerland",
				"cross",
				"red",
				"swiss"
			]
		},
		"🇨🇮": {
			"name": "flag Côte d’Ivoire",
			"slug": "flag_cote_d_ivoire",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_cote_d_ivoire",
				"ivory",
				"coast",
				"flag",
				"nation",
				"country",
				"banner",
				"cote_d_ivoire",
				"côte",
				"divoire",
				"d’ivoire"
			]
		},
		"🇨🇰": {
			"name": "flag Cook Islands",
			"slug": "flag_cook_islands",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_cook_islands",
				"cook",
				"islands",
				"flag",
				"nation",
				"country",
				"banner",
				"cook_islands",
				"island",
				"islander"
			]
		},
		"🇨🇱": {
			"name": "flag Chile",
			"slug": "flag_chile",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_chile",
				"flag",
				"nation",
				"country",
				"banner",
				"chile",
				"chilean"
			]
		},
		"🇨🇲": {
			"name": "flag Cameroon",
			"slug": "flag_cameroon",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_cameroon",
				"cm",
				"flag",
				"nation",
				"country",
				"banner",
				"cameroon",
				"cameroonian"
			]
		},
		"🇨🇳": {
			"name": "flag China",
			"slug": "flag_china",
			"group": "Flags",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"flag_china",
				"china",
				"chinese",
				"prc",
				"flag",
				"country",
				"nation",
				"banner",
				"cn",
				"indicator",
				"letters",
				"regional",
				"symbol"
			]
		},
		"🇨🇴": {
			"name": "flag Colombia",
			"slug": "flag_colombia",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_colombia",
				"co",
				"flag",
				"nation",
				"country",
				"banner",
				"colombia",
				"colombian"
			]
		},
		"🇨🇵": {
			"name": "flag Clipperton Island",
			"slug": "flag_clipperton_island",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": ["flag_clipperton_island"]
		},
		"🇨🇶": {
			"name": "flag Sark",
			"slug": "flag_sark",
			"group": "Flags",
			"emoji_version": "16.0",
			"unicode_version": "16.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_sark",
				"cq",
				"flag",
				"banner"
			]
		},
		"🇨🇷": {
			"name": "flag Costa Rica",
			"slug": "flag_costa_rica",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_costa_rica",
				"costa",
				"rica",
				"flag",
				"nation",
				"country",
				"banner",
				"costa_rica",
				"rican"
			]
		},
		"🇨🇺": {
			"name": "flag Cuba",
			"slug": "flag_cuba",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_cuba",
				"cu",
				"flag",
				"nation",
				"country",
				"banner",
				"cuba",
				"cuban"
			]
		},
		"🇨🇻": {
			"name": "flag Cape Verde",
			"slug": "flag_cape_verde",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_cape_verde",
				"cabo",
				"verde",
				"flag",
				"nation",
				"country",
				"banner",
				"cape_verde",
				"verdian"
			]
		},
		"🇨🇼": {
			"name": "flag Curaçao",
			"slug": "flag_curacao",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_curacao",
				"curaçao",
				"flag",
				"nation",
				"country",
				"banner",
				"curacao",
				"antilles",
				"curaçaoan"
			]
		},
		"🇨🇽": {
			"name": "flag Christmas Island",
			"slug": "flag_christmas_island",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_christmas_island",
				"christmas",
				"island",
				"flag",
				"nation",
				"country",
				"banner",
				"christmas_island"
			]
		},
		"🇨🇾": {
			"name": "flag Cyprus",
			"slug": "flag_cyprus",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_cyprus",
				"cy",
				"flag",
				"nation",
				"country",
				"banner",
				"cyprus",
				"cypriot"
			]
		},
		"🇨🇿": {
			"name": "flag Czechia",
			"slug": "flag_czechia",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_czechia",
				"cz",
				"flag",
				"nation",
				"country",
				"banner",
				"czechia",
				"czech",
				"republic"
			]
		},
		"🇩🇪": {
			"name": "flag Germany",
			"slug": "flag_germany",
			"group": "Flags",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"flag_germany",
				"german",
				"nation",
				"flag",
				"country",
				"banner",
				"germany",
				"de",
				"deutsch",
				"indicator",
				"letters",
				"regional",
				"symbol"
			]
		},
		"🇩🇬": {
			"name": "flag Diego Garcia",
			"slug": "flag_diego_garcia",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": ["flag_diego_garcia"]
		},
		"🇩🇯": {
			"name": "flag Djibouti",
			"slug": "flag_djibouti",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_djibouti",
				"dj",
				"flag",
				"nation",
				"country",
				"banner",
				"djibouti",
				"djiboutian"
			]
		},
		"🇩🇰": {
			"name": "flag Denmark",
			"slug": "flag_denmark",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_denmark",
				"dk",
				"flag",
				"nation",
				"country",
				"banner",
				"denmark",
				"danish"
			]
		},
		"🇩🇲": {
			"name": "flag Dominica",
			"slug": "flag_dominica",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_dominica",
				"dm",
				"flag",
				"nation",
				"country",
				"banner",
				"dominica"
			]
		},
		"🇩🇴": {
			"name": "flag Dominican Republic",
			"slug": "flag_dominican_republic",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_dominican_republic",
				"dominican",
				"republic",
				"flag",
				"nation",
				"country",
				"banner",
				"dominican_republic",
				"dom",
				"rep"
			]
		},
		"🇩🇿": {
			"name": "flag Algeria",
			"slug": "flag_algeria",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_algeria",
				"dz",
				"flag",
				"nation",
				"country",
				"banner",
				"algeria",
				"algerian"
			]
		},
		"🇪🇦": {
			"name": "flag Ceuta & Melilla",
			"slug": "flag_ceuta_melilla",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": ["flag_ceuta_melilla"]
		},
		"🇪🇨": {
			"name": "flag Ecuador",
			"slug": "flag_ecuador",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_ecuador",
				"ec",
				"flag",
				"nation",
				"country",
				"banner",
				"ecuador",
				"ecuadorian"
			]
		},
		"🇪🇪": {
			"name": "flag Estonia",
			"slug": "flag_estonia",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_estonia",
				"ee",
				"flag",
				"nation",
				"country",
				"banner",
				"estonia",
				"estonian"
			]
		},
		"🇪🇬": {
			"name": "flag Egypt",
			"slug": "flag_egypt",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_egypt",
				"eg",
				"flag",
				"nation",
				"country",
				"banner",
				"egypt",
				"egyptian"
			]
		},
		"🇪🇭": {
			"name": "flag Western Sahara",
			"slug": "flag_western_sahara",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_western_sahara",
				"western",
				"sahara",
				"flag",
				"nation",
				"country",
				"banner",
				"western_sahara",
				"saharan",
				"west"
			]
		},
		"🇪🇷": {
			"name": "flag Eritrea",
			"slug": "flag_eritrea",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_eritrea",
				"er",
				"flag",
				"nation",
				"country",
				"banner",
				"eritrea",
				"eritrean"
			]
		},
		"🇪🇸": {
			"name": "flag Spain",
			"slug": "flag_spain",
			"group": "Flags",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"flag_spain",
				"spain",
				"flag",
				"nation",
				"country",
				"banner",
				"ceuta",
				"es",
				"indicator",
				"letters",
				"melilla",
				"regional",
				"spanish",
				"symbol"
			]
		},
		"🇪🇹": {
			"name": "flag Ethiopia",
			"slug": "flag_ethiopia",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_ethiopia",
				"et",
				"flag",
				"nation",
				"country",
				"banner",
				"ethiopia",
				"ethiopian"
			]
		},
		"🇪🇺": {
			"name": "flag European Union",
			"slug": "flag_european_union",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_european_union",
				"european",
				"union",
				"flag",
				"banner",
				"eu"
			]
		},
		"🇫🇮": {
			"name": "flag Finland",
			"slug": "flag_finland",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_finland",
				"fi",
				"flag",
				"nation",
				"country",
				"banner",
				"finland",
				"finnish"
			]
		},
		"🇫🇯": {
			"name": "flag Fiji",
			"slug": "flag_fiji",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_fiji",
				"fj",
				"flag",
				"nation",
				"country",
				"banner",
				"fiji",
				"fijian"
			]
		},
		"🇫🇰": {
			"name": "flag Falkland Islands",
			"slug": "flag_falkland_islands",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_falkland_islands",
				"falkland",
				"islands",
				"malvinas",
				"flag",
				"nation",
				"country",
				"banner",
				"falkland_islands",
				"falklander",
				"falklands",
				"island",
				"islas"
			]
		},
		"🇫🇲": {
			"name": "flag Micronesia",
			"slug": "flag_micronesia",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_micronesia",
				"micronesia",
				"federated",
				"states",
				"flag",
				"nation",
				"country",
				"banner",
				"micronesian"
			]
		},
		"🇫🇴": {
			"name": "flag Faroe Islands",
			"slug": "flag_faroe_islands",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_faroe_islands",
				"faroe",
				"islands",
				"flag",
				"nation",
				"country",
				"banner",
				"faroe_islands",
				"island",
				"islander"
			]
		},
		"🇫🇷": {
			"name": "flag France",
			"slug": "flag_france",
			"group": "Flags",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"flag_france",
				"banner",
				"flag",
				"nation",
				"france",
				"french",
				"country",
				"clipperton",
				"fr",
				"indicator",
				"island",
				"letters",
				"martin",
				"regional",
				"saint",
				"st.",
				"symbol"
			]
		},
		"🇬🇦": {
			"name": "flag Gabon",
			"slug": "flag_gabon",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_gabon",
				"ga",
				"flag",
				"nation",
				"country",
				"banner",
				"gabon",
				"gabonese"
			]
		},
		"🇬🇧": {
			"name": "flag United Kingdom",
			"slug": "flag_united_kingdom",
			"group": "Flags",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"flag_united_kingdom",
				"united",
				"kingdom",
				"great",
				"britain",
				"northern",
				"ireland",
				"flag",
				"nation",
				"country",
				"banner",
				"british",
				"UK",
				"english",
				"england",
				"union jack",
				"united_kingdom",
				"cornwall",
				"gb",
				"scotland",
				"wales"
			]
		},
		"🇬🇩": {
			"name": "flag Grenada",
			"slug": "flag_grenada",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_grenada",
				"gd",
				"flag",
				"nation",
				"country",
				"banner",
				"grenada",
				"grenadian"
			]
		},
		"🇬🇪": {
			"name": "flag Georgia",
			"slug": "flag_georgia",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_georgia",
				"ge",
				"flag",
				"nation",
				"country",
				"banner",
				"georgia",
				"georgian"
			]
		},
		"🇬🇫": {
			"name": "flag French Guiana",
			"slug": "flag_french_guiana",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_french_guiana",
				"french",
				"guiana",
				"flag",
				"nation",
				"country",
				"banner",
				"french_guiana",
				"guinean"
			]
		},
		"🇬🇬": {
			"name": "flag Guernsey",
			"slug": "flag_guernsey",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_guernsey",
				"gg",
				"flag",
				"nation",
				"country",
				"banner",
				"guernsey"
			]
		},
		"🇬🇭": {
			"name": "flag Ghana",
			"slug": "flag_ghana",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_ghana",
				"gh",
				"flag",
				"nation",
				"country",
				"banner",
				"ghana",
				"ghanaian"
			]
		},
		"🇬🇮": {
			"name": "flag Gibraltar",
			"slug": "flag_gibraltar",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_gibraltar",
				"gi",
				"flag",
				"nation",
				"country",
				"banner",
				"gibraltar",
				"gibraltarian"
			]
		},
		"🇬🇱": {
			"name": "flag Greenland",
			"slug": "flag_greenland",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_greenland",
				"gl",
				"flag",
				"nation",
				"country",
				"banner",
				"greenland",
				"greenlandic"
			]
		},
		"🇬🇲": {
			"name": "flag Gambia",
			"slug": "flag_gambia",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_gambia",
				"gm",
				"flag",
				"nation",
				"country",
				"banner",
				"gambia",
				"gambian\xA0flag"
			]
		},
		"🇬🇳": {
			"name": "flag Guinea",
			"slug": "flag_guinea",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_guinea",
				"gn",
				"flag",
				"nation",
				"country",
				"banner",
				"guinea",
				"guinean"
			]
		},
		"🇬🇵": {
			"name": "flag Guadeloupe",
			"slug": "flag_guadeloupe",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_guadeloupe",
				"gp",
				"flag",
				"nation",
				"country",
				"banner",
				"guadeloupe",
				"guadeloupean"
			]
		},
		"🇬🇶": {
			"name": "flag Equatorial Guinea",
			"slug": "flag_equatorial_guinea",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_equatorial_guinea",
				"equatorial",
				"gn",
				"flag",
				"nation",
				"country",
				"banner",
				"equatorial_guinea",
				"equatoguinean",
				"guinean"
			]
		},
		"🇬🇷": {
			"name": "flag Greece",
			"slug": "flag_greece",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_greece",
				"gr",
				"flag",
				"nation",
				"country",
				"banner",
				"greece",
				"greek"
			]
		},
		"🇬🇸": {
			"name": "flag South Georgia & South Sandwich Islands",
			"slug": "flag_south_georgia_south_sandwich_islands",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_south_georgia_south_sandwich_islands",
				"south",
				"georgia",
				"sandwich",
				"islands",
				"flag",
				"nation",
				"country",
				"banner",
				"south_georgia_south_sandwich_islands",
				"island"
			]
		},
		"🇬🇹": {
			"name": "flag Guatemala",
			"slug": "flag_guatemala",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_guatemala",
				"gt",
				"flag",
				"nation",
				"country",
				"banner",
				"guatemala",
				"guatemalan"
			]
		},
		"🇬🇺": {
			"name": "flag Guam",
			"slug": "flag_guam",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_guam",
				"gu",
				"flag",
				"nation",
				"country",
				"banner",
				"guam",
				"chamorro",
				"guamanian"
			]
		},
		"🇬🇼": {
			"name": "flag Guinea-Bissau",
			"slug": "flag_guinea_bissau",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_guinea_bissau",
				"gw",
				"bissau",
				"flag",
				"nation",
				"country",
				"banner",
				"guinea_bissau"
			]
		},
		"🇬🇾": {
			"name": "flag Guyana",
			"slug": "flag_guyana",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_guyana",
				"gy",
				"flag",
				"nation",
				"country",
				"banner",
				"guyana",
				"guyanese"
			]
		},
		"🇭🇰": {
			"name": "flag Hong Kong SAR China",
			"slug": "flag_hong_kong_sar_china",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_hong_kong_sar_china",
				"hong",
				"kong",
				"flag",
				"nation",
				"country",
				"banner",
				"hong_kong_sar_china"
			]
		},
		"🇭🇲": {
			"name": "flag Heard & McDonald Islands",
			"slug": "flag_heard_mcdonald_islands",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": ["flag_heard_mcdonald_islands"]
		},
		"🇭🇳": {
			"name": "flag Honduras",
			"slug": "flag_honduras",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_honduras",
				"hn",
				"flag",
				"nation",
				"country",
				"banner",
				"honduras",
				"honduran"
			]
		},
		"🇭🇷": {
			"name": "flag Croatia",
			"slug": "flag_croatia",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_croatia",
				"hr",
				"flag",
				"nation",
				"country",
				"banner",
				"croatia",
				"croatian"
			]
		},
		"🇭🇹": {
			"name": "flag Haiti",
			"slug": "flag_haiti",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_haiti",
				"ht",
				"flag",
				"nation",
				"country",
				"banner",
				"haiti",
				"haitian"
			]
		},
		"🇭🇺": {
			"name": "flag Hungary",
			"slug": "flag_hungary",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_hungary",
				"hu",
				"flag",
				"nation",
				"country",
				"banner",
				"hungary",
				"hungarian"
			]
		},
		"🇮🇨": {
			"name": "flag Canary Islands",
			"slug": "flag_canary_islands",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_canary_islands",
				"canary",
				"islands",
				"flag",
				"nation",
				"country",
				"banner",
				"canary_islands",
				"island"
			]
		},
		"🇮🇩": {
			"name": "flag Indonesia",
			"slug": "flag_indonesia",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_indonesia",
				"flag",
				"nation",
				"country",
				"banner",
				"indonesia",
				"indonesian"
			]
		},
		"🇮🇪": {
			"name": "flag Ireland",
			"slug": "flag_ireland",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_ireland",
				"ie",
				"flag",
				"nation",
				"country",
				"banner",
				"ireland",
				"irish\xA0flag"
			]
		},
		"🇮🇱": {
			"name": "flag Israel",
			"slug": "flag_israel",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_israel",
				"il",
				"flag",
				"nation",
				"country",
				"banner",
				"israel",
				"israeli"
			]
		},
		"🇮🇲": {
			"name": "flag Isle of Man",
			"slug": "flag_isle_of_man",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_isle_of_man",
				"isle",
				"man",
				"flag",
				"nation",
				"country",
				"banner",
				"isle_of_man",
				"manx"
			]
		},
		"🇮🇳": {
			"name": "flag India",
			"slug": "flag_india",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_india",
				"in",
				"flag",
				"nation",
				"country",
				"banner",
				"india",
				"indian"
			]
		},
		"🇮🇴": {
			"name": "flag British Indian Ocean Territory",
			"slug": "flag_british_indian_ocean_territory",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_british_indian_ocean_territory",
				"british",
				"indian",
				"ocean",
				"territory",
				"flag",
				"nation",
				"country",
				"banner",
				"british_indian_ocean_territory",
				"chagos",
				"diego",
				"garcia",
				"island"
			]
		},
		"🇮🇶": {
			"name": "flag Iraq",
			"slug": "flag_iraq",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_iraq",
				"iq",
				"flag",
				"nation",
				"country",
				"banner",
				"iraq",
				"iraqi"
			]
		},
		"🇮🇷": {
			"name": "flag Iran",
			"slug": "flag_iran",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_iran",
				"iran",
				"islamic",
				"republic",
				"flag",
				"nation",
				"country",
				"banner",
				"iranian\xA0flag"
			]
		},
		"🇮🇸": {
			"name": "flag Iceland",
			"slug": "flag_iceland",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_iceland",
				"is",
				"flag",
				"nation",
				"country",
				"banner",
				"iceland",
				"icelandic"
			]
		},
		"🇮🇹": {
			"name": "flag Italy",
			"slug": "flag_italy",
			"group": "Flags",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"flag_italy",
				"italy",
				"flag",
				"nation",
				"country",
				"banner",
				"indicator",
				"italian",
				"letters",
				"regional",
				"symbol"
			]
		},
		"🇯🇪": {
			"name": "flag Jersey",
			"slug": "flag_jersey",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_jersey",
				"je",
				"flag",
				"nation",
				"country",
				"banner",
				"jersey"
			]
		},
		"🇯🇲": {
			"name": "flag Jamaica",
			"slug": "flag_jamaica",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_jamaica",
				"jm",
				"flag",
				"nation",
				"country",
				"banner",
				"jamaica",
				"jamaican\xA0flag"
			]
		},
		"🇯🇴": {
			"name": "flag Jordan",
			"slug": "flag_jordan",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_jordan",
				"jo",
				"flag",
				"nation",
				"country",
				"banner",
				"jordan",
				"jordanian"
			]
		},
		"🇯🇵": {
			"name": "flag Japan",
			"slug": "flag_japan",
			"group": "Flags",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"flag_japan",
				"japanese",
				"nation",
				"flag",
				"country",
				"banner",
				"japan",
				"jp",
				"ja",
				"indicator",
				"letters",
				"regional",
				"symbol"
			]
		},
		"🇰🇪": {
			"name": "flag Kenya",
			"slug": "flag_kenya",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_kenya",
				"ke",
				"flag",
				"nation",
				"country",
				"banner",
				"kenya",
				"kenyan"
			]
		},
		"🇰🇬": {
			"name": "flag Kyrgyzstan",
			"slug": "flag_kyrgyzstan",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_kyrgyzstan",
				"kg",
				"flag",
				"nation",
				"country",
				"banner",
				"kyrgyzstan",
				"kyrgyzstani"
			]
		},
		"🇰🇭": {
			"name": "flag Cambodia",
			"slug": "flag_cambodia",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_cambodia",
				"kh",
				"flag",
				"nation",
				"country",
				"banner",
				"cambodia",
				"cambodian"
			]
		},
		"🇰🇮": {
			"name": "flag Kiribati",
			"slug": "flag_kiribati",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_kiribati",
				"ki",
				"flag",
				"nation",
				"country",
				"banner",
				"kiribati",
				"i"
			]
		},
		"🇰🇲": {
			"name": "flag Comoros",
			"slug": "flag_comoros",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_comoros",
				"km",
				"flag",
				"nation",
				"country",
				"banner",
				"comoros",
				"comoran"
			]
		},
		"🇰🇳": {
			"name": "flag St. Kitts & Nevis",
			"slug": "flag_st_kitts_nevis",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_st_kitts_nevis",
				"saint",
				"kitts",
				"nevis",
				"flag",
				"nation",
				"country",
				"banner",
				"st_kitts_nevis",
				"st."
			]
		},
		"🇰🇵": {
			"name": "flag North Korea",
			"slug": "flag_north_korea",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_north_korea",
				"north",
				"korea",
				"nation",
				"flag",
				"country",
				"banner",
				"north_korea",
				"korean"
			]
		},
		"🇰🇷": {
			"name": "flag South Korea",
			"slug": "flag_south_korea",
			"group": "Flags",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"flag_south_korea",
				"south",
				"korea",
				"nation",
				"flag",
				"country",
				"banner",
				"south_korea",
				"indicator",
				"korean",
				"kr",
				"letters",
				"regional",
				"symbol"
			]
		},
		"🇰🇼": {
			"name": "flag Kuwait",
			"slug": "flag_kuwait",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_kuwait",
				"kw",
				"flag",
				"nation",
				"country",
				"banner",
				"kuwait",
				"kuwaiti"
			]
		},
		"🇰🇾": {
			"name": "flag Cayman Islands",
			"slug": "flag_cayman_islands",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_cayman_islands",
				"cayman",
				"islands",
				"flag",
				"nation",
				"country",
				"banner",
				"cayman_islands",
				"caymanian",
				"island"
			]
		},
		"🇰🇿": {
			"name": "flag Kazakhstan",
			"slug": "flag_kazakhstan",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_kazakhstan",
				"kz",
				"flag",
				"nation",
				"country",
				"banner",
				"kazakhstan",
				"kazakh",
				"kazakhstani"
			]
		},
		"🇱🇦": {
			"name": "flag Laos",
			"slug": "flag_laos",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_laos",
				"lao",
				"democratic",
				"republic",
				"flag",
				"nation",
				"country",
				"banner",
				"laos",
				"laotian"
			]
		},
		"🇱🇧": {
			"name": "flag Lebanon",
			"slug": "flag_lebanon",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_lebanon",
				"lb",
				"flag",
				"nation",
				"country",
				"banner",
				"lebanon",
				"lebanese"
			]
		},
		"🇱🇨": {
			"name": "flag St. Lucia",
			"slug": "flag_st_lucia",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_st_lucia",
				"saint",
				"lucia",
				"flag",
				"nation",
				"country",
				"banner",
				"st_lucia",
				"st."
			]
		},
		"🇱🇮": {
			"name": "flag Liechtenstein",
			"slug": "flag_liechtenstein",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_liechtenstein",
				"li",
				"flag",
				"nation",
				"country",
				"banner",
				"liechtenstein",
				"liechtensteiner"
			]
		},
		"🇱🇰": {
			"name": "flag Sri Lanka",
			"slug": "flag_sri_lanka",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_sri_lanka",
				"sri",
				"lanka",
				"flag",
				"nation",
				"country",
				"banner",
				"sri_lanka",
				"lankan"
			]
		},
		"🇱🇷": {
			"name": "flag Liberia",
			"slug": "flag_liberia",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_liberia",
				"lr",
				"flag",
				"nation",
				"country",
				"banner",
				"liberia",
				"liberian"
			]
		},
		"🇱🇸": {
			"name": "flag Lesotho",
			"slug": "flag_lesotho",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_lesotho",
				"ls",
				"flag",
				"nation",
				"country",
				"banner",
				"lesotho",
				"basotho"
			]
		},
		"🇱🇹": {
			"name": "flag Lithuania",
			"slug": "flag_lithuania",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_lithuania",
				"lt",
				"flag",
				"nation",
				"country",
				"banner",
				"lithuania",
				"lithuanian"
			]
		},
		"🇱🇺": {
			"name": "flag Luxembourg",
			"slug": "flag_luxembourg",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_luxembourg",
				"lu",
				"flag",
				"nation",
				"country",
				"banner",
				"luxembourg",
				"luxembourger"
			]
		},
		"🇱🇻": {
			"name": "flag Latvia",
			"slug": "flag_latvia",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_latvia",
				"lv",
				"flag",
				"nation",
				"country",
				"banner",
				"latvia",
				"latvian"
			]
		},
		"🇱🇾": {
			"name": "flag Libya",
			"slug": "flag_libya",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_libya",
				"ly",
				"flag",
				"nation",
				"country",
				"banner",
				"libya",
				"libyan"
			]
		},
		"🇲🇦": {
			"name": "flag Morocco",
			"slug": "flag_morocco",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_morocco",
				"ma",
				"flag",
				"nation",
				"country",
				"banner",
				"morocco",
				"moroccan"
			]
		},
		"🇲🇨": {
			"name": "flag Monaco",
			"slug": "flag_monaco",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_monaco",
				"mc",
				"flag",
				"nation",
				"country",
				"banner",
				"monaco",
				"monégasque"
			]
		},
		"🇲🇩": {
			"name": "flag Moldova",
			"slug": "flag_moldova",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_moldova",
				"moldova",
				"republic",
				"flag",
				"nation",
				"country",
				"banner",
				"moldovan"
			]
		},
		"🇲🇪": {
			"name": "flag Montenegro",
			"slug": "flag_montenegro",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_montenegro",
				"me",
				"flag",
				"nation",
				"country",
				"banner",
				"montenegro",
				"montenegrin"
			]
		},
		"🇲🇫": {
			"name": "flag St. Martin",
			"slug": "flag_st_martin",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": ["flag_st_martin", "st."]
		},
		"🇲🇬": {
			"name": "flag Madagascar",
			"slug": "flag_madagascar",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_madagascar",
				"mg",
				"flag",
				"nation",
				"country",
				"banner",
				"madagascar",
				"madagascan"
			]
		},
		"🇲🇭": {
			"name": "flag Marshall Islands",
			"slug": "flag_marshall_islands",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_marshall_islands",
				"marshall",
				"islands",
				"flag",
				"nation",
				"country",
				"banner",
				"marshall_islands",
				"island",
				"marshallese"
			]
		},
		"🇲🇰": {
			"name": "flag North Macedonia",
			"slug": "flag_north_macedonia",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_north_macedonia",
				"macedonia",
				"flag",
				"nation",
				"country",
				"banner",
				"north_macedonia",
				"macedonian"
			]
		},
		"🇲🇱": {
			"name": "flag Mali",
			"slug": "flag_mali",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_mali",
				"ml",
				"flag",
				"nation",
				"country",
				"banner",
				"mali",
				"malian"
			]
		},
		"🇲🇲": {
			"name": "flag Myanmar (Burma)",
			"slug": "flag_myanmar",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_myanmar",
				"mm",
				"flag",
				"nation",
				"country",
				"banner",
				"myanmar",
				"burma",
				"burmese",
				"for",
				"myanmarese\xA0flag"
			]
		},
		"🇲🇳": {
			"name": "flag Mongolia",
			"slug": "flag_mongolia",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_mongolia",
				"mn",
				"flag",
				"nation",
				"country",
				"banner",
				"mongolia",
				"mongolian"
			]
		},
		"🇲🇴": {
			"name": "flag Macao SAR China",
			"slug": "flag_macao_sar_china",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_macao_sar_china",
				"macao",
				"flag",
				"nation",
				"country",
				"banner",
				"macao_sar_china",
				"macanese\xA0flag",
				"macau"
			]
		},
		"🇲🇵": {
			"name": "flag Northern Mariana Islands",
			"slug": "flag_northern_mariana_islands",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_northern_mariana_islands",
				"northern",
				"mariana",
				"islands",
				"flag",
				"nation",
				"country",
				"banner",
				"northern_mariana_islands",
				"island",
				"micronesian",
				"north"
			]
		},
		"🇲🇶": {
			"name": "flag Martinique",
			"slug": "flag_martinique",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_martinique",
				"mq",
				"flag",
				"nation",
				"country",
				"banner",
				"martinique",
				"martiniquais\xA0flag",
				"of\xA0martinique",
				"snake"
			]
		},
		"🇲🇷": {
			"name": "flag Mauritania",
			"slug": "flag_mauritania",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_mauritania",
				"mr",
				"flag",
				"nation",
				"country",
				"banner",
				"mauritania",
				"mauritanian"
			]
		},
		"🇲🇸": {
			"name": "flag Montserrat",
			"slug": "flag_montserrat",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_montserrat",
				"ms",
				"flag",
				"nation",
				"country",
				"banner",
				"montserrat",
				"montserratian"
			]
		},
		"🇲🇹": {
			"name": "flag Malta",
			"slug": "flag_malta",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_malta",
				"mt",
				"flag",
				"nation",
				"country",
				"banner",
				"malta",
				"maltese"
			]
		},
		"🇲🇺": {
			"name": "flag Mauritius",
			"slug": "flag_mauritius",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_mauritius",
				"mu",
				"flag",
				"nation",
				"country",
				"banner",
				"mauritius",
				"mauritian"
			]
		},
		"🇲🇻": {
			"name": "flag Maldives",
			"slug": "flag_maldives",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_maldives",
				"mv",
				"flag",
				"nation",
				"country",
				"banner",
				"maldives",
				"maldivian"
			]
		},
		"🇲🇼": {
			"name": "flag Malawi",
			"slug": "flag_malawi",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_malawi",
				"mw",
				"flag",
				"nation",
				"country",
				"banner",
				"malawi",
				"malawian\xA0flag"
			]
		},
		"🇲🇽": {
			"name": "flag Mexico",
			"slug": "flag_mexico",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_mexico",
				"mx",
				"flag",
				"nation",
				"country",
				"banner",
				"mexico",
				"mexican"
			]
		},
		"🇲🇾": {
			"name": "flag Malaysia",
			"slug": "flag_malaysia",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_malaysia",
				"my",
				"flag",
				"nation",
				"country",
				"banner",
				"malaysia",
				"malaysian"
			]
		},
		"🇲🇿": {
			"name": "flag Mozambique",
			"slug": "flag_mozambique",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_mozambique",
				"mz",
				"flag",
				"nation",
				"country",
				"banner",
				"mozambique",
				"mozambican"
			]
		},
		"🇳🇦": {
			"name": "flag Namibia",
			"slug": "flag_namibia",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_namibia",
				"na",
				"flag",
				"nation",
				"country",
				"banner",
				"namibia",
				"namibian"
			]
		},
		"🇳🇨": {
			"name": "flag New Caledonia",
			"slug": "flag_new_caledonia",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_new_caledonia",
				"new",
				"caledonia",
				"flag",
				"nation",
				"country",
				"banner",
				"new_caledonia",
				"caledonian"
			]
		},
		"🇳🇪": {
			"name": "flag Niger",
			"slug": "flag_niger",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_niger",
				"ne",
				"flag",
				"nation",
				"country",
				"banner",
				"niger",
				"nigerien\xA0flag"
			]
		},
		"🇳🇫": {
			"name": "flag Norfolk Island",
			"slug": "flag_norfolk_island",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_norfolk_island",
				"norfolk",
				"island",
				"flag",
				"nation",
				"country",
				"banner",
				"norfolk_island"
			]
		},
		"🇳🇬": {
			"name": "flag Nigeria",
			"slug": "flag_nigeria",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_nigeria",
				"flag",
				"nation",
				"country",
				"banner",
				"nigeria",
				"nigerian"
			]
		},
		"🇳🇮": {
			"name": "flag Nicaragua",
			"slug": "flag_nicaragua",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_nicaragua",
				"ni",
				"flag",
				"nation",
				"country",
				"banner",
				"nicaragua",
				"nicaraguan"
			]
		},
		"🇳🇱": {
			"name": "flag Netherlands",
			"slug": "flag_netherlands",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_netherlands",
				"nl",
				"flag",
				"nation",
				"country",
				"banner",
				"netherlands",
				"dutch"
			]
		},
		"🇳🇴": {
			"name": "flag Norway",
			"slug": "flag_norway",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_norway",
				"no",
				"flag",
				"nation",
				"country",
				"banner",
				"norway",
				"bouvet",
				"jan",
				"mayen",
				"norwegian",
				"svalbard"
			]
		},
		"🇳🇵": {
			"name": "flag Nepal",
			"slug": "flag_nepal",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_nepal",
				"np",
				"flag",
				"nation",
				"country",
				"banner",
				"nepal",
				"nepalese"
			]
		},
		"🇳🇷": {
			"name": "flag Nauru",
			"slug": "flag_nauru",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_nauru",
				"nr",
				"flag",
				"nation",
				"country",
				"banner",
				"nauru",
				"nauruan"
			]
		},
		"🇳🇺": {
			"name": "flag Niue",
			"slug": "flag_niue",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_niue",
				"nu",
				"flag",
				"nation",
				"country",
				"banner",
				"niue",
				"niuean"
			]
		},
		"🇳🇿": {
			"name": "flag New Zealand",
			"slug": "flag_new_zealand",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_new_zealand",
				"new",
				"zealand",
				"flag",
				"nation",
				"country",
				"banner",
				"new_zealand",
				"kiwi"
			]
		},
		"🇴🇲": {
			"name": "flag Oman",
			"slug": "flag_oman",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_oman",
				"om_symbol",
				"flag",
				"nation",
				"country",
				"banner",
				"oman",
				"omani"
			]
		},
		"🇵🇦": {
			"name": "flag Panama",
			"slug": "flag_panama",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_panama",
				"pa",
				"flag",
				"nation",
				"country",
				"banner",
				"panama",
				"panamanian"
			]
		},
		"🇵🇪": {
			"name": "flag Peru",
			"slug": "flag_peru",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_peru",
				"pe",
				"flag",
				"nation",
				"country",
				"banner",
				"peru",
				"peruvian"
			]
		},
		"🇵🇫": {
			"name": "flag French Polynesia",
			"slug": "flag_french_polynesia",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_french_polynesia",
				"french",
				"polynesia",
				"flag",
				"nation",
				"country",
				"banner",
				"french_polynesia",
				"polynesian"
			]
		},
		"🇵🇬": {
			"name": "flag Papua New Guinea",
			"slug": "flag_papua_new_guinea",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_papua_new_guinea",
				"papua",
				"new",
				"guinea",
				"flag",
				"nation",
				"country",
				"banner",
				"papua_new_guinea",
				"guinean",
				"png"
			]
		},
		"🇵🇭": {
			"name": "flag Philippines",
			"slug": "flag_philippines",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_philippines",
				"ph",
				"flag",
				"nation",
				"country",
				"banner",
				"philippines"
			]
		},
		"🇵🇰": {
			"name": "flag Pakistan",
			"slug": "flag_pakistan",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_pakistan",
				"pk",
				"flag",
				"nation",
				"country",
				"banner",
				"pakistan",
				"pakistani"
			]
		},
		"🇵🇱": {
			"name": "flag Poland",
			"slug": "flag_poland",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_poland",
				"pl",
				"flag",
				"nation",
				"country",
				"banner",
				"poland",
				"polish"
			]
		},
		"🇵🇲": {
			"name": "flag St. Pierre & Miquelon",
			"slug": "flag_st_pierre_miquelon",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_st_pierre_miquelon",
				"saint",
				"pierre",
				"miquelon",
				"flag",
				"nation",
				"country",
				"banner",
				"st_pierre_miquelon",
				"st."
			]
		},
		"🇵🇳": {
			"name": "flag Pitcairn Islands",
			"slug": "flag_pitcairn_islands",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_pitcairn_islands",
				"pitcairn",
				"flag",
				"nation",
				"country",
				"banner",
				"pitcairn_islands",
				"island"
			]
		},
		"🇵🇷": {
			"name": "flag Puerto Rico",
			"slug": "flag_puerto_rico",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_puerto_rico",
				"puerto",
				"rico",
				"flag",
				"nation",
				"country",
				"banner",
				"puerto_rico",
				"rican"
			]
		},
		"🇵🇸": {
			"name": "flag Palestinian Territories",
			"slug": "flag_palestinian_territories",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_palestinian_territories",
				"palestine",
				"palestinian",
				"territories",
				"flag",
				"nation",
				"country",
				"banner",
				"palestinian_territories"
			]
		},
		"🇵🇹": {
			"name": "flag Portugal",
			"slug": "flag_portugal",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_portugal",
				"pt",
				"flag",
				"nation",
				"country",
				"banner",
				"portugal",
				"portugese"
			]
		},
		"🇵🇼": {
			"name": "flag Palau",
			"slug": "flag_palau",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_palau",
				"pw",
				"flag",
				"nation",
				"country",
				"banner",
				"palau",
				"palauan"
			]
		},
		"🇵🇾": {
			"name": "flag Paraguay",
			"slug": "flag_paraguay",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_paraguay",
				"py",
				"flag",
				"nation",
				"country",
				"banner",
				"paraguay",
				"paraguayan"
			]
		},
		"🇶🇦": {
			"name": "flag Qatar",
			"slug": "flag_qatar",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_qatar",
				"qa",
				"flag",
				"nation",
				"country",
				"banner",
				"qatar",
				"qatari"
			]
		},
		"🇷🇪": {
			"name": "flag Réunion",
			"slug": "flag_reunion",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_reunion",
				"réunion",
				"flag",
				"nation",
				"country",
				"banner",
				"reunion",
				"réunionnais"
			]
		},
		"🇷🇴": {
			"name": "flag Romania",
			"slug": "flag_romania",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_romania",
				"ro",
				"flag",
				"nation",
				"country",
				"banner",
				"romania",
				"romanian"
			]
		},
		"🇷🇸": {
			"name": "flag Serbia",
			"slug": "flag_serbia",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_serbia",
				"rs",
				"flag",
				"nation",
				"country",
				"banner",
				"serbia",
				"serbian\xA0flag"
			]
		},
		"🇷🇺": {
			"name": "flag Russia",
			"slug": "flag_russia",
			"group": "Flags",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"flag_russia",
				"russian",
				"federation",
				"flag",
				"nation",
				"country",
				"banner",
				"russia",
				"indicator",
				"letters",
				"regional",
				"ru",
				"symbol"
			]
		},
		"🇷🇼": {
			"name": "flag Rwanda",
			"slug": "flag_rwanda",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_rwanda",
				"rw",
				"flag",
				"nation",
				"country",
				"banner",
				"rwanda",
				"rwandan"
			]
		},
		"🇸🇦": {
			"name": "flag Saudi Arabia",
			"slug": "flag_saudi_arabia",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_saudi_arabia",
				"flag",
				"nation",
				"country",
				"banner",
				"saudi_arabia",
				"arabian\xA0flag"
			]
		},
		"🇸🇧": {
			"name": "flag Solomon Islands",
			"slug": "flag_solomon_islands",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_solomon_islands",
				"solomon",
				"islands",
				"flag",
				"nation",
				"country",
				"banner",
				"solomon_islands",
				"island",
				"islander\xA0flag"
			]
		},
		"🇸🇨": {
			"name": "flag Seychelles",
			"slug": "flag_seychelles",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_seychelles",
				"sc",
				"flag",
				"nation",
				"country",
				"banner",
				"seychelles",
				"seychellois\xA0flag"
			]
		},
		"🇸🇩": {
			"name": "flag Sudan",
			"slug": "flag_sudan",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_sudan",
				"sd",
				"flag",
				"nation",
				"country",
				"banner",
				"sudan",
				"sudanese"
			]
		},
		"🇸🇪": {
			"name": "flag Sweden",
			"slug": "flag_sweden",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_sweden",
				"se",
				"flag",
				"nation",
				"country",
				"banner",
				"sweden",
				"swedish"
			]
		},
		"🇸🇬": {
			"name": "flag Singapore",
			"slug": "flag_singapore",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_singapore",
				"sg",
				"flag",
				"nation",
				"country",
				"banner",
				"singapore",
				"singaporean"
			]
		},
		"🇸🇭": {
			"name": "flag St. Helena",
			"slug": "flag_st_helena",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_st_helena",
				"saint",
				"helena",
				"ascension",
				"tristan",
				"cunha",
				"flag",
				"nation",
				"country",
				"banner",
				"st_helena",
				"st."
			]
		},
		"🇸🇮": {
			"name": "flag Slovenia",
			"slug": "flag_slovenia",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_slovenia",
				"si",
				"flag",
				"nation",
				"country",
				"banner",
				"slovenia",
				"slovenian"
			]
		},
		"🇸🇯": {
			"name": "flag Svalbard & Jan Mayen",
			"slug": "flag_svalbard_jan_mayen",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": ["flag_svalbard_jan_mayen"]
		},
		"🇸🇰": {
			"name": "flag Slovakia",
			"slug": "flag_slovakia",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_slovakia",
				"sk",
				"flag",
				"nation",
				"country",
				"banner",
				"slovakia",
				"slovakian",
				"slovak\xA0flag"
			]
		},
		"🇸🇱": {
			"name": "flag Sierra Leone",
			"slug": "flag_sierra_leone",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_sierra_leone",
				"sierra",
				"leone",
				"flag",
				"nation",
				"country",
				"banner",
				"sierra_leone",
				"leonean"
			]
		},
		"🇸🇲": {
			"name": "flag San Marino",
			"slug": "flag_san_marino",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_san_marino",
				"san",
				"marino",
				"flag",
				"nation",
				"country",
				"banner",
				"san_marino",
				"sammarinese"
			]
		},
		"🇸🇳": {
			"name": "flag Senegal",
			"slug": "flag_senegal",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_senegal",
				"sn",
				"flag",
				"nation",
				"country",
				"banner",
				"senegal",
				"sengalese"
			]
		},
		"🇸🇴": {
			"name": "flag Somalia",
			"slug": "flag_somalia",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_somalia",
				"so",
				"flag",
				"nation",
				"country",
				"banner",
				"somalia",
				"somalian\xA0flag"
			]
		},
		"🇸🇷": {
			"name": "flag Suriname",
			"slug": "flag_suriname",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_suriname",
				"sr",
				"flag",
				"nation",
				"country",
				"banner",
				"suriname",
				"surinamer"
			]
		},
		"🇸🇸": {
			"name": "flag South Sudan",
			"slug": "flag_south_sudan",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_south_sudan",
				"south",
				"sd",
				"flag",
				"nation",
				"country",
				"banner",
				"south_sudan",
				"sudanese\xA0flag"
			]
		},
		"🇸🇹": {
			"name": "flag São Tomé & Príncipe",
			"slug": "flag_sao_tome_principe",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_sao_tome_principe",
				"sao",
				"tome",
				"principe",
				"flag",
				"nation",
				"country",
				"banner",
				"sao_tome_principe",
				"príncipe",
				"são",
				"tomé"
			]
		},
		"🇸🇻": {
			"name": "flag El Salvador",
			"slug": "flag_el_salvador",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_el_salvador",
				"el",
				"salvador",
				"flag",
				"nation",
				"country",
				"banner",
				"el_salvador",
				"salvadoran"
			]
		},
		"🇸🇽": {
			"name": "flag Sint Maarten",
			"slug": "flag_sint_maarten",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_sint_maarten",
				"sint",
				"maarten",
				"dutch",
				"flag",
				"nation",
				"country",
				"banner",
				"sint_maarten"
			]
		},
		"🇸🇾": {
			"name": "flag Syria",
			"slug": "flag_syria",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_syria",
				"syrian",
				"arab",
				"republic",
				"flag",
				"nation",
				"country",
				"banner",
				"syria"
			]
		},
		"🇸🇿": {
			"name": "flag Eswatini",
			"slug": "flag_eswatini",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_eswatini",
				"sz",
				"flag",
				"nation",
				"country",
				"banner",
				"eswatini",
				"swaziland"
			]
		},
		"🇹🇦": {
			"name": "flag Tristan da Cunha",
			"slug": "flag_tristan_da_cunha",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": ["flag_tristan_da_cunha"]
		},
		"🇹🇨": {
			"name": "flag Turks & Caicos Islands",
			"slug": "flag_turks_caicos_islands",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_turks_caicos_islands",
				"turks",
				"caicos",
				"islands",
				"flag",
				"nation",
				"country",
				"banner",
				"turks_caicos_islands",
				"island"
			]
		},
		"🇹🇩": {
			"name": "flag Chad",
			"slug": "flag_chad",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_chad",
				"td",
				"flag",
				"nation",
				"country",
				"banner",
				"chad",
				"chadian"
			]
		},
		"🇹🇫": {
			"name": "flag French Southern Territories",
			"slug": "flag_french_southern_territories",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_french_southern_territories",
				"french",
				"southern",
				"territories",
				"flag",
				"nation",
				"country",
				"banner",
				"french_southern_territories",
				"antarctic",
				"lands"
			]
		},
		"🇹🇬": {
			"name": "flag Togo",
			"slug": "flag_togo",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_togo",
				"tg",
				"flag",
				"nation",
				"country",
				"banner",
				"togo",
				"togolese"
			]
		},
		"🇹🇭": {
			"name": "flag Thailand",
			"slug": "flag_thailand",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_thailand",
				"th",
				"flag",
				"nation",
				"country",
				"banner",
				"thailand",
				"thai"
			]
		},
		"🇹🇯": {
			"name": "flag Tajikistan",
			"slug": "flag_tajikistan",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_tajikistan",
				"tj",
				"flag",
				"nation",
				"country",
				"banner",
				"tajikistan",
				"tajik"
			]
		},
		"🇹🇰": {
			"name": "flag Tokelau",
			"slug": "flag_tokelau",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_tokelau",
				"tk",
				"flag",
				"nation",
				"country",
				"banner",
				"tokelau",
				"tokelauan"
			]
		},
		"🇹🇱": {
			"name": "flag Timor-Leste",
			"slug": "flag_timor_leste",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_timor_leste",
				"timor",
				"leste",
				"flag",
				"nation",
				"country",
				"banner",
				"timor_leste",
				"east",
				"leste\xA0flag",
				"timorese"
			]
		},
		"🇹🇲": {
			"name": "flag Turkmenistan",
			"slug": "flag_turkmenistan",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_turkmenistan",
				"flag",
				"nation",
				"country",
				"banner",
				"turkmenistan",
				"turkmen"
			]
		},
		"🇹🇳": {
			"name": "flag Tunisia",
			"slug": "flag_tunisia",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_tunisia",
				"tn",
				"flag",
				"nation",
				"country",
				"banner",
				"tunisia",
				"tunisian"
			]
		},
		"🇹🇴": {
			"name": "flag Tonga",
			"slug": "flag_tonga",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_tonga",
				"to",
				"flag",
				"nation",
				"country",
				"banner",
				"tonga",
				"tongan\xA0flag"
			]
		},
		"🇹🇷": {
			"name": "flag Türkiye",
			"slug": "flag_turkiye",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_turkey",
				"turkey",
				"flag",
				"nation",
				"country",
				"banner",
				"tr",
				"turkish\xA0flag",
				"türkiye"
			]
		},
		"🇹🇹": {
			"name": "flag Trinidad & Tobago",
			"slug": "flag_trinidad_tobago",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_trinidad_tobago",
				"trinidad",
				"tobago",
				"flag",
				"nation",
				"country",
				"banner",
				"trinidad_tobago"
			]
		},
		"🇹🇻": {
			"name": "flag Tuvalu",
			"slug": "flag_tuvalu",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_tuvalu",
				"flag",
				"nation",
				"country",
				"banner",
				"tuvalu",
				"tuvaluan"
			]
		},
		"🇹🇼": {
			"name": "flag Taiwan",
			"slug": "flag_taiwan",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_taiwan",
				"tw",
				"flag",
				"nation",
				"country",
				"banner",
				"taiwan",
				"china",
				"taiwanese"
			]
		},
		"🇹🇿": {
			"name": "flag Tanzania",
			"slug": "flag_tanzania",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_tanzania",
				"tanzania",
				"united",
				"republic",
				"flag",
				"nation",
				"country",
				"banner",
				"tanzanian"
			]
		},
		"🇺🇦": {
			"name": "flag Ukraine",
			"slug": "flag_ukraine",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_ukraine",
				"ua",
				"flag",
				"nation",
				"country",
				"banner",
				"ukraine",
				"ukrainian"
			]
		},
		"🇺🇬": {
			"name": "flag Uganda",
			"slug": "flag_uganda",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_uganda",
				"ug",
				"flag",
				"nation",
				"country",
				"banner",
				"uganda",
				"ugandan\xA0flag"
			]
		},
		"🇺🇲": {
			"name": "flag U.S. Outlying Islands",
			"slug": "flag_u_s_outlying_islands",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_u_s_outlying_islands",
				"u.s.",
				"us"
			]
		},
		"🇺🇳": {
			"name": "flag United Nations",
			"slug": "flag_united_nations",
			"group": "Flags",
			"emoji_version": "4.0",
			"unicode_version": "4.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_united_nations",
				"un",
				"flag",
				"banner"
			]
		},
		"🇺🇸": {
			"name": "flag United States",
			"slug": "flag_united_states",
			"group": "Flags",
			"emoji_version": "0.6",
			"unicode_version": "0.6",
			"skin_tone_support": false,
			"aliases": [
				"flag_united_states",
				"united",
				"states",
				"america",
				"flag",
				"nation",
				"country",
				"banner",
				"united_states",
				"american",
				"indicator",
				"islands",
				"letters",
				"outlying",
				"regional",
				"symbol",
				"us",
				"usa"
			]
		},
		"🇺🇾": {
			"name": "flag Uruguay",
			"slug": "flag_uruguay",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_uruguay",
				"uy",
				"flag",
				"nation",
				"country",
				"banner",
				"uruguay",
				"uruguayan"
			]
		},
		"🇺🇿": {
			"name": "flag Uzbekistan",
			"slug": "flag_uzbekistan",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_uzbekistan",
				"uz",
				"flag",
				"nation",
				"country",
				"banner",
				"uzbekistan",
				"uzbek",
				"uzbekistani"
			]
		},
		"🇻🇦": {
			"name": "flag Vatican City",
			"slug": "flag_vatican_city",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_vatican_city",
				"vatican",
				"city",
				"flag",
				"nation",
				"country",
				"banner",
				"vatican_city",
				"vanticanien"
			]
		},
		"🇻🇨": {
			"name": "flag St. Vincent & Grenadines",
			"slug": "flag_st_vincent_grenadines",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_st_vincent_grenadines",
				"saint",
				"vincent",
				"grenadines",
				"flag",
				"nation",
				"country",
				"banner",
				"st_vincent_grenadines",
				"st."
			]
		},
		"🇻🇪": {
			"name": "flag Venezuela",
			"slug": "flag_venezuela",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_venezuela",
				"ve",
				"bolivarian",
				"republic",
				"flag",
				"nation",
				"country",
				"banner",
				"venezuela",
				"venezuelan"
			]
		},
		"🇻🇬": {
			"name": "flag British Virgin Islands",
			"slug": "flag_british_virgin_islands",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_british_virgin_islands",
				"british",
				"virgin",
				"islands",
				"bvi",
				"flag",
				"nation",
				"country",
				"banner",
				"british_virgin_islands",
				"island",
				"islander"
			]
		},
		"🇻🇮": {
			"name": "flag U.S. Virgin Islands",
			"slug": "flag_u_s_virgin_islands",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_u_s_virgin_islands",
				"virgin",
				"islands",
				"us",
				"flag",
				"nation",
				"country",
				"banner",
				"u_s_virgin_islands",
				"america",
				"island",
				"islander",
				"states",
				"u.s.",
				"united",
				"usa"
			]
		},
		"🇻🇳": {
			"name": "flag Vietnam",
			"slug": "flag_vietnam",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_vietnam",
				"viet",
				"nam",
				"flag",
				"nation",
				"country",
				"banner",
				"vietnam",
				"vietnamese"
			]
		},
		"🇻🇺": {
			"name": "flag Vanuatu",
			"slug": "flag_vanuatu",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_vanuatu",
				"vu",
				"flag",
				"nation",
				"country",
				"banner",
				"vanuatu",
				"ni",
				"vanuatu\xA0flag"
			]
		},
		"🇼🇫": {
			"name": "flag Wallis & Futuna",
			"slug": "flag_wallis_futuna",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_wallis_futuna",
				"wallis",
				"futuna",
				"flag",
				"nation",
				"country",
				"banner",
				"wallis_futuna"
			]
		},
		"🇼🇸": {
			"name": "flag Samoa",
			"slug": "flag_samoa",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_samoa",
				"ws",
				"flag",
				"nation",
				"country",
				"banner",
				"samoa",
				"samoan\xA0flag"
			]
		},
		"🇽🇰": {
			"name": "flag Kosovo",
			"slug": "flag_kosovo",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_kosovo",
				"xk",
				"flag",
				"nation",
				"country",
				"banner",
				"kosovo",
				"kosovar"
			]
		},
		"🇾🇪": {
			"name": "flag Yemen",
			"slug": "flag_yemen",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_yemen",
				"ye",
				"flag",
				"nation",
				"country",
				"banner",
				"yemen",
				"yemeni\xA0flag"
			]
		},
		"🇾🇹": {
			"name": "flag Mayotte",
			"slug": "flag_mayotte",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_mayotte",
				"yt",
				"flag",
				"nation",
				"country",
				"banner",
				"mayotte"
			]
		},
		"🇿🇦": {
			"name": "flag South Africa",
			"slug": "flag_south_africa",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_south_africa",
				"south",
				"africa",
				"flag",
				"nation",
				"country",
				"banner",
				"south_africa",
				"african\xA0flag"
			]
		},
		"🇿🇲": {
			"name": "flag Zambia",
			"slug": "flag_zambia",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_zambia",
				"zm",
				"flag",
				"nation",
				"country",
				"banner",
				"zambia",
				"zambian"
			]
		},
		"🇿🇼": {
			"name": "flag Zimbabwe",
			"slug": "flag_zimbabwe",
			"group": "Flags",
			"emoji_version": "2.0",
			"unicode_version": "2.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_zimbabwe",
				"zw",
				"flag",
				"nation",
				"country",
				"banner",
				"zimbabwe",
				"zim",
				"zimbabwean\xA0flag"
			]
		},
		"🏴󠁧󠁢󠁥󠁮󠁧󠁿": {
			"name": "flag England",
			"slug": "flag_england",
			"group": "Flags",
			"emoji_version": "5.0",
			"unicode_version": "5.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_england",
				"flag",
				"english",
				"cross",
				"george's",
				"st"
			]
		},
		"🏴󠁧󠁢󠁳󠁣󠁴󠁿": {
			"name": "flag Scotland",
			"slug": "flag_scotland",
			"group": "Flags",
			"emoji_version": "5.0",
			"unicode_version": "5.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_scotland",
				"flag",
				"scottish",
				"andrew's",
				"cross",
				"saltire",
				"st"
			]
		},
		"🏴󠁧󠁢󠁷󠁬󠁳󠁿": {
			"name": "flag Wales",
			"slug": "flag_wales",
			"group": "Flags",
			"emoji_version": "5.0",
			"unicode_version": "5.0",
			"skin_tone_support": false,
			"aliases": [
				"flag_wales",
				"flag",
				"welsh",
				"baner",
				"cymru",
				"ddraig",
				"dragon",
				"goch",
				"red",
				"y"
			]
		}
	};
	//#endregion
	//#region src/shared/sanitize.ts
	var ALLOWED_TAGS = new Set([
		"B",
		"STRONG",
		"I",
		"EM",
		"U",
		"BR"
	]);
	var REMOVE_ENTIRELY = new Set([
		"SCRIPT",
		"STYLE",
		"IFRAME",
		"OBJECT",
		"EMBED",
		"SVG"
	]);
	function stripNode(node) {
		const children = Array.from(node.childNodes);
		for (const child of children) if (child.nodeType === Node.ELEMENT_NODE) {
			const el = child;
			if (REMOVE_ENTIRELY.has(el.tagName)) {
				node.removeChild(el);
				continue;
			}
			stripNode(el);
			if (!ALLOWED_TAGS.has(el.tagName)) {
				while (el.firstChild) node.insertBefore(el.firstChild, el);
				node.removeChild(el);
			} else Array.from(el.attributes).forEach((attr) => el.removeAttribute(attr.name));
		} else if (child.nodeType !== Node.TEXT_NODE) node.removeChild(child);
	}
	function sanitizeExpansion(html) {
		const doc = new DOMParser().parseFromString(html, "text/html");
		stripNode(doc.body);
		return doc.body.innerHTML;
	}
	//#endregion
	//#region src/content/content.ts
	var emojiEntries = Object.entries(emoji_default).map(([emoji, meta]) => ({
		...meta,
		emoji
	}));
	function tokenize(s) {
		return s.toLowerCase().split(/[\s_]+/).filter(Boolean);
	}
	function wordVariants(token) {
		const variants = new Set([token]);
		if (token.endsWith("ing") && token.length > 4) {
			const base = token.slice(0, -3);
			variants.add(base);
			variants.add(base + "e");
			if (base.length >= 2 && base[base.length - 1] === base[base.length - 2]) variants.add(base.slice(0, -1));
		}
		if (token.endsWith("ed") && token.length > 3) {
			const base = token.slice(0, -2);
			variants.add(base);
			variants.add(base + "e");
			if (base.length >= 2 && base[base.length - 1] === base[base.length - 2]) variants.add(base.slice(0, -1));
		}
		if (token.endsWith("es") && token.length > 3) variants.add(token.slice(0, -2));
		else if (token.endsWith("s") && token.length > 3) variants.add(token.slice(0, -1));
		return Array.from(variants);
	}
	var searchIndex = emojiEntries.map((entry) => {
		const name = entry.name.toLowerCase();
		const slug = entry.slug.toLowerCase();
		const aliases = entry.aliases.map((a) => a.toLowerCase());
		const tokens = Array.from(new Set([
			...tokenize(name),
			...tokenize(slug),
			...aliases
		]));
		return {
			entry,
			name,
			slug,
			aliases,
			tokens,
			variants: Array.from(new Set(tokens.flatMap(wordVariants)))
		};
	});
	function matchScore(item, q, qSlug) {
		if (item.name === q || item.slug === qSlug || item.aliases.includes(q)) return 0;
		if (item.name.startsWith(q) || item.slug.startsWith(qSlug)) return 1;
		for (const token of item.tokens) if (token === q) return 1;
		for (const v of item.variants) if (v === q) return 2;
		if (q.length >= 3) {
			for (const v of item.variants) if (v.startsWith(q)) return 3;
		}
		if (item.name.includes(q) || item.slug.includes(qSlug)) return 4;
		if (q.length >= 3) {
			for (const v of item.variants) if (v.includes(q)) return 5;
		}
		return null;
	}
	var ACTIVE_FLAG = "__quipCompanionActive__";
	if (window[ACTIVE_FLAG]) {} else {
		window[ACTIVE_FLAG] = true;
		initQuipCompanion();
	}
	function initQuipCompanion() {
		let map = {};
		let modifier = "alt";
		let committing = false;
		let lastCommitAt = 0;
		const COMMIT_COOLDOWN_MS = 150;
		async function load() {
			const stored = await import_browser_polyfill.default.storage.sync.get(["quips", "modifier"]);
			map = stored.quips || {};
			modifier = stored.modifier || "alt";
		}
		load();
		import_browser_polyfill.default.storage.onChanged.addListener((changes, area) => {
			if (area !== "sync") return;
			if (changes.quips) map = changes.quips.newValue || {};
			if (changes.modifier) modifier = changes.modifier.newValue || "alt";
		});
		let host = null;
		let shadow = null;
		let match = null;
		let emojiHost = null;
		let emojiShadow = null;
		let emojiBox = null;
		let emojiCode = null;
		let emojiResults = [];
		let emojiRowEls = [];
		let emojiIndex = 0;
		function parseRgb(str) {
			const m = str.match(/rgba?\(([\d.]+),\s*([\d.]+),\s*([\d.]+)(?:,\s*([\d.]+))?\)/);
			if (!m) return [
				255,
				255,
				255,
				1
			];
			return [
				parseFloat(m[1]),
				parseFloat(m[2]),
				parseFloat(m[3]),
				m[4] !== void 0 ? parseFloat(m[4]) : 1
			];
		}
		function effectiveBgColor(target) {
			let el = target;
			while (el) {
				const [r, g, b, a] = parseRgb(getComputedStyle(el).backgroundColor);
				if (a > .05) return [
					r,
					g,
					b
				];
				el = el.parentElement;
			}
			const [r, g, b] = parseRgb(getComputedStyle(document.documentElement).backgroundColor);
			return [
				r,
				g,
				b
			];
		}
		function siteColors(target) {
			const font = getComputedStyle(document.body).fontFamily || "-apple-system, system-ui, sans-serif";
			const [br, bg2, bb] = effectiveBgColor(target);
			const dark = (br * 299 + bg2 * 587 + bb * 114) / 1e3 < 140;
			const tint = (n) => dark ? Math.min(255, n + 16) : Math.max(0, n - 10);
			const pillBg = `rgba(${tint(br)}, ${tint(bg2)}, ${tint(bb)}, 0.97)`;
			let sampled = 0;
			let el = target;
			while (el && el !== document.body) {
				const val = parseFloat(getComputedStyle(el).borderRadius);
				if (!isNaN(val) && val > 0) {
					sampled = val;
					break;
				}
				el = el.parentElement;
			}
			return {
				font,
				dark,
				pillRadius: `${Math.min(sampled, 16)}px`,
				keyRadius: `${Math.min(Math.round(sampled * .45), 7)}px`,
				pillBg,
				fg: dark ? "rgba(255,255,255,0.9)" : "rgba(10,10,10,0.88)",
				sub: dark ? "rgba(255,255,255,0.28)" : "rgba(0,0,0,0.26)",
				border: dark ? "rgba(255,255,255,0.09)" : "rgba(0,0,0,0.07)",
				keyBg: dark ? "rgba(255,255,255,0.07)" : "rgba(0,0,0,0.055)",
				keyBorder: dark ? "rgba(255,255,255,0.13)" : "rgba(0,0,0,0.09)",
				keyShadow: dark ? "0 1px 0 rgba(0,0,0,0.5)" : "0 1px 0 rgba(0,0,0,0.12)",
				rowHover: dark ? "rgba(255,255,255,0.08)" : "rgba(0,0,0,0.05)",
				rowSelected: dark ? "rgba(255,255,255,0.14)" : "rgba(0,0,0,0.08)"
			};
		}
		function modSymbol() {
			return modifier === "alt" ? "⌥" : modifier === "ctrl" ? "⌃" : "⇧";
		}
		function keySpan(symbol) {
			const span = document.createElement("span");
			span.className = "key";
			span.textContent = symbol;
			return span;
		}
		function htmlToPlainText(html) {
			const doc = new DOMParser().parseFromString(html, "text/html");
			const walk = (node) => {
				if (node.nodeType === Node.TEXT_NODE) return node.textContent || "";
				if (node.nodeType !== Node.ELEMENT_NODE) return "";
				const el = node;
				const tag = el.tagName.toLowerCase();
				if (tag === "br") return "\n";
				let out = "";
				el.childNodes.forEach((child) => {
					out += walk(child);
				});
				if (tag === "div" || tag === "p") return out + "\n";
				return out;
			};
			let result = "";
			doc.body.childNodes.forEach((child) => {
				result += walk(child);
			});
			return result.replace(/\n+$/, "");
		}
		function positionHost(target, hostEl, contentEl) {
			const rect = getAnchorRect(target);
			const pw = contentEl.getBoundingClientRect().width || 220;
			const ph = contentEl.getBoundingClientRect().height || 40;
			const gap = 8;
			const anchorX = Math.max(8, Math.min(rect.left - pw / 2, window.innerWidth - pw - 16));
			const fitsAbove = rect.top - ph - gap > 0;
			hostEl.style.left = `${anchorX}px`;
			hostEl.style.top = fitsAbove ? `${rect.top - ph - gap}px` : `${rect.bottom + gap}px`;
			hostEl.style.visibility = "visible";
		}
		function popover(target, code, expansion) {
			remove();
			const safeExpansion = sanitizeExpansion(expansion);
			host = document.createElement("div");
			host.style.cssText = "position:fixed;z-index:2147483647;visibility:hidden;pointer-events:none;";
			document.body.appendChild(host);
			shadow = host.attachShadow({ mode: "open" });
			const c = siteColors(target);
			const style = document.createElement("style");
			style.textContent = `
    .pill {
      display: inline-flex;
      align-items: center;
      gap: 12px;
      max-width: min(420px, calc(100vw - 24px));
      background: ${c.pillBg};
      backdrop-filter: blur(28px) saturate(180%);
      -webkit-backdrop-filter: blur(28px) saturate(180%);
      border: 0.5px solid ${c.border};
      box-shadow: 0 0 0 0.5px ${c.border}, 0 8px 24px rgba(0,0,0,0.18), 0 2px 6px rgba(0,0,0,0.08), inset 0 1px 0 ${c.dark ? "rgba(255,255,255,0.06)" : "rgba(255,255,255,0.9)"};
      border-radius: ${c.pillRadius};
      padding: 10px 14px;
      font-family: ${c.font};
      white-space: nowrap;
      animation: in 0.13s cubic-bezier(0.2,0.9,0.3,1) both;
    }
    .text {
      min-width: 0;
      overflow: hidden;
      text-overflow: ellipsis;
      font-size: 13.5px;
      font-weight: 500;
      color: ${c.fg};
      letter-spacing: 0;
    }
    .keys { flex: 0 0 auto; }
    .keys { display: flex; align-items: center; gap: 3px; }
    .key {
      display: inline-flex; align-items: center; justify-content: center;
      background: ${c.keyBg}; border: 0.5px solid ${c.keyBorder};
      box-shadow: ${c.keyShadow}; border-radius: ${c.keyRadius};
      padding: 2px 6px; font-size: 11px; color: ${c.sub};
      font-family: -apple-system, system-ui, sans-serif; line-height: 1.4;
    }
    @keyframes in { from { opacity:0; transform:scale(0.95) translateY(3px); } to { opacity:1; transform:scale(1) translateY(0); } }
  `;
			shadow.appendChild(style);
			const pill = document.createElement("div");
			pill.className = "pill";
			const text = document.createElement("span");
			text.className = "text";
			text.textContent = htmlToPlainText(safeExpansion).replace(/\n+/g, " ⏎ ");
			const keys = document.createElement("span");
			keys.className = "keys";
			keys.appendChild(keySpan(modSymbol()));
			keys.appendChild(keySpan("↩"));
			pill.appendChild(text);
			pill.appendChild(keys);
			shadow.appendChild(pill);
			requestAnimationFrame(() => {
				positionHost(target, host, pill);
			});
			match = {
				code,
				expansion: safeExpansion
			};
		}
		function remove() {
			host?.remove();
			host = null;
			shadow = null;
			match = null;
		}
		function searchEmoji(query) {
			const q = query.toLowerCase().trim();
			if (!q) return emojiEntries.slice(0, 40);
			const qSlug = q.replace(/\s+/g, "_");
			const scored = [];
			for (const item of searchIndex) {
				const score = matchScore(item, q, qSlug);
				if (score !== null) scored.push({
					entry: item.entry,
					score
				});
			}
			return scored.sort((a, b) => a.score - b.score || a.entry.name.length - b.entry.name.length || a.entry.name.localeCompare(b.entry.name)).slice(0, 40).map((x) => x.entry);
		}
		function buildEmojiRows(box, target, results) {
			box.innerHTML = "";
			emojiRowEls = [];
			results.forEach((entry, idx) => {
				const row = document.createElement("div");
				row.className = "row" + (idx === 0 ? " selected" : "");
				const glyph = document.createElement("span");
				glyph.className = "glyph";
				glyph.textContent = entry.emoji;
				const name = document.createElement("span");
				name.className = "name";
				name.textContent = entry.name;
				row.appendChild(glyph);
				row.appendChild(name);
				row.addEventListener("mousedown", (ev) => {
					ev.preventDefault();
					emojiIndex = idx;
					commitEmoji(target);
				});
				box.appendChild(row);
				emojiRowEls.push(row);
			});
		}
		function emojiPalette(target, code, query) {
			const results = searchEmoji(query);
			if (!results.length) {
				removeEmoji();
				return;
			}
			emojiCode = code;
			emojiResults = results;
			emojiIndex = 0;
			if (emojiHost && emojiShadow && emojiBox) {
				buildEmojiRows(emojiBox, target, results);
				positionHost(target, emojiHost, emojiBox);
				return;
			}
			emojiHost = document.createElement("div");
			emojiHost.style.cssText = "position:fixed;z-index:2147483647;visibility:hidden;pointer-events:auto;";
			document.body.appendChild(emojiHost);
			emojiShadow = emojiHost.attachShadow({ mode: "open" });
			const c = siteColors(target);
			const style = document.createElement("style");
			style.textContent = `
    .box {
      width: 240px;
      max-height: 260px;
      overflow-y: auto;
      background: ${c.pillBg};
      backdrop-filter: blur(28px) saturate(180%);
      -webkit-backdrop-filter: blur(28px) saturate(180%);
      border: 0.5px solid ${c.border};
      box-shadow: 0 0 0 0.5px ${c.border}, 0 8px 24px rgba(0,0,0,0.18), 0 2px 6px rgba(0,0,0,0.08), inset 0 1px 0 ${c.dark ? "rgba(255,255,255,0.06)" : "rgba(255,255,255,0.9)"};
      border-radius: ${c.pillRadius};
      padding: 6px;
      font-family: ${c.font};
      animation: in 0.13s cubic-bezier(0.2,0.9,0.3,1) both;
    }
    .row {
      display: flex;
      align-items: center;
      gap: 10px;
      padding: 6px 8px;
      border-radius: ${c.keyRadius};
      cursor: pointer;
    }
    .row.selected { background: ${c.rowSelected}; }
    .glyph { font-size: 18px; line-height: 1; flex: 0 0 auto; }
    .name {
      font-size: 12.5px;
      font-weight: 500;
      color: ${c.fg};
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
    @keyframes in { from { opacity:0; transform:scale(0.95) translateY(3px); } to { opacity:1; transform:scale(1) translateY(0); } }
  `;
			emojiShadow.appendChild(style);
			const box = document.createElement("div");
			box.className = "box";
			emojiShadow.appendChild(box);
			emojiBox = box;
			buildEmojiRows(box, target, results);
			requestAnimationFrame(() => {
				positionHost(target, emojiHost, box);
			});
		}
		function updateEmojiSelection() {
			emojiRowEls.forEach((row, idx) => {
				row.classList.toggle("selected", idx === emojiIndex);
				if (idx === emojiIndex) row.scrollIntoView({ block: "nearest" });
			});
		}
		function moveEmojiSelection(delta) {
			if (!emojiResults.length) return;
			emojiIndex = (emojiIndex + delta + emojiResults.length) % emojiResults.length;
			updateEmojiSelection();
		}
		function removeEmoji() {
			emojiHost?.remove();
			emojiHost = null;
			emojiShadow = null;
			emojiBox = null;
			emojiCode = null;
			emojiResults = [];
			emojiRowEls = [];
			emojiIndex = 0;
		}
		function commitEmoji(target) {
			if (!emojiCode || !emojiResults.length) return;
			const entry = emojiResults[emojiIndex];
			match = {
				code: emojiCode,
				expansion: entry.emoji
			};
			commit(target);
			removeEmoji();
		}
		function commit(target) {
			if (!match || committing) return;
			const now = Date.now();
			if (now - lastCommitAt < COMMIT_COOLDOWN_MS) return;
			lastCommitAt = now;
			committing = true;
			if (isTextControl(target)) commitTextControl(target);
			else commitContentEditable(target);
			committing = false;
		}
		function commitTextControl(target) {
			if (!match) return;
			const expansion = htmlToPlainText(match.expansion);
			const val = target.value;
			const cursor = target.selectionStart ?? val.length;
			const beforeCursor = val.slice(0, cursor);
			if (!beforeCursor.endsWith(match.code)) {
				remove();
				return;
			}
			const idx = beforeCursor.length - match.code.length;
			if (idx === -1) return;
			const before = val.slice(0, idx);
			const after = val.slice(idx + match.code.length);
			target.value = before + expansion + after;
			const pos = before.length + expansion.length;
			target.setSelectionRange(pos, pos);
			target.dispatchEvent(new Event("input", { bubbles: true }));
			remove();
		}
		function commitContentEditable(target) {
			if (!match) return;
			const before = textBeforeCaret(target);
			if (!before.endsWith(match.code)) {
				remove();
				return;
			}
			target.focus();
			const selection = getSelection();
			if (!selection?.rangeCount) return;
			const caret = selection.getRangeAt(0);
			if (!caret.collapsed || !target.contains(caret.commonAncestorContainer)) return;
			const start = domPointAtTextOffset(target, before.length - match.code.length);
			if (!start) return;
			const replace = document.createRange();
			replace.setStart(start.node, start.offset);
			replace.setEnd(caret.endContainer, caret.endOffset);
			selection.removeAllRanges();
			selection.addRange(replace);
			target.dispatchEvent(new InputEvent("beforeinput", {
				bubbles: true,
				cancelable: true,
				inputType: "deleteContentBackward"
			}));
			document.execCommand("delete", false);
			const plain = htmlToPlainText(match.expansion);
			target.dispatchEvent(new InputEvent("beforeinput", {
				bubbles: true,
				cancelable: true,
				inputType: "insertFromPaste",
				data: plain
			}));
			if (/<[a-z][\s\S]*>/i.test(match.expansion)) document.execCommand("insertHTML", false, match.expansion);
			else document.execCommand("insertText", false, match.expansion);
			remove();
		}
		function isTextControl(el) {
			return el instanceof HTMLInputElement || el instanceof HTMLTextAreaElement;
		}
		function editableFrom(el) {
			if (!el) return null;
			const editable = el.closest("[contenteditable='true'], [contenteditable='plaintext-only']");
			if (editable) return editable;
			if (el.isContentEditable) {
				let node = el;
				while (node.parentElement?.isContentEditable) node = node.parentElement;
				return node;
			}
			return null;
		}
		function field(e) {
			const el = e.composedPath()[0];
			if (!el) return null;
			if (el instanceof HTMLInputElement || el instanceof HTMLTextAreaElement) return el;
			return editableFrom(el);
		}
		function textBeforeCaret(target) {
			const selection = getSelection();
			if (!selection?.rangeCount) return "";
			const range = selection.getRangeAt(0);
			if (!target.contains(range.endContainer)) return "";
			const before = range.cloneRange();
			before.selectNodeContents(target);
			before.setEnd(range.endContainer, range.endOffset);
			return before.toString();
		}
		function domPointAtTextOffset(root, offset) {
			const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
			let remaining = offset;
			let node = walker.nextNode();
			while (node) {
				if (remaining <= node.length) return {
					node,
					offset: remaining
				};
				remaining -= node.length;
				node = walker.nextNode();
			}
			return null;
		}
		function getAnchorRect(target) {
			if (!isTextControl(target)) {
				const range = getSelection()?.rangeCount ? getSelection().getRangeAt(0).cloneRange() : null;
				if (range && target.contains(range.endContainer)) {
					range.collapse(false);
					let rect = range.getBoundingClientRect();
					if (!rect.width && !rect.height) {
						const marker = document.createElement("span");
						marker.textContent = "​";
						range.insertNode(marker);
						rect = marker.getBoundingClientRect();
						marker.remove();
					}
					if (rect.width || rect.height) return rect;
				}
				return target.getBoundingClientRect();
			}
			const rect = target.getBoundingClientRect();
			const cs = getComputedStyle(target);
			const ctx = document.createElement("canvas").getContext("2d");
			if (!ctx) return rect;
			ctx.font = `${cs.fontWeight} ${cs.fontSize} ${cs.fontFamily}`;
			const textW = ctx.measureText(target.value.slice(0, target.selectionStart ?? target.value.length)).width;
			const left = rect.left + (parseFloat(cs.paddingLeft) || 0) + textW;
			return new DOMRect(left, rect.top, 0, rect.height);
		}
		document.addEventListener("input", (e) => {
			if (committing) return;
			const target = field(e);
			if (!target) {
				remove();
				removeEmoji();
				return;
			}
			const val = (isTextControl(target) ? target.value.slice(0, target.selectionStart ?? void 0) : textBeforeCaret(target)).replace(/\u00A0/g, " ");
			const quipFound = val.match(/(![a-zA-Z]+)$/);
			const emojiFound = val.match(/(?:^|[\s])(:[a-zA-Z0-9_+-]+(?:[ ][a-zA-Z0-9_+-]*)*)$/);
			if (quipFound && map[quipFound[1]]) {
				popover(target, quipFound[1], map[quipFound[1]]);
				removeEmoji();
			} else if (emojiFound && emojiFound[1].length <= 40) {
				const code = emojiFound[1];
				emojiPalette(target, code, code.slice(1).replace(/\s+/g, " ").trimEnd());
				remove();
			} else {
				remove();
				removeEmoji();
			}
		}, true);
		document.addEventListener("keydown", (e) => {
			if (emojiCode) {
				if (e.key === "ArrowDown") {
					e.preventDefault();
					moveEmojiSelection(1);
					return;
				}
				if (e.key === "ArrowUp") {
					e.preventDefault();
					moveEmojiSelection(-1);
					return;
				}
				if (e.key === "Enter" || e.key === "Tab") {
					e.preventDefault();
					e.stopPropagation();
					e.stopImmediatePropagation();
					if (e.repeat) return;
					const target = field(e);
					if (target) commitEmoji(target);
					return;
				}
				if (e.key === "Escape") {
					e.preventDefault();
					removeEmoji();
					return;
				}
			}
			if ((modifier === "alt" ? e.altKey : modifier === "ctrl" ? e.ctrlKey : e.shiftKey) && e.key === "Enter" && match) {
				e.preventDefault();
				e.stopPropagation();
				e.stopImmediatePropagation();
				if (e.repeat) return;
				const target = field(e);
				if (target) commit(target);
			}
			if (e.key === "Escape") remove();
		}, true);
		document.addEventListener("scroll", () => {
			remove();
			removeEmoji();
		}, true);
	}
	//#endregion
})();
